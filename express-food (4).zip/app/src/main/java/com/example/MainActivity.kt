package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.ExpressRepository
import com.example.model.UserRole
import com.example.ui.screens.admin.AdminMainScreen
import com.example.ui.screens.auth.RoleGatewayScreen
import com.example.ui.screens.auth.RoleSpecificLoginScreen
import com.example.ui.screens.customer.CustomerMainScreen
import com.example.ui.screens.delivery.DeliveryMainScreen
import com.example.ui.screens.restaurant.RestaurantMainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ExpressFoodRootApp()
                }
            }
        }
    }
}

@Composable
fun ExpressFoodRootApp() {
    val currentUser by ExpressRepository.currentUser.collectAsState()
    var selectedAuthRole by remember { mutableStateOf<UserRole?>(null) }

    if (currentUser != null) {
        val user = currentUser!!
        BackHandler {
            // Logout on system back press at root
            ExpressRepository.logout()
        }

        when (user.role) {
            UserRole.CUSTOMER -> {
                CustomerMainScreen(
                    onLogout = { ExpressRepository.logout() }
                )
            }

            UserRole.RESTAURANT -> {
                RestaurantMainScreen(
                    onLogout = { ExpressRepository.logout() }
                )
            }

            UserRole.DELIVERY_PARTNER -> {
                DeliveryMainScreen(
                    onLogout = { ExpressRepository.logout() }
                )
            }

            UserRole.ADMIN -> {
                AdminMainScreen(
                    onLogout = { ExpressRepository.logout() }
                )
            }
        }
    } else {
        if (selectedAuthRole != null) {
            val role = selectedAuthRole!!
            BackHandler {
                selectedAuthRole = null
            }

            RoleSpecificLoginScreen(
                targetRole = role,
                title = when (role) {
                    UserRole.CUSTOMER -> "Customer Sign In"
                    UserRole.RESTAURANT -> "Restaurant Partner Portal"
                    UserRole.DELIVERY_PARTNER -> "Delivery Partner Portal"
                    UserRole.ADMIN -> "Express Food Admin Login"
                },
                onLoginSuccess = {
                    selectedAuthRole = null
                },
                onBack = {
                    selectedAuthRole = null
                }
            )
        } else {
            RoleGatewayScreen(
                onSelectCustomer = { selectedAuthRole = UserRole.CUSTOMER },
                onSelectRestaurant = { selectedAuthRole = UserRole.RESTAURANT },
                onSelectDelivery = { selectedAuthRole = UserRole.DELIVERY_PARTNER },
                onSelectAdmin = { selectedAuthRole = UserRole.ADMIN }
            )
        }
    }
}
