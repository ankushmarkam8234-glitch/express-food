package com.example.model

enum class UserRole {
    CUSTOMER,
    RESTAURANT,
    DELIVERY_PARTNER,
    ADMIN
}

data class UserAccount(
    val id: String,
    val email: String,
    val name: String,
    val phone: String,
    val role: UserRole,
    val passwordHash: String,
    val isActive: Boolean = true,
    val assignedEntityId: String? = null, // restaurantId or deliveryPartnerId
    val mustChangePassword: Boolean = false,
    val status: String = "ACTIVE" // "ACTIVE", "DEACTIVATED", "SUSPENDED"
)

data class Restaurant(
    val id: String,
    val name: String,
    val cuisine: String,
    val address: String,
    val lat: Double,
    val lng: Double,
    val rating: Double,
    val ratingCount: Int,
    val isOpen: Boolean, // controls online/offline acceptance of orders
    val phone: String,
    val email: String = "",
    val bannerEmoji: String = "🍛",
    val openingHours: String = "10:00 AM - 11:00 PM",
    val status: String = "ACTIVE", // "ACTIVE", "DEACTIVATED", "SUSPENDED"
    val lastStatusUpdatedAt: Long = System.currentTimeMillis()
)

data class MenuItem(
    val id: String,
    val restaurantId: String,
    val name: String,
    val description: String,
    val category: String,
    val originalPrice: Int,
    val markupAmount: Int = 20, // Strict rule: original_price + ₹20
    val isAvailable: Boolean = true,
    val isVeg: Boolean = true,
    val imageUrl: String = ""
) {
    // Validated customer price: original + ₹20 added exactly once
    val customerPrice: Int
        get() = originalPrice + markupAmount
}

data class CartItem(
    val menuItem: MenuItem,
    val quantity: Int
) {
    val itemSubtotal: Int
        get() = menuItem.customerPrice * quantity
}

enum class OrderStatus {
    CART,
    CHECKOUT,
    ORDER_PLACED,
    RESTAURANT_ACCEPTED,
    PREPARING,
    READY_FOR_PICKUP,
    DELIVERY_PARTNER_ASSIGNED,
    PICKED_UP,
    ON_THE_WAY,
    DELIVERED,
    CANCELLED,
    REJECTED,
    FAILED
}

enum class PaymentMethod {
    COD,
    ONLINE_RAZORPAY
}

enum class PaymentStatus {
    PENDING,
    SUCCESSFUL,
    FAILED,
    CANCELLED,
    REFUNDED
}

data class OrderStatusEntry(
    val status: OrderStatus,
    val timestamp: Long,
    val note: String = ""
)

data class DeliveryLocation(
    val title: String,
    val fullAddress: String,
    val lat: Double,
    val lng: Double
)

data class Order(
    val id: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val customerLat: Double = 28.6139,
    val customerLng: Double = 77.2090,
    val restaurantId: String,
    val restaurantName: String,
    val restaurantAddress: String,
    val restaurantLat: Double = 28.6328,
    val restaurantLng: Double = 77.2197,
    val items: List<CartItem>,
    val subtotal: Int,
    val deliveryFee: Int,
    val platformFee: Int = 10, // Customer platform fee: ₹10
    val tipAmount: Int = 0,
    val coinDiscount: Int = 0,
    val deliveryFeeDiscount: Int = 0,
    val totalAmount: Int,
    val distanceKm: Double,
    val isRoadDistance: Boolean = false, // false for coordinate straight-line, true if road routing configured
    val isEmergencyOrder: Boolean = false,
    val emergencyApprovedByAdmin: Boolean = false,
    val paymentMethod: PaymentMethod = PaymentMethod.COD,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val orderStatus: OrderStatus = OrderStatus.ORDER_PLACED,
    val assignedDeliveryPartnerId: String? = null,
    val assignedDeliveryPartnerName: String? = null,
    val assignedDeliveryPartnerPhone: String? = null,
    val assignedDeliveryPartnerOnline: Boolean = true,
    val partnerOfflineAlert: Boolean = false, // Set to true if assigned partner goes offline during delivery
    val createdAt: Long = System.currentTimeMillis(),
    val statusHistory: List<OrderStatusEntry> = emptyList(),
    val restaurantCommission: Int = 10, // Restaurant commission: ₹10 per completed order
    val ownerCommission: Int = 10, // Express Food owner commission: ₹10 per completed order
    val deliveryFeeDiscountTicketId: String? = null,
    val coinsAwarded: Boolean = false,
    val coinsEarned: Int = 0,
    val deliveryPartnerRatePerKm: Int = 17,
    val deliveryPartnerEarnings: Int = (kotlin.math.ceil(distanceKm).toInt().coerceAtLeast(1) * 17)
)

data class AppNotification(
    val id: String,
    val recipientRole: UserRole,
    val recipientEntityId: String? = null, // restaurantId or deliveryPartnerId or userId
    val title: String,
    val message: String,
    val orderId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class DeliveryPartner(
    val id: String,
    val code: String, // e.g. "DP-101"
    val name: String,
    val phone: String,
    val email: String = "",
    val address: String = "Central Hub, New Delhi",
    val vehicleType: String = "Motorcycle",
    val isOnline: Boolean = true,
    val status: String = "ACTIVE", // "ACTIVE", "DEACTIVATED", "SUSPENDED"
    val lastStatusUpdatedAt: Long = System.currentTimeMillis(),
    val totalDeliveries: Int = 0,
    val baseEarnings: Int = 0,
    val tipsEarned: Int = 0,
    val rating: Double = 4.8,
    val activeOrderId: String? = null
)

data class TicketMessage(
    val senderId: String,
    val senderName: String,
    val senderRole: UserRole,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class SupportTicket(
    val id: String,
    val customerId: String,
    val customerName: String,
    val orderId: String? = null,
    val category: String, // "DELIVERY_FEE_DISCOUNT", "ORDER_ISSUE", "PAYMENT_ISSUE", "GENERAL"
    val reason: String,
    val requestedDiscount: Int = 0,
    val approvedDiscount: Int = 0,
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED, RESOLVED, CLOSED
    val messages: List<TicketMessage> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val approvedBy: String? = null,
    val approvedAt: Long? = null
)

data class RatingReview(
    val id: String,
    val orderId: String,
    val customerId: String,
    val customerName: String,
    val targetType: String, // "RESTAURANT" or "DELIVERY_PARTNER"
    val targetId: String,
    val stars: Int,
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CoinTransaction(
    val id: String,
    val orderId: String?,
    val amount: Int, // positive for earn, negative for redeem
    val type: String, // "EARNED", "REDEEMED", "REFUNDED"
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AuditLog(
    val id: String,
    val adminEmail: String,
    val action: String,
    val targetType: String,
    val targetId: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class DeliveryFeeResult(
    val fee: Int,
    val bandDescription: String,
    val isEmergencyRequired: Boolean,
    val isAvailable: Boolean,
    val isRoadDistance: Boolean = false
)

data class PriceCalculation(
    val subtotal: Int,
    val deliveryFee: Int,
    val deliveryFeeDiscount: Int,
    val effectiveDeliveryFee: Int,
    val platformFee: Int,
    val tipAmount: Int,
    val coinDiscount: Int,
    val coinsToRedeem: Int,
    val totalAmount: Int
)

sealed class LoginResult {
    data class Success(val user: UserAccount) : LoginResult()
    data class MustChangePassword(val user: UserAccount) : LoginResult()
    data class AccountBlocked(val reason: String) : LoginResult()
    data class InvalidCredentials(val message: String) : LoginResult()
}
