package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.math.ceil

object ExpressRepository {

    // Language state
    private val _currentLanguage = MutableStateFlow(com.example.localization.AppLanguage.HINDI)
    val currentLanguage: StateFlow<com.example.localization.AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: com.example.localization.AppLanguage) {
        _currentLanguage.value = language
    }

    // Active User / Session
    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    // Data collections
    private val _users = MutableStateFlow<List<UserAccount>>(emptyList())
    val users: StateFlow<List<UserAccount>> = _users.asStateFlow()

    private val _restaurants = MutableStateFlow<List<Restaurant>>(emptyList())
    val restaurants: StateFlow<List<Restaurant>> = _restaurants.asStateFlow()

    private val _menuItems = MutableStateFlow<List<MenuItem>>(emptyList())
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _deliveryPartners = MutableStateFlow<List<DeliveryPartner>>(emptyList())
    val deliveryPartners: StateFlow<List<DeliveryPartner>> = _deliveryPartners.asStateFlow()

    private val _supportTickets = MutableStateFlow<List<SupportTicket>>(emptyList())
    val supportTickets: StateFlow<List<SupportTicket>> = _supportTickets.asStateFlow()

    private val _ratings = MutableStateFlow<List<RatingReview>>(emptyList())
    val ratings: StateFlow<List<RatingReview>> = _ratings.asStateFlow()

    private val _coinBalance = MutableStateFlow(350) // Default 350 coins (= ₹35 discount ready)
    val coinBalance: StateFlow<Int> = _coinBalance.asStateFlow()

    private val _coinTransactions = MutableStateFlow<List<CoinTransaction>>(emptyList())
    val coinTransactions: StateFlow<List<CoinTransaction>> = _coinTransactions.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    // Customer Saved Delivery Locations with coordinates
    private val _savedLocations = MutableStateFlow<List<DeliveryLocation>>(emptyList())
    val savedLocations: StateFlow<List<DeliveryLocation>> = _savedLocations.asStateFlow()

    private val _selectedLocation = MutableStateFlow<DeliveryLocation?>(null)
    val selectedLocation: StateFlow<DeliveryLocation?> = _selectedLocation.asStateFlow()

    fun selectDeliveryLocation(location: DeliveryLocation) {
        _selectedLocation.value = location
    }

    // Configurable Coin Reward Rate: Default 15 coins per eligible ₹100 of subtotal
    private val _coinsPerHundredConfig = MutableStateFlow(15)
    val coinsPerHundredConfig: StateFlow<Int> = _coinsPerHundredConfig.asStateFlow()

    fun setCoinRewardRate(coinsPer100: Int) {
        val validRate = coinsPer100.coerceIn(1, 100)
        _coinsPerHundredConfig.value = validRate
        recordAuditLog("CONFIG_UPDATE", "COIN_RATE", "COINS_PER_100", "Updated reward rate to $validRate coins per ₹100")
    }

    // Delivery fee discount in progress for current checkout
    private val _activeFeeDiscount = MutableStateFlow(0)
    val activeFeeDiscount: StateFlow<Int> = _activeFeeDiscount.asStateFlow()

    private val _activeDiscountTicketId = MutableStateFlow<String?>(null)
    val activeDiscountTicketId: StateFlow<String?> = _activeDiscountTicketId.asStateFlow()

    // Notifications and Sound State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    fun toggleSoundEnabled() {
        _isSoundEnabled.value = !_isSoundEnabled.value
    }

    fun setSoundEnabled(enabled: Boolean) {
        _isSoundEnabled.value = enabled
    }

    fun dismissNotification(id: String) {
        _notifications.value = _notifications.value.filterNot { it.id == id }
    }

    fun postNotification(notification: AppNotification) {
        val existing = _notifications.value.any {
            it.orderId != null && it.orderId == notification.orderId &&
            it.recipientRole == notification.recipientRole &&
            it.recipientEntityId == notification.recipientEntityId &&
            it.title == notification.title
        }
        if (!existing) {
            _notifications.value = listOf(notification) + _notifications.value
        }
    }

    // Demo Mode & Cloud Service Flags
    val isDemoMode: Boolean = true
    val isFirebaseConfigured: Boolean = false
    val isRazorpayLive: Boolean = false
    val isGoogleMapsLive: Boolean = false

    init {
        bootstrapData()
    }

    fun resetToDefaultState() {
        clearCart()
        _coinBalance.value = 350
        _coinsPerHundredConfig.value = 15
        _activeFeeDiscount.value = 0
        _activeDiscountTicketId.value = null
        _notifications.value = emptyList()
        _isSoundEnabled.value = true
        bootstrapData()
    }

    private fun bootstrapData() {
        // Initial Admin User
        val admin = UserAccount(
            id = "ADMIN-001",
            email = "admin@expressfood.in",
            name = "Express Admin",
            phone = "9876543210",
            role = UserRole.ADMIN,
            passwordHash = "Admin@2026",
            isActive = true,
            status = "ACTIVE",
            mustChangePassword = false
        )

        // Initial Customer
        val customer = UserAccount(
            id = "CUST-1001",
            email = "customer@expressfood.in",
            name = "Rahul Verma",
            phone = "9811223344",
            role = UserRole.CUSTOMER,
            passwordHash = "customer123",
            isActive = true,
            status = "ACTIVE",
            mustChangePassword = false
        )

        // Seed Saved Locations with verified GPS coordinates
        val defaultLocations = listOf(
            DeliveryLocation("Home - Sunshine Heights", "Flat 402, Sunshine Heights, New Delhi", 28.6250, 77.2150),
            DeliveryLocation("Office - Connaught Place", "Barakhamba Road, Connaught Place, New Delhi", 28.6315, 77.2220),
            DeliveryLocation("South Extension", "Block E, South Extension Part II, New Delhi", 28.5684, 77.2217),
            DeliveryLocation("Karol Bagh Hub", "Pusa Road, Karol Bagh, New Delhi", 28.6517, 77.1906),
            DeliveryLocation("Noida Sector 18 (Emergency Band)", "Atta Market, Sector 18, Noida", 28.5708, 77.3271)
        )
        _savedLocations.value = defaultLocations
        _selectedLocation.value = defaultLocations.first()

        // Seed Restaurants
        val rest1 = Restaurant(
            id = "REST-001",
            name = "Dilli Durbar Express",
            cuisine = "North Indian, Biryani, Mughlai",
            address = "Shop 14, Connaught Place, New Delhi",
            lat = 28.6328,
            lng = 77.2197,
            rating = 4.7,
            ratingCount = 842,
            isOpen = true,
            phone = "9822334455",
            email = "dilli@expressfood.in",
            bannerEmoji = "🥘",
            openingHours = "11:00 AM - 11:30 PM",
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis() - 3600000L
        )
        val rest2 = Restaurant(
            id = "REST-002",
            name = "Dakshin Tiffin House",
            cuisine = "South Indian, Dosa, Idli, Filter Coffee",
            address = "Plot 8, Indiranagar, Bengaluru",
            lat = 12.9784,
            lng = 77.6408,
            rating = 4.8,
            ratingCount = 1205,
            isOpen = true,
            phone = "9822001122",
            email = "dakshin@expressfood.in",
            bannerEmoji = "🥞",
            openingHours = "07:30 AM - 10:30 PM",
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis() - 7200000L
        )
        val rest3 = Restaurant(
            id = "REST-003",
            name = "Punjab Grill & Tandoor",
            cuisine = "Punjabi, Tandoori, Parathas",
            address = "Sector 18, Noida",
            lat = 28.5708,
            lng = 77.3271,
            rating = 4.6,
            ratingCount = 630,
            isOpen = true,
            phone = "9833445566",
            email = "punjabgrill@expressfood.in",
            bannerEmoji = "🍗",
            openingHours = "12:00 PM - 11:00 PM",
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis() - 14400000L
        )

        // Seed Menu Items
        val items = listOf(
            MenuItem(
                id = "MENU-101",
                restaurantId = "REST-001",
                name = "Butter Chicken & Garlic Naan",
                description = "Tender tandoori chicken simmered in rich creamy tomato and butter gravy, served with 2 freshly baked naans.",
                category = "Main Course",
                originalPrice = 220, // customer price = 240
                isVeg = false,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-102",
                restaurantId = "REST-001",
                name = "Dal Makhani with Jeera Rice",
                description = "Slow-cooked black lentils overnight with desi ghee, paired with aromatic cumin basmati rice.",
                category = "Main Course",
                originalPrice = 160, // customer price = 180
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-103",
                restaurantId = "REST-001",
                name = "Paneer Tikka Dum Biryani",
                description = "Smoky grilled cottage cheese cubes layered with spiced long grain basmati rice and saffron.",
                category = "Biryani",
                originalPrice = 180, // customer price = 200
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-104",
                restaurantId = "REST-001",
                name = "Gulab Jamun (2 Pieces)",
                description = "Warm golden milk-solid dumplings soaked in fragrant cardamom rose sugar syrup.",
                category = "Desserts",
                originalPrice = 50, // customer price = 70
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-201",
                restaurantId = "REST-002",
                name = "Mysore Masala Dosa",
                description = "Crispy golden crepe smeared with spicy red chutney, filled with potato bhaji, served with 3 chutneys & piping sambar.",
                category = "South Indian",
                originalPrice = 90, // customer price = 110
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-202",
                restaurantId = "REST-002",
                name = "Ghee Podi Idli (4 Pieces)",
                description = "Steamed fluffy rice cakes tossed in aromatic gunpowder spice blend and pure cow ghee.",
                category = "South Indian",
                originalPrice = 80, // customer price = 100
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-203",
                restaurantId = "REST-002",
                name = "Degree Filter Coffee",
                description = "Traditional freshly brewed South Indian chicory blend coffee frothed with hot milk.",
                category = "Beverages",
                originalPrice = 30, // customer price = 50
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-301",
                restaurantId = "REST-003",
                name = "Amritsari Chole Bhature",
                description = "Pindi style spicy chickpeas paired with 2 fluffy bhaturas, pickled carrots and mint chutney.",
                category = "North Indian",
                originalPrice = 120, // customer price = 140
                isVeg = true,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=400&q=80"
            ),
            MenuItem(
                id = "MENU-302",
                restaurantId = "REST-003",
                name = "Tandoori Chicken (Half)",
                description = "Juicy chicken roasted in clay oven with traditional tandoori spices and lemon.",
                category = "Starters",
                originalPrice = 200, // customer price = 220
                isVeg = false,
                isAvailable = true,
                imageUrl = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=400&q=80"
            )
        )

        // Seed Delivery Partners
        val dp1 = DeliveryPartner(
            id = "DP-001",
            code = "DP-101",
            name = "Ramesh Kumar",
            phone = "9988776655",
            email = "ramesh@expressfood.in",
            address = "Central Delhi Hub, Connaught Place",
            vehicleType = "Motorcycle",
            isOnline = true,
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis() - 1800000L,
            totalDeliveries = 142,
            baseEarnings = 5680,
            tipsEarned = 1420,
            rating = 4.9
        )
        val dp2 = DeliveryPartner(
            id = "DP-002",
            code = "DP-102",
            name = "Amit Sharma",
            phone = "9871122334",
            email = "amit@expressfood.in",
            address = "South Extension Hub, New Delhi",
            vehicleType = "Scooter",
            isOnline = true,
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis() - 5400000L,
            totalDeliveries = 98,
            baseEarnings = 3920,
            tipsEarned = 890,
            rating = 4.7
        )

        // Seed Restaurant Partner User Accounts
        val restUser1 = UserAccount(
            id = "RESTUSER-001",
            email = "dilli@expressfood.in",
            name = "Dilli Durbar Owner",
            phone = "9822334455",
            role = UserRole.RESTAURANT,
            passwordHash = "rest123",
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = "REST-001",
            mustChangePassword = false
        )
        val restUser2 = UserAccount(
            id = "RESTUSER-002",
            email = "dakshin@expressfood.in",
            name = "Dakshin Owner",
            phone = "9822001122",
            role = UserRole.RESTAURANT,
            passwordHash = "rest123",
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = "REST-002",
            mustChangePassword = false
        )

        // Seed Delivery Partner User Accounts
        val dpUser1 = UserAccount(
            id = "DPUSER-001",
            email = "ramesh@expressfood.in",
            name = "Ramesh Kumar",
            phone = "9988776655",
            role = UserRole.DELIVERY_PARTNER,
            passwordHash = "partner123",
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = "DP-001",
            mustChangePassword = false
        )
        val dpUser2 = UserAccount(
            id = "DPUSER-002",
            email = "amit@expressfood.in",
            name = "Amit Sharma",
            phone = "9871122334",
            role = UserRole.DELIVERY_PARTNER,
            passwordHash = "partner123",
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = "DP-002",
            mustChangePassword = false
        )

        // Seed active order waiting for assignment
        val pendingOrder = Order(
            id = "ORD-8001",
            customerId = "CUST-1001",
            customerName = "Rahul Verma",
            customerPhone = "+91 9811223344",
            deliveryAddress = "Flat 402, Sunshine Heights, New Delhi",
            customerLat = 28.6250,
            customerLng = 77.2150,
            restaurantId = "REST-001",
            restaurantName = "Dilli Durbar Express",
            restaurantAddress = "Shop 14, Connaught Place, New Delhi",
            restaurantLat = 28.6328,
            restaurantLng = 77.2197,
            items = listOf(CartItem(items[0], 1), CartItem(items[1], 1)),
            subtotal = 420,
            deliveryFee = 25,
            platformFee = 10,
            tipAmount = 10,
            totalAmount = 465,
            distanceKm = 0.9,
            orderStatus = OrderStatus.READY_FOR_PICKUP,
            assignedDeliveryPartnerId = null,
            createdAt = System.currentTimeMillis() - 600000L
        )

        val pastOrder = Order(
            id = "ORD-7001",
            customerId = "CUST-1001",
            customerName = "Rahul Verma",
            customerPhone = "+91 9811223344",
            deliveryAddress = "Flat 402, Sunshine Heights, New Delhi",
            customerLat = 28.6250,
            customerLng = 77.2150,
            restaurantId = "REST-001",
            restaurantName = "Dilli Durbar Express",
            restaurantAddress = "Shop 14, Connaught Place, New Delhi",
            restaurantLat = 28.6328,
            restaurantLng = 77.2197,
            items = listOf(
                CartItem(items[0], 1), // customerPrice 240
                CartItem(items[3], 1)  // customerPrice 70
            ),
            subtotal = 310,
            deliveryFee = 50,
            platformFee = 10,
            tipAmount = 20,
            coinDiscount = 10,
            deliveryFeeDiscount = 0,
            totalAmount = 380,
            distanceKm = 1.8,
            paymentMethod = PaymentMethod.ONLINE_RAZORPAY,
            paymentStatus = PaymentStatus.SUCCESSFUL,
            orderStatus = OrderStatus.DELIVERED,
            assignedDeliveryPartnerId = "DP-001",
            assignedDeliveryPartnerName = "Ramesh Kumar (DP-101)",
            assignedDeliveryPartnerPhone = "+91 9988776655",
            assignedDeliveryPartnerOnline = true,
            createdAt = System.currentTimeMillis() - 86400000L,
            statusHistory = listOf(
                OrderStatusEntry(OrderStatus.ORDER_PLACED, System.currentTimeMillis() - 86400000L),
                OrderStatusEntry(OrderStatus.RESTAURANT_ACCEPTED, System.currentTimeMillis() - 84000000L),
                OrderStatusEntry(OrderStatus.PREPARING, System.currentTimeMillis() - 83000000L),
                OrderStatusEntry(OrderStatus.READY_FOR_PICKUP, System.currentTimeMillis() - 81000000L),
                OrderStatusEntry(OrderStatus.DELIVERY_PARTNER_ASSIGNED, System.currentTimeMillis() - 80000000L),
                OrderStatusEntry(OrderStatus.PICKED_UP, System.currentTimeMillis() - 79000000L),
                OrderStatusEntry(OrderStatus.ON_THE_WAY, System.currentTimeMillis() - 78000000L),
                OrderStatusEntry(OrderStatus.DELIVERED, System.currentTimeMillis() - 76000000L)
            ),
            restaurantCommission = 10,
            ownerCommission = 10,
            coinsAwarded = true,
            coinsEarned = 45
        )

        _users.value = listOf(admin, customer, restUser1, restUser2, dpUser1, dpUser2)
        _restaurants.value = listOf(rest1, rest2, rest3)
        _menuItems.value = items
        _deliveryPartners.value = listOf(dp1, dp2)
        _orders.value = listOf(pendingOrder, pastOrder)
        _coinTransactions.value = listOf(
            CoinTransaction("COIN-1", "ORD-7001", 45, "EARNED", "Order ORD-7001 reward (15 coins per ₹100 of ₹310 subtotal)"),
            CoinTransaction("COIN-2", null, 350, "EARNED", "Welcome joining bonus")
        )
        _auditLogs.value = listOf(
            AuditLog("AUD-1", "admin@expressfood.in", "SYSTEM_BOOTSTRAP", "PLATFORM", "SYSTEM", "Express Food platform initialized with Order Assignment first.", System.currentTimeMillis() - 100000L)
        )

        _currentUser.value = customer
    }

    // Normalization utilities
    fun normalizeEmail(raw: String): String = raw.trim().lowercase()

    fun normalizePhone(raw: String): String {
        var clean = raw.replace(Regex("[^0-9]"), "")
        if (clean.startsWith("91") && clean.length == 12) {
            clean = clean.substring(2)
        } else if (clean.startsWith("0") && clean.length == 11) {
            clean = clean.substring(1)
        }
        return clean
    }

    // AUTOMATIC DISTANCE FROM MAP COORDINATES (Haversine Formula)
    fun calculateCoordinateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val dist = r * c
        return Math.round(dist * 10.0) / 10.0
    }

    // Exact Delivery Fee Calculation Schedule
    fun calculateDeliveryFee(distanceKm: Double, isEmergency: Boolean = false): DeliveryFeeResult {
        if (distanceKm <= 0.0) {
            return DeliveryFeeResult(25, "Up to 1 km", false, true)
        }
        val band = ceil(distanceKm).toInt()

        return when {
            band <= 1 -> DeliveryFeeResult(25, "Up to 1 km", false, true)
            band == 2 -> DeliveryFeeResult(50, "Over 1 km and up to 2 km", false, true)
            band == 3 -> DeliveryFeeResult(75, "Over 2 km and up to 3 km", false, true)
            band == 4 -> DeliveryFeeResult(75, "Over 3 km and up to 4 km", false, true)
            band == 5 -> DeliveryFeeResult(85, "Over 4 km and up to 5 km", false, true)
            band == 6 -> DeliveryFeeResult(86, "Over 5 km and up to 6 km", false, true)
            band == 7 -> DeliveryFeeResult(90, "Over 6 km and up to 7 km", false, true)
            band == 8 -> DeliveryFeeResult(92, "Over 7 km and up to 8 km", false, true)
            band == 9 -> DeliveryFeeResult(100, "Over 8 km and up to 9 km", false, true)
            band == 10 -> DeliveryFeeResult(135, "Over 9 km and up to 10 km", false, true)
            band == 11 -> DeliveryFeeResult(200, "Over 10 km and up to 11 km (Emergency Only)", true, isEmergency)
            band == 12 -> DeliveryFeeResult(250, "Over 11 km and up to 12 km (Emergency Only)", true, isEmergency)
            band == 13 -> DeliveryFeeResult(300, "Over 12 km and up to 13 km (Emergency Only)", true, isEmergency)
            else -> DeliveryFeeResult(0, "Over 13 km: Delivery Unavailable", false, false)
        }
    }

    fun calculateEarnedCoins(subtotal: Int): Int {
        val blocks = subtotal / 100
        return blocks * _coinsPerHundredConfig.value
    }

    // Full Price Breakdown Calculation
    fun calculatePrice(
        cartItems: List<CartItem>,
        distanceKm: Double,
        tipAmount: Int,
        coinsToRedeem: Int,
        feeDiscount: Int,
        isEmergency: Boolean
    ): PriceCalculation {
        val subtotal = cartItems.sumOf { it.itemSubtotal }
        val feeResult = calculateDeliveryFee(distanceKm, isEmergency)
        val deliveryFee = feeResult.fee

        val validFeeDiscount = feeDiscount.coerceIn(0, deliveryFee)
        val effectiveDeliveryFee = deliveryFee - validFeeDiscount
        val platformFee = if (cartItems.isNotEmpty()) 10 else 0

        val maxRedeemableCoins = minOf(_coinBalance.value, coinsToRedeem, subtotal * 10)
        val coinDiscount = maxRedeemableCoins / 10

        val total = maxOf(0, subtotal + effectiveDeliveryFee + platformFee + tipAmount - coinDiscount)

        return PriceCalculation(
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            deliveryFeeDiscount = validFeeDiscount,
            effectiveDeliveryFee = effectiveDeliveryFee,
            platformFee = platformFee,
            tipAmount = tipAmount,
            coinDiscount = coinDiscount,
            coinsToRedeem = maxRedeemableCoins,
            totalAmount = total
        )
    }

    // Cart operations
    fun addToCart(menuItem: MenuItem) {
        val current = _cart.value.toMutableList()
        if (current.isNotEmpty() && current.first().menuItem.restaurantId != menuItem.restaurantId) {
            current.clear()
        }
        val index = current.indexOfFirst { it.menuItem.id == menuItem.id }
        if (index != -1) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + 1)
        } else {
            current.add(CartItem(menuItem, 1))
        }
        _cart.value = current
    }

    fun updateCartQuantity(menuItemId: String, newQuantity: Int) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.menuItem.id == menuItemId }
        if (index != -1) {
            if (newQuantity <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = newQuantity)
            }
            _cart.value = current
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _activeFeeDiscount.value = 0
        _activeDiscountTicketId.value = null
    }

    // Place Order using Automatic Map Distance
    fun placeOrder(
        customerAddress: String,
        customerLat: Double,
        customerLng: Double,
        tipAmount: Int,
        coinsRedeemed: Int,
        paymentMethod: PaymentMethod,
        isEmergency: Boolean = false
    ): Result<Order> {
        val cartItems = _cart.value
        if (cartItems.isEmpty()) {
            return Result.failure(IllegalStateException("Cart is empty"))
        }

        val firstItem = cartItems.first().menuItem
        val restaurant = _restaurants.value.find { it.id == firstItem.restaurantId }
            ?: return Result.failure(IllegalStateException("Restaurant not found"))

        if (!restaurant.isOpen) {
            return Result.failure(IllegalStateException("Restaurant is currently offline and not accepting new orders."))
        }

        // Calculate accurate distance from restaurant coordinates to customer coordinates
        val distanceKm = calculateCoordinateDistance(restaurant.lat, restaurant.lng, customerLat, customerLng)

        val feeResult = calculateDeliveryFee(distanceKm, isEmergency)
        if (!feeResult.isAvailable) {
            return Result.failure(IllegalStateException("Distance exceeds 13 km limit ($distanceKm km) or emergency not confirmed"))
        }

        val price = calculatePrice(
            cartItems = cartItems,
            distanceKm = distanceKm,
            tipAmount = tipAmount,
            coinsToRedeem = coinsRedeemed,
            feeDiscount = _activeFeeDiscount.value,
            isEmergency = isEmergency
        )

        val user = _currentUser.value ?: return Result.failure(IllegalStateException("User not logged in"))

        val orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 6).uppercase()
        val newOrder = Order(
            id = orderId,
            customerId = user.id,
            customerName = user.name,
            customerPhone = user.phone,
            deliveryAddress = customerAddress,
            customerLat = customerLat,
            customerLng = customerLng,
            restaurantId = restaurant.id,
            restaurantName = restaurant.name,
            restaurantAddress = restaurant.address,
            restaurantLat = restaurant.lat,
            restaurantLng = restaurant.lng,
            items = cartItems.toList(),
            subtotal = price.subtotal,
            deliveryFee = price.deliveryFee,
            platformFee = price.platformFee,
            tipAmount = price.tipAmount,
            coinDiscount = price.coinDiscount,
            deliveryFeeDiscount = price.deliveryFeeDiscount,
            totalAmount = price.totalAmount,
            distanceKm = distanceKm,
            isRoadDistance = false,
            isEmergencyOrder = feeResult.isEmergencyRequired,
            emergencyApprovedByAdmin = !feeResult.isEmergencyRequired,
            paymentMethod = paymentMethod,
            paymentStatus = if (paymentMethod == PaymentMethod.COD) PaymentStatus.PENDING else PaymentStatus.SUCCESSFUL,
            orderStatus = OrderStatus.ORDER_PLACED,
            createdAt = System.currentTimeMillis(),
            statusHistory = listOf(OrderStatusEntry(OrderStatus.ORDER_PLACED, System.currentTimeMillis(), "Order placed by customer")),
            restaurantCommission = 10,
            ownerCommission = 10,
            deliveryFeeDiscountTicketId = _activeDiscountTicketId.value,
            coinsAwarded = false,
            coinsEarned = calculateEarnedCoins(price.subtotal)
        )

        if (price.coinsToRedeem > 0) {
            _coinBalance.value = maxOf(0, _coinBalance.value - price.coinsToRedeem)
            val tx = CoinTransaction(
                id = "TX-" + UUID.randomUUID().toString().take(6),
                orderId = orderId,
                amount = -price.coinsToRedeem,
                type = "REDEEMED",
                description = "Redeemed for ₹${price.coinDiscount} discount on order #$orderId"
            )
            _coinTransactions.value = listOf(tx) + _coinTransactions.value
        }

        _orders.value = listOf(newOrder) + _orders.value

        // Dispatch new order alert notification to restaurant partner
        val restNotif = AppNotification(
            id = "NOTIF-" + UUID.randomUUID().toString().take(6).uppercase(),
            recipientRole = UserRole.RESTAURANT,
            recipientEntityId = restaurant.id,
            title = "New Order #${newOrder.id} Received!",
            message = "${cartItems.sumOf { it.quantity }} items • ₹${price.totalAmount} • ${paymentMethod.name}",
            orderId = orderId
        )
        postNotification(restNotif)

        clearCart()
        return Result.success(newOrder)
    }

    // Overloaded placeOrder for backward compatibility
    fun placeOrder(
        customerAddress: String,
        distanceKm: Double,
        tipAmount: Int,
        coinsRedeemed: Int,
        paymentMethod: PaymentMethod,
        isEmergency: Boolean = false
    ): Result<Order> {
        val cartItems = _cart.value
        val firstItem = cartItems.firstOrNull()?.menuItem
        val restaurant = _restaurants.value.find { it.id == firstItem?.restaurantId } ?: _restaurants.value.first()
        val approxLat = restaurant.lat + (distanceKm / 111.0)
        val approxLng = restaurant.lng
        return placeOrder(
            customerAddress = customerAddress,
            customerLat = approxLat,
            customerLng = approxLng,
            tipAmount = tipAmount,
            coinsRedeemed = coinsRedeemed,
            paymentMethod = paymentMethod,
            isEmergency = isEmergency
        )
    }

    // Status Transitions with Validation
    fun updateOrderStatus(orderId: String, newStatus: OrderStatus, note: String = ""): Boolean {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return false

        val order = currentOrders[index]
        val currentStatus = order.orderStatus

        val allowed = when (currentStatus) {
            OrderStatus.ORDER_PLACED -> newStatus in listOf(OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.REJECTED, OrderStatus.CANCELLED)
            OrderStatus.RESTAURANT_ACCEPTED -> newStatus in listOf(OrderStatus.PREPARING, OrderStatus.CANCELLED)
            OrderStatus.PREPARING -> newStatus in listOf(OrderStatus.READY_FOR_PICKUP, OrderStatus.CANCELLED)
            OrderStatus.READY_FOR_PICKUP -> newStatus in listOf(OrderStatus.DELIVERY_PARTNER_ASSIGNED, OrderStatus.PICKED_UP, OrderStatus.CANCELLED)
            OrderStatus.DELIVERY_PARTNER_ASSIGNED -> newStatus in listOf(OrderStatus.PICKED_UP, OrderStatus.CANCELLED)
            OrderStatus.PICKED_UP -> newStatus in listOf(OrderStatus.ON_THE_WAY, OrderStatus.FAILED)
            OrderStatus.ON_THE_WAY -> newStatus in listOf(OrderStatus.DELIVERED, OrderStatus.FAILED)
            OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.REJECTED, OrderStatus.FAILED -> false
            else -> true
        }

        if (!allowed && newStatus != OrderStatus.CANCELLED) {
            return false
        }

        val updatedHistory = order.statusHistory + OrderStatusEntry(newStatus, System.currentTimeMillis(), note)

        var coinsAwarded = order.coinsAwarded
        var coinsEarned = order.coinsEarned

        if (newStatus == OrderStatus.DELIVERED && !order.coinsAwarded) {
            coinsEarned = calculateEarnedCoins(order.subtotal)
            if (coinsEarned > 0) {
                _coinBalance.value += coinsEarned
                val tx = CoinTransaction(
                    id = "TX-" + UUID.randomUUID().toString().take(6),
                    orderId = order.id,
                    amount = coinsEarned,
                    type = "EARNED",
                    description = "Earned $coinsEarned coins (${_coinsPerHundredConfig.value} per ₹100) on order #${order.id}"
                )
                _coinTransactions.value = listOf(tx) + _coinTransactions.value
            }
            coinsAwarded = true

            order.assignedDeliveryPartnerId?.let { dpId ->
                val dps = _deliveryPartners.value.toMutableList()
                val dpIdx = dps.indexOfFirst { it.id == dpId }
                if (dpIdx != -1) {
                    val p = dps[dpIdx]
                    dps[dpIdx] = p.copy(
                        totalDeliveries = p.totalDeliveries + 1,
                        baseEarnings = p.baseEarnings + order.deliveryPartnerEarnings,
                        tipsEarned = p.tipsEarned + order.tipAmount,
                        activeOrderId = null
                    )
                    _deliveryPartners.value = dps
                }
            }
        }

        val updatedPaymentStatus = if (newStatus == OrderStatus.DELIVERED && order.paymentMethod == PaymentMethod.COD) {
            PaymentStatus.SUCCESSFUL
        } else {
            order.paymentStatus
        }

        val updatedOrder = order.copy(
            orderStatus = newStatus,
            paymentStatus = updatedPaymentStatus,
            statusHistory = updatedHistory,
            coinsAwarded = coinsAwarded,
            coinsEarned = coinsEarned
        )

        currentOrders[index] = updatedOrder
        _orders.value = currentOrders
        return true
    }

    // ORDER ASSIGNMENT & REASSIGNMENT BY ADMIN
    fun assignDeliveryPartner(orderId: String, partnerId: String): Boolean {
        val currentOrders = _orders.value.toMutableList()
        val orderIndex = currentOrders.indexOfFirst { it.id == orderId }
        val partner = _deliveryPartners.value.find { it.id == partnerId }

        if (orderIndex == -1 || partner == null) return false

        val order = currentOrders[orderIndex]
        val oldPartnerId = order.assignedDeliveryPartnerId

        // If reassigning, clear previous partner active order
        if (oldPartnerId != null && oldPartnerId != partnerId) {
            val dps = _deliveryPartners.value.toMutableList()
            val oldIdx = dps.indexOfFirst { it.id == oldPartnerId }
            if (oldIdx != -1) {
                dps[oldIdx] = dps[oldIdx].copy(activeOrderId = null)
                _deliveryPartners.value = dps
            }
        }

        val isReassign = oldPartnerId != null
        val actionText = if (isReassign) "Reassigned" else "Assigned"

        val updatedOrder = order.copy(
            assignedDeliveryPartnerId = partner.id,
            assignedDeliveryPartnerName = "${partner.name} (${partner.code})",
            assignedDeliveryPartnerPhone = partner.phone,
            assignedDeliveryPartnerOnline = partner.isOnline,
            partnerOfflineAlert = !partner.isOnline,
            orderStatus = if (order.orderStatus == OrderStatus.READY_FOR_PICKUP) OrderStatus.DELIVERY_PARTNER_ASSIGNED else order.orderStatus,
            statusHistory = order.statusHistory + OrderStatusEntry(
                OrderStatus.DELIVERY_PARTNER_ASSIGNED,
                System.currentTimeMillis(),
                "$actionText to ${partner.name} (${partner.code})"
            )
        )
        currentOrders[orderIndex] = updatedOrder
        _orders.value = currentOrders

        // Update new partner active order
        val dps = _deliveryPartners.value.toMutableList()
        val dpIndex = dps.indexOfFirst { it.id == partnerId }
        if (dpIndex != -1) {
            dps[dpIndex] = dps[dpIndex].copy(activeOrderId = orderId)
            _deliveryPartners.value = dps
        }

        // Dispatch alert notification to assigned delivery partner
        val dpNotif = AppNotification(
            id = "NOTIF-" + UUID.randomUUID().toString().take(6).uppercase(),
            recipientRole = UserRole.DELIVERY_PARTNER,
            recipientEntityId = partner.id,
            title = "New Order Assigned! (#$orderId)",
            message = "Pickup: ${order.restaurantName} • Deliver: ${order.deliveryAddress} • Earnings: ₹${order.deliveryPartnerEarnings}",
            orderId = orderId
        )
        postNotification(dpNotif)

        recordAuditLog(
            if (isReassign) "REASSIGN_DELIVERY_PARTNER" else "ASSIGN_DELIVERY_PARTNER",
            "ORDER",
            orderId,
            "$actionText partner ${partner.name} (${partner.code})"
        )
        return true
    }

    fun updateDeliveryPartnerStatus(orderId: String, newStatus: OrderStatus): Boolean {
        return updateOrderStatus(orderId, newStatus, "Updated by delivery partner")
    }

    // ONLINE / OFFLINE TOGGLE FOR DELIVERY PARTNER
    // If a delivery partner goes offline during an active delivery, do not silently cancel; alert admin and preserve assignment!
    fun toggleDeliveryPartnerAvailability(partnerId: String) {
        val dps = _deliveryPartners.value.toMutableList()
        val idx = dps.indexOfFirst { it.id == partnerId }
        if (idx != -1) {
            val newOnline = !dps[idx].isOnline
            dps[idx] = dps[idx].copy(
                isOnline = newOnline,
                lastStatusUpdatedAt = System.currentTimeMillis()
            )
            _deliveryPartners.value = dps

            // Check if partner has an active ongoing delivery
            val activeOrder = _orders.value.find {
                it.assignedDeliveryPartnerId == partnerId &&
                        it.orderStatus !in listOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.FAILED, OrderStatus.REJECTED)
            }

            if (activeOrder != null) {
                val orderList = _orders.value.toMutableList()
                val ordIdx = orderList.indexOfFirst { it.id == activeOrder.id }
                if (ordIdx != -1) {
                    orderList[ordIdx] = orderList[ordIdx].copy(
                        assignedDeliveryPartnerOnline = newOnline,
                        partnerOfflineAlert = !newOnline // alert flag raised if gone offline during delivery
                    )
                    _orders.value = orderList
                }
                recordAuditLog(
                    "PARTNER_STATUS_ALERT",
                    "ORDER",
                    activeOrder.id,
                    "Partner ${dps[idx].name} toggled ${if (newOnline) "ONLINE" else "OFFLINE"} during active delivery #${activeOrder.id}"
                )
            }

            recordAuditLog(
                "PARTNER_AVAILABILITY",
                "DELIVERY_PARTNER",
                partnerId,
                "Toggled duty status to: ${if (newOnline) "ONLINE" else "OFFLINE"}"
            )
        }
    }

    // ONLINE / OFFLINE TOGGLE FOR RESTAURANT PARTNER
    fun toggleRestaurantStatus(restaurantId: String) {
        val rests = _restaurants.value.toMutableList()
        val idx = rests.indexOfFirst { it.id == restaurantId }
        if (idx != -1) {
            val newOpen = !rests[idx].isOpen
            rests[idx] = rests[idx].copy(
                isOpen = newOpen,
                lastStatusUpdatedAt = System.currentTimeMillis()
            )
            _restaurants.value = rests
            recordAuditLog(
                "RESTAURANT_AVAILABILITY",
                "RESTAURANT",
                restaurantId,
                "Toggled operational status to: ${if (newOpen) "ONLINE (Open)" else "OFFLINE (Closed)"}"
            )
        }
    }

    fun updatePartnerOnlineStatus(partnerId: String, isOnline: Boolean) {
        val dps = _deliveryPartners.value
        val partner = dps.find { it.id == partnerId }
        if (partner != null && partner.isOnline != isOnline) {
            toggleDeliveryPartnerAvailability(partnerId)
        }
    }

    fun updateRestaurantOnlineStatus(restaurantId: String, isOpen: Boolean) {
        val rests = _restaurants.value
        val restaurant = rests.find { it.id == restaurantId }
        if (restaurant != null && restaurant.isOpen != isOpen) {
            toggleRestaurantStatus(restaurantId)
        }
    }

    // RESTAURANT MANAGEMENT (Admin)
    fun provisionRestaurantPartner(
        name: String,
        email: String,
        phone: String,
        cuisine: String,
        address: String,
        openingHours: String = "10:00 AM - 11:00 PM",
        initialPassword: String = "rest2026",
        mustChangePassword: Boolean = false // Default false to prevent unwanted prompts
    ): Restaurant {
        val restId = "REST-" + UUID.randomUUID().toString().take(4).uppercase()
        val newRest = Restaurant(
            id = restId,
            name = name.trim(),
            cuisine = cuisine.trim(),
            address = address.trim(),
            lat = 28.6139,
            lng = 77.2090,
            rating = 5.0,
            ratingCount = 0,
            isOpen = true,
            phone = normalizePhone(phone),
            email = normalizeEmail(email),
            bannerEmoji = "🍽️",
            openingHours = openingHours.trim(),
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis()
        )
        _restaurants.value = _restaurants.value + newRest

        val user = UserAccount(
            id = "USER-" + UUID.randomUUID().toString().take(6),
            email = normalizeEmail(email),
            name = name.trim(),
            phone = normalizePhone(phone),
            role = UserRole.RESTAURANT,
            passwordHash = initialPassword.trim(),
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = restId,
            mustChangePassword = mustChangePassword
        )
        _users.value = _users.value + user
        recordAuditLog("CREATE_RESTAURANT", "RESTAURANT", restId, "Created restaurant $name ($email)")
        return newRest
    }

    fun updateRestaurant(
        id: String,
        name: String,
        cuisine: String,
        address: String,
        phone: String,
        email: String,
        openingHours: String
    ): Result<Restaurant> {
        val rests = _restaurants.value.toMutableList()
        val idx = rests.indexOfFirst { it.id == id }
        if (idx == -1) return Result.failure(IllegalArgumentException("Restaurant not found"))

        val existing = rests[idx]
        val updated = existing.copy(
            name = name.trim(),
            cuisine = cuisine.trim(),
            address = address.trim(),
            phone = normalizePhone(phone),
            email = normalizeEmail(email),
            openingHours = openingHours.trim()
        )
        rests[idx] = updated
        _restaurants.value = rests

        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == id }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(
                name = name.trim(),
                email = normalizeEmail(email),
                phone = normalizePhone(phone)
            )
            _users.value = userList
        }

        recordAuditLog("UPDATE_RESTAURANT", "RESTAURANT", id, "Updated details for $name")
        return Result.success(updated)
    }

    fun setRestaurantStatus(id: String, status: String): Boolean {
        val rests = _restaurants.value.toMutableList()
        val idx = rests.indexOfFirst { it.id == id }
        if (idx == -1) return false

        val isActive = status == "ACTIVE"
        rests[idx] = rests[idx].copy(
            status = status,
            isOpen = if (!isActive) false else rests[idx].isOpen,
            lastStatusUpdatedAt = System.currentTimeMillis()
        )
        _restaurants.value = rests

        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == id }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(isActive = isActive, status = status)
            _users.value = userList
        }

        recordAuditLog("SET_RESTAURANT_STATUS", "RESTAURANT", id, "Status updated to $status")
        return true
    }

    fun resetRestaurantPassword(restaurantId: String, newTempPassword: String): String {
        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == restaurantId }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(
                passwordHash = newTempPassword.trim(),
                mustChangePassword = false
            )
            _users.value = userList
            recordAuditLog("RESET_PASSWORD", "RESTAURANT_USER", userList[userIdx].id, "Password reset by admin")
            return newTempPassword
        }
        return ""
    }

    // DELIVERY PARTNER MANAGEMENT (Admin)
    fun provisionDeliveryPartner(
        name: String,
        email: String,
        phone: String,
        address: String,
        vehicleType: String,
        initialPassword: String = "partner2026",
        mustChangePassword: Boolean = false // Default false to prevent unwanted prompts
    ): DeliveryPartner {
        val dpId = "DP-" + UUID.randomUUID().toString().take(4).uppercase()
        val code = "DP-" + (100 + _deliveryPartners.value.size + 1)
        val partner = DeliveryPartner(
            id = dpId,
            code = code,
            name = name.trim(),
            phone = normalizePhone(phone),
            email = normalizeEmail(email),
            address = address.trim(),
            vehicleType = vehicleType.trim(),
            isOnline = true,
            status = "ACTIVE",
            lastStatusUpdatedAt = System.currentTimeMillis(),
            totalDeliveries = 0,
            baseEarnings = 0,
            tipsEarned = 0,
            rating = 5.0
        )
        _deliveryPartners.value = _deliveryPartners.value + partner

        val user = UserAccount(
            id = "USER-" + UUID.randomUUID().toString().take(6),
            email = normalizeEmail(email),
            name = name.trim(),
            phone = normalizePhone(phone),
            role = UserRole.DELIVERY_PARTNER,
            passwordHash = initialPassword.trim(),
            isActive = true,
            status = "ACTIVE",
            assignedEntityId = dpId,
            mustChangePassword = mustChangePassword
        )
        _users.value = _users.value + user
        recordAuditLog("CREATE_DELIVERY_PARTNER", "DELIVERY_PARTNER", dpId, "Created partner $name ($code)")
        return partner
    }

    fun updateDeliveryPartner(
        id: String,
        name: String,
        email: String,
        phone: String,
        address: String,
        vehicleType: String
    ): Result<DeliveryPartner> {
        val dps = _deliveryPartners.value.toMutableList()
        val idx = dps.indexOfFirst { it.id == id }
        if (idx == -1) return Result.failure(IllegalArgumentException("Partner not found"))

        val existing = dps[idx]
        val updated = existing.copy(
            name = name.trim(),
            email = normalizeEmail(email),
            phone = normalizePhone(phone),
            address = address.trim(),
            vehicleType = vehicleType.trim()
        )
        dps[idx] = updated
        _deliveryPartners.value = dps

        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == id }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(
                name = name.trim(),
                email = normalizeEmail(email),
                phone = normalizePhone(phone)
            )
            _users.value = userList
        }

        recordAuditLog("UPDATE_DELIVERY_PARTNER", "DELIVERY_PARTNER", id, "Updated details for $name")
        return Result.success(updated)
    }

    fun setDeliveryPartnerStatus(id: String, status: String): Boolean {
        val dps = _deliveryPartners.value.toMutableList()
        val idx = dps.indexOfFirst { it.id == id }
        if (idx == -1) return false

        val isActive = status == "ACTIVE"
        dps[idx] = dps[idx].copy(
            status = status,
            isOnline = if (!isActive) false else dps[idx].isOnline,
            lastStatusUpdatedAt = System.currentTimeMillis()
        )
        _deliveryPartners.value = dps

        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == id }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(isActive = isActive, status = status)
            _users.value = userList
        }

        recordAuditLog("SET_DELIVERY_PARTNER_STATUS", "DELIVERY_PARTNER", id, "Status updated to $status")
        return true
    }

    fun resetDeliveryPartnerPassword(dpId: String, newTempPassword: String): String {
        val userList = _users.value.toMutableList()
        val userIdx = userList.indexOfFirst { it.assignedEntityId == dpId }
        if (userIdx != -1) {
            userList[userIdx] = userList[userIdx].copy(
                passwordHash = newTempPassword.trim(),
                mustChangePassword = false
            )
            _users.value = userList
            recordAuditLog("RESET_PASSWORD", "DELIVERY_USER", userList[userIdx].id, "Password reset by admin")
            return newTempPassword
        }
        return ""
    }

    // Customer Account Management (Admin)
    fun setCustomerStatus(customerId: String, status: String): Boolean {
        val userList = _users.value.toMutableList()
        val idx = userList.indexOfFirst { it.id == customerId }
        if (idx == -1) return false

        val isActive = status == "ACTIVE"
        userList[idx] = userList[idx].copy(isActive = isActive, status = status)
        _users.value = userList
        recordAuditLog("SET_CUSTOMER_STATUS", "CUSTOMER", customerId, "Status updated to $status")
        return true
    }

    // AUTHENTICATION & LOGIN
    fun login(identifier: String, password: String, targetRole: UserRole): UserAccount? {
        val res = authenticate(identifier, password, targetRole)
        return if (res is LoginResult.Success) res.user else null
    }

    fun authenticate(identifier: String, password: String, expectedRole: UserRole): LoginResult {
        val trimmedId = identifier.trim()
        val trimmedPass = password.trim()

        if (trimmedId.isBlank() || trimmedPass.isBlank()) {
            return LoginResult.InvalidCredentials("Please enter both login identifier and password.")
        }

        val isEmail = trimmedId.contains("@")
        val normEmail = if (isEmail) normalizeEmail(trimmedId) else ""
        val normPhone = if (!isEmail) normalizePhone(trimmedId) else ""

        val found = _users.value.find { user ->
            val matchId = if (isEmail) {
                normalizeEmail(user.email) == normEmail
            } else {
                normalizePhone(user.phone) == normPhone || user.phone == trimmedId
            }
            matchId && user.role == expectedRole
        }

        if (found == null) {
            return LoginResult.InvalidCredentials("Invalid email/mobile or credentials for ${expectedRole.name}.")
        }

        if (found.passwordHash != trimmedPass) {
            return LoginResult.InvalidCredentials("Incorrect password. Please verify and try again.")
        }

        if (!found.isActive || found.status != "ACTIVE") {
            return LoginResult.AccountBlocked("Account is suspended or deactivated by administrator.")
        }

        // Restaurant and Delivery Partner authenticate directly into their portals
        if (found.mustChangePassword && found.role != UserRole.RESTAURANT && found.role != UserRole.DELIVERY_PARTNER) {
            return LoginResult.MustChangePassword(found)
        }

        _currentUser.value = found
        return LoginResult.Success(found)
    }

    fun changeUserPassword(userId: String, newPassword: String): Result<Boolean> {
        if (newPassword.trim().length < 6) {
            return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val userList = _users.value.toMutableList()
        val idx = userList.indexOfFirst { it.id == userId }
        if (idx == -1) return Result.failure(IllegalArgumentException("User not found"))

        val updated = userList[idx].copy(
            passwordHash = newPassword.trim(),
            mustChangePassword = false
        )
        userList[idx] = updated
        _users.value = userList
        _currentUser.value = updated
        recordAuditLog("PASSWORD_CHANGED", "USER", userId, "User updated password")
        return Result.success(true)
    }

    fun recoverCustomerPassword(identifier: String, newPassword: String): Result<String> {
        if (newPassword.trim().length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }
        val trimmedId = identifier.trim()
        val isEmail = trimmedId.contains("@")
        val normEmail = if (isEmail) normalizeEmail(trimmedId) else ""
        val normPhone = if (!isEmail) normalizePhone(trimmedId) else ""

        val userList = _users.value.toMutableList()
        val idx = userList.indexOfFirst { user ->
            user.role == UserRole.CUSTOMER && if (isEmail) {
                normalizeEmail(user.email) == normEmail
            } else {
                normalizePhone(user.phone) == normPhone
            }
        }

        if (idx == -1) {
            return Result.failure(IllegalArgumentException("If this account exists, recovery instructions have been initiated."))
        }

        userList[idx] = userList[idx].copy(passwordHash = newPassword.trim(), mustChangePassword = false)
        _users.value = userList
        recordAuditLog("CUSTOMER_PASSWORD_RECOVERED", "CUSTOMER", userList[idx].id, "Password reset via verified recovery flow")
        return Result.success("Password recovered successfully! Please login with your new password.")
    }

    fun registerCustomer(name: String, email: String, phone: String, passwordHash: String): UserAccount {
        val newUser = UserAccount(
            id = "CUST-" + UUID.randomUUID().toString().take(6).uppercase(),
            email = normalizeEmail(email),
            name = name.trim(),
            phone = normalizePhone(phone),
            role = UserRole.CUSTOMER,
            passwordHash = passwordHash.trim(),
            isActive = true,
            status = "ACTIVE",
            mustChangePassword = false
        )
        _users.value = _users.value + newUser
        _currentUser.value = newUser
        return newUser
    }

    fun logout() {
        _currentUser.value = null
    }

    // Menu Item Operations
    fun addMenuItem(
        restaurantId: String,
        name: String,
        description: String,
        category: String,
        originalPrice: Int,
        isVeg: Boolean,
        imageUrl: String = ""
    ): MenuItem {
        val newItem = MenuItem(
            id = "MENU-" + UUID.randomUUID().toString().take(6).uppercase(),
            restaurantId = restaurantId,
            name = name,
            description = description,
            category = category,
            originalPrice = originalPrice,
            markupAmount = 20,
            isAvailable = true,
            isVeg = isVeg,
            imageUrl = imageUrl
        )
        _menuItems.value = _menuItems.value + newItem
        return newItem
    }

    fun toggleMenuItemStock(itemId: String) {
        val items = _menuItems.value.toMutableList()
        val idx = items.indexOfFirst { it.id == itemId }
        if (idx != -1) {
            items[idx] = items[idx].copy(isAvailable = !items[idx].isAvailable)
            _menuItems.value = items
        }
    }

    fun deleteMenuItem(itemId: String) {
        _menuItems.value = _menuItems.value.filterNot { it.id == itemId }
    }

    // Support Tickets & Fee Discounts
    fun createDeliveryFeeDiscountRequest(
        customerId: String,
        customerName: String,
        reason: String,
        currentFee: Int,
        requestedAmount: Int = 20
    ): SupportTicket {
        val ticketId = "DISC-" + UUID.randomUUID().toString().take(6).uppercase()
        val ticket = SupportTicket(
            id = ticketId,
            customerId = customerId,
            customerName = customerName,
            category = "DELIVERY_FEE_DISCOUNT",
            reason = reason,
            requestedDiscount = minOf(requestedAmount, currentFee),
            status = "PENDING",
            messages = listOf(
                TicketMessage(
                    senderId = customerId,
                    senderName = customerName,
                    senderRole = UserRole.CUSTOMER,
                    message = "Requested delivery fee discount of ₹$requestedAmount for reason: $reason"
                )
            )
        )
        _supportTickets.value = listOf(ticket) + _supportTickets.value
        return ticket
    }

    fun adminReviewDiscountRequest(ticketId: String, approve: Boolean, discountGranted: Int = 20, adminEmail: String = "admin@expressfood.in"): Boolean {
        val tickets = _supportTickets.value.toMutableList()
        val idx = tickets.indexOfFirst { it.id == ticketId }
        if (idx == -1) return false

        val ticket = tickets[idx]
        val status = if (approve) "APPROVED" else "REJECTED"
        val granted = if (approve) discountGranted else 0

        val reply = if (approve) {
            "Admin approved delivery fee discount of ₹$granted."
        } else {
            "Admin declined delivery fee discount request."
        }

        tickets[idx] = ticket.copy(
            status = status,
            approvedDiscount = granted,
            approvedBy = adminEmail,
            approvedAt = System.currentTimeMillis(),
            messages = ticket.messages + TicketMessage(
                senderId = "ADMIN-001",
                senderName = "Express Admin",
                senderRole = UserRole.ADMIN,
                message = reply
            )
        )
        _supportTickets.value = tickets

        if (approve) {
            _activeFeeDiscount.value = granted
            _activeDiscountTicketId.value = ticketId
        }

        recordAuditLog("REVIEW_DISCOUNT", "TICKET", ticketId, "Status: $status, Discount: ₹$granted by $adminEmail")
        return true
    }

    fun createSupportTicket(
        customerId: String,
        customerName: String,
        category: String,
        reason: String,
        orderId: String? = null
    ): SupportTicket {
        val ticketId = "TKT-" + UUID.randomUUID().toString().take(6).uppercase()
        val ticket = SupportTicket(
            id = ticketId,
            customerId = customerId,
            customerName = customerName,
            orderId = orderId,
            category = category,
            reason = reason,
            status = "PENDING",
            messages = listOf(
                TicketMessage(
                    senderId = customerId,
                    senderName = customerName,
                    senderRole = UserRole.CUSTOMER,
                    message = reason
                )
            )
        )
        _supportTickets.value = listOf(ticket) + _supportTickets.value
        return ticket
    }

    fun replyToTicket(ticketId: String, senderId: String, senderName: String, role: UserRole, message: String) {
        val tickets = _supportTickets.value.toMutableList()
        val idx = tickets.indexOfFirst { it.id == ticketId }
        if (idx != -1) {
            val t = tickets[idx]
            tickets[idx] = t.copy(
                messages = t.messages + TicketMessage(senderId, senderName, role, message)
            )
            _supportTickets.value = tickets
        }
    }

    fun submitRating(
        orderId: String,
        customerId: String,
        customerName: String,
        targetType: String,
        targetId: String,
        stars: Int,
        comment: String
    ): Boolean {
        val existing = _ratings.value.find { it.orderId == orderId && it.targetType == targetType && it.targetId == targetId }
        if (existing != null) return false

        val rating = RatingReview(
            id = "REV-" + UUID.randomUUID().toString().take(6).uppercase(),
            orderId = orderId,
            customerId = customerId,
            customerName = customerName,
            targetType = targetType,
            targetId = targetId,
            stars = stars.coerceIn(1, 5),
            comment = comment
        )
        _ratings.value = listOf(rating) + _ratings.value
        return true
    }

    fun recordAuditLog(action: String, targetType: String, targetId: String, details: String) {
        val log = AuditLog(
            id = "LOG-" + UUID.randomUUID().toString().take(6).uppercase(),
            adminEmail = _currentUser.value?.email ?: "admin@expressfood.in",
            action = action,
            targetType = targetType,
            targetId = targetId,
            details = details,
            timestamp = System.currentTimeMillis()
        )
        _auditLogs.value = listOf(log) + _auditLogs.value
    }
}
