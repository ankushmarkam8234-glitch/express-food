package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ExpressRepository
import com.example.localization.AppStrings
import com.example.model.*
import com.example.ui.components.ExpressTopBar
import com.example.ui.components.PriceBreakdownCard
import com.example.ui.components.DirectCallButton
import com.example.ui.components.DialPhoneIconButton
import com.example.ui.theme.*

@Composable
fun CustomerMainScreen(
    onLogout: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val cart by ExpressRepository.cart.collectAsState()
    val orders by ExpressRepository.orders.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Discover, 1: Cart, 2: Orders, 3: Wallet, 4: Support
    var selectedRestaurantId by remember { mutableStateOf<String?>(null) }
    var activeTrackingOrderId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            ExpressTopBar(
                title = AppStrings.t("app_title", currentLang),
                currentRole = UserRole.CUSTOMER,
                onLogout = onLogout,
                onBack = if (selectedRestaurantId != null || activeTrackingOrderId != null) {
                    {
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    }
                } else null
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0 && selectedRestaurantId == null && activeTrackingOrderId == null,
                    onClick = {
                        selectedTab = 0
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    },
                    icon = { Icon(Icons.Default.Restaurant, contentDescription = "Discover") },
                    label = { Text(AppStrings.t("nav_home", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_customer_discover")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (cart.isNotEmpty()) {
                                    Badge { Text("${cart.sumOf { it.quantity }}") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                        }
                    },
                    label = { Text(AppStrings.t("nav_cart", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_customer_cart")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = {
                        selectedTab = 2
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    },
                    icon = { Icon(Icons.AutoMirrored.Filled.ReceiptLong, contentDescription = "Orders") },
                    label = { Text(AppStrings.t("nav_orders", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_customer_orders")
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = {
                        selectedTab = 3
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    },
                    icon = { Icon(Icons.Default.MonetizationOn, contentDescription = "Wallet") },
                    label = { Text(AppStrings.t("nav_wallet", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_customer_wallet")
                )

                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = {
                        selectedTab = 4
                        selectedRestaurantId = null
                        activeTrackingOrderId = null
                    },
                    icon = { Icon(Icons.Default.SupportAgent, contentDescription = "Support") },
                    label = { Text(AppStrings.t("nav_support", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_customer_support")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when {
                activeTrackingOrderId != null -> {
                    val order = orders.find { it.id == activeTrackingOrderId }
                    if (order != null) {
                        OrderTrackingScreen(
                            order = order,
                            onBack = { activeTrackingOrderId = null }
                        )
                    } else {
                        activeTrackingOrderId = null
                    }
                }

                selectedRestaurantId != null -> {
                    RestaurantDetailScreen(
                        restaurantId = selectedRestaurantId!!,
                        onBack = { selectedRestaurantId = null },
                        onGoToCart = {
                            selectedRestaurantId = null
                            selectedTab = 1
                        }
                    )
                }

                selectedTab == 0 -> {
                    CustomerDiscoverScreen(
                        onSelectRestaurant = { restId -> selectedRestaurantId = restId }
                    )
                }

                selectedTab == 1 -> {
                    CustomerCartScreen(
                        onOrderPlaced = { orderId ->
                            activeTrackingOrderId = orderId
                        }
                    )
                }

                selectedTab == 2 -> {
                    CustomerOrdersListScreen(
                        onTrackOrder = { orderId -> activeTrackingOrderId = orderId }
                    )
                }

                selectedTab == 3 -> {
                    CustomerWalletScreen()
                }

                selectedTab == 4 -> {
                    CustomerSupportScreen()
                }
            }
        }
    }
}

@Composable
fun CustomerDiscoverScreen(
    onSelectRestaurant: (String) -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val restaurants by ExpressRepository.restaurants.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "North Indian", "South Indian", "Biryani", "Desserts", "Beverages")

    val filteredRestaurants = remember(restaurants, searchQuery, selectedCategory) {
        restaurants.filter { rest ->
            val matchQuery = searchQuery.isBlank() ||
                    rest.name.contains(searchQuery, ignoreCase = true) ||
                    rest.cuisine.contains(searchQuery, ignoreCase = true)
            val matchCat = selectedCategory == "All" || rest.cuisine.contains(selectedCategory, ignoreCase = true)
            matchQuery && matchCat
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome banner
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ExpressRed,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🇮🇳 Express Food India",
                            color = PureWhite,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹20 flat platform fee per dish transparently included. Fastest delivery in your city!",
                            color = PureWhite.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                    Text(text = "🛵", fontSize = 40.sp)
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_restaurants"),
                placeholder = { Text(AppStrings.t("search", currentLang)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }

        // Categories
        item {
            Column {
                Text(
                    text = AppStrings.t("categories", currentLang),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        val isSelected = cat == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ExpressRed,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = AppStrings.t("featured_restaurants", currentLang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        items(filteredRestaurants) { rest ->
            RestaurantCard(
                restaurant = rest,
                onClick = { onSelectRestaurant(rest.id) }
            )
        }
    }
}

@Composable
fun RestaurantCard(
    restaurant: Restaurant,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("restaurant_card_${restaurant.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(ExpressRedLight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = restaurant.bannerEmoji, fontSize = 54.sp)
                Surface(
                    shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp),
                    color = if (restaurant.isOpen) FreshGreen else Color.Gray,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Text(
                        text = if (restaurant.isOpen) "Open Now" else "Closed",
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = restaurant.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = FreshGreen
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "★ ${restaurant.rating}",
                                color = PureWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = restaurant.cuisine,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = ExpressRed
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = restaurant.address,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun RestaurantDetailScreen(
    restaurantId: String,
    onBack: () -> Unit,
    onGoToCart: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val restaurants by ExpressRepository.restaurants.collectAsState()
    val allMenuItems by ExpressRepository.menuItems.collectAsState()
    val cart by ExpressRepository.cart.collectAsState()

    val restaurant = restaurants.find { it.id == restaurantId } ?: return
    val items = allMenuItems.filter { it.restaurantId == restaurantId }

    Scaffold(
        bottomBar = {
            if (cart.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${cart.sumOf { it.quantity }} items in cart",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Subtotal: ₹${cart.sumOf { it.itemSubtotal }}",
                                color = ExpressRed,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }
                        Button(
                            onClick = onGoToCart,
                            colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_view_cart_floating")
                        ) {
                            Text(AppStrings.t("nav_cart", currentLang), color = PureWhite, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = PureWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = restaurant.name,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = restaurant.cuisine, fontWeight = FontWeight.SemiBold)
                        Text(text = "📍 " + restaurant.address, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text(text = "🕒 " + restaurant.openingHours, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ExpressRedLight
                        ) {
                            Text(
                                text = "Transparent Pricing: Every dish has restaurant's original price + ₹20 platform fee. No hidden markups!",
                                fontSize = 11.sp,
                                color = ExpressRedDark,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Menu Items",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            items(items) { item ->
                MenuItemRow(
                    item = item,
                    cartQuantity = cart.find { it.menuItem.id == item.id }?.quantity ?: 0,
                    onAddToCart = { ExpressRepository.addToCart(item) },
                    onUpdateQuantity = { q -> ExpressRepository.updateCartQuantity(item.id, q) }
                )
            }
        }
    }
}

@Composable
fun MenuItemRow(
    item: MenuItem,
    cartQuantity: Int,
    onAddToCart: () -> Unit,
    onUpdateQuantity: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (item.isVeg) FreshGreenLight else ExpressRedLight
                    ) {
                        Text(
                            text = if (item.isVeg) "🟢 VEG" else "🔴 NON-VEG",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (item.isVeg) FreshGreen else ExpressRedDark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.category,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Price display showing customer price and breakdown
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "₹${item.customerPrice}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(Orig: ₹${item.originalPrice} + ₹${item.markupAmount})",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Food Photo & Add / Quantity controls column
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (item.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(76.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                if (cartQuantity == 0) {
                    Button(
                        onClick = onAddToCart,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                        modifier = Modifier.testTag("btn_add_item_${item.id}")
                    ) {
                        Text("ADD", fontWeight = FontWeight.Bold, color = PureWhite)
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ExpressRedLight)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        IconButton(
                            onClick = { onUpdateQuantity(cartQuantity - 1) },
                            modifier = Modifier.size(32.dp).testTag("btn_minus_${item.id}")
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = ExpressRed, modifier = Modifier.size(16.dp))
                        }
                        Text(
                            text = "$cartQuantity",
                            fontWeight = FontWeight.Bold,
                            color = ExpressRed,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(
                            onClick = { onUpdateQuantity(cartQuantity + 1) },
                            modifier = Modifier.size(32.dp).testTag("btn_plus_${item.id}")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase", tint = ExpressRed, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerCartScreen(
    onOrderPlaced: (String) -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val cart by ExpressRepository.cart.collectAsState()
    val coinBalance by ExpressRepository.coinBalance.collectAsState()
    val activeFeeDiscount by ExpressRepository.activeFeeDiscount.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()
    val restaurants by ExpressRepository.restaurants.collectAsState()
    val savedLocations by ExpressRepository.savedLocations.collectAsState()

    val currentRestaurant = remember(cart, restaurants) {
        val rId = cart.firstOrNull()?.menuItem?.restaurantId
        restaurants.find { it.id == rId } ?: restaurants.firstOrNull()
    }

    var selectedLocIdx by remember { mutableStateOf(0) }
    var customerAddress by remember { mutableStateOf("Flat 402, Sunshine Heights, Connaught Place, New Delhi") }
    var customerLat by remember { mutableStateOf(28.6328) }
    var customerLng by remember { mutableStateOf(77.2197) }
    var manualSliderKm by remember { mutableStateOf<Double?>(null) }

    val calculatedAutoDistance = remember(currentRestaurant, customerLat, customerLng) {
        if (currentRestaurant != null) {
            ExpressRepository.calculateCoordinateDistance(
                currentRestaurant.lat,
                currentRestaurant.lng,
                customerLat,
                customerLng
            )
        } else {
            2.5
        }
    }

    val distanceKm = manualSliderKm ?: calculatedAutoDistance

    var selectedTip by remember { mutableStateOf(10) }
    var customTipInput by remember { mutableStateOf("") }
    var isCustomTip by remember { mutableStateOf(false) }
    var coinsToRedeem by remember { mutableStateOf(0) }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.COD) }
    var isEmergencyConfirmed by remember { mutableStateOf(false) }

    var showDiscountDialog by remember { mutableStateOf(false) }
    var discountReason by remember { mutableStateOf("") }
    var placeOrderError by remember { mutableStateOf<String?>(null) }
    var isPlacingOrder by remember { mutableStateOf(false) }

    val tip = if (isCustomTip) customTipInput.toIntOrNull() ?: 0 else selectedTip
    val feeResult = ExpressRepository.calculateDeliveryFee(distanceKm, isEmergencyConfirmed)

    val calc = ExpressRepository.calculatePrice(
        cartItems = cart,
        distanceKm = distanceKm,
        tipAmount = tip,
        coinsToRedeem = coinsToRedeem,
        feeDiscount = activeFeeDiscount,
        isEmergency = isEmergencyConfirmed
    )

    if (cart.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "🛒", fontSize = 64.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = AppStrings.t("empty_cart", currentLang),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = AppStrings.t("nav_cart", currentLang),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        // Cart items
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                cart.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.menuItem.name,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "₹${item.menuItem.customerPrice} × ${item.quantity}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { ExpressRepository.updateCartQuantity(item.menuItem.id, item.quantity - 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                            Text(
                                text = "${item.quantity}",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp)
                            )
                            IconButton(
                                onClick = { ExpressRepository.updateCartQuantity(item.menuItem.id, item.quantity + 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "₹${item.itemSubtotal}",
                                fontWeight = FontWeight.Bold,
                                color = ExpressRed
                            )
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }

        // Delivery Address with Saved Map Locations
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Delivery Location & Map Coordinates",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Select a saved GPS pin or enter an address for automatic distance calculation.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(savedLocations) { loc ->
                        val isSelected = customerAddress == loc.fullAddress
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                customerAddress = loc.fullAddress
                                customerLat = loc.lat
                                customerLng = loc.lng
                                manualSliderKm = null // return to automatic coordinate distance
                            },
                            label = { Text(loc.title, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customerAddress,
                    onValueChange = {
                        customerAddress = it
                        selectedLocIdx = -1
                    },
                    label = { Text("Delivery Address") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_delivery_address"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "📍 Pin GPS: Lat $customerLat, Lng $customerLng",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }

        // Automatic Distance & Exact Delivery Fee Schedule
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Straight-Line Distance (GPS Coordinates)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        if (currentRestaurant != null) {
                            Text(
                                text = "From: ${currentRestaurant.name} (${currentRestaurant.lat}, ${currentRestaurant.lng})",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                    Text(
                        text = "%.1f km".format(distanceKm),
                        fontWeight = FontWeight.ExtraBold,
                        color = ExpressRed,
                        fontSize = 16.sp
                    )
                }

                Text(
                    text = "Note: Straight-line coordinate distance applied. Road routing provider activates automatically when configured.",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Slider(
                    value = distanceKm.toFloat(),
                    onValueChange = { manualSliderKm = it.toDouble() },
                    valueRange = 0.5f..14.0f,
                    steps = 26,
                    modifier = Modifier.testTag("slider_distance_km")
                )

                Text(
                    text = AppStrings.t("distance_band", currentLang, feeResult.bandDescription),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )

                if (feeResult.isEmergencyRequired) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SpiceAmberLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = AppStrings.t("emergency_delivery_tag", currentLang),
                                fontWeight = FontWeight.Bold,
                                color = SpiceAmber,
                                fontSize = 12.sp
                            )
                            Text(
                                text = AppStrings.t("emergency_delivery_desc", currentLang),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Checkbox(
                                    checked = isEmergencyConfirmed,
                                    onCheckedChange = { isEmergencyConfirmed = it },
                                    modifier = Modifier.testTag("chk_emergency_confirm")
                                )
                                Text("I accept emergency fee & admin approval", fontSize = 12.sp)
                            }
                        }
                    }
                }

                if (!feeResult.isAvailable && !feeResult.isEmergencyRequired) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = AppStrings.t("distance_unavailable", currentLang),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Request Delivery Fee Discount button
                OutlinedButton(
                    onClick = { showDiscountDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_request_discount")
                ) {
                    Icon(Icons.Default.Discount, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(AppStrings.t("request_discount_btn", currentLang), fontSize = 12.sp)
                }
            }
        }

        // Optional Tip Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = AppStrings.t("select_tip", currentLang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = AppStrings.t("tip_note", currentLang),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))

                val tipOptions = listOf(0, 10, 20, 30, 50)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tipOptions) { opt ->
                        FilterChip(
                            selected = !isCustomTip && selectedTip == opt,
                            onClick = {
                                isCustomTip = false
                                selectedTip = opt
                            },
                            label = { Text("₹$opt") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ExpressRed,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = isCustomTip,
                            onClick = { isCustomTip = true },
                            label = { Text("Custom") }
                        )
                    }
                }

                if (isCustomTip) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customTipInput,
                        onValueChange = { customTipInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Custom Tip (₹)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_custom_tip")
                    )
                }
            }
        }

        // Coin Rewards & Redemption
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🪙 " + AppStrings.t("redeem_coins", currentLang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = AppStrings.t("coins_available", currentLang, coinBalance),
                        fontSize = 12.sp,
                        color = FreshGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val redeemOptions = listOf(0, 100, 200, 300, 500).filter { it <= coinBalance }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(redeemOptions) { coins ->
                        FilterChip(
                            selected = coinsToRedeem == coins,
                            onClick = { coinsToRedeem = coins },
                            label = { Text("$coins coins (₹${coins / 10} off)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FreshGreen,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }
            }
        }

        // Payment Method Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = AppStrings.t("payment_method", currentLang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { paymentMethod = PaymentMethod.COD }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = paymentMethod == PaymentMethod.COD,
                        onClick = { paymentMethod = PaymentMethod.COD },
                        modifier = Modifier.testTag("radio_pay_cod")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(AppStrings.t("cod", currentLang))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { paymentMethod = PaymentMethod.ONLINE_RAZORPAY }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = paymentMethod == PaymentMethod.ONLINE_RAZORPAY,
                        onClick = { paymentMethod = PaymentMethod.ONLINE_RAZORPAY },
                        modifier = Modifier.testTag("radio_pay_online")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(AppStrings.t("online_pay", currentLang))
                }
            }
        }

        // Full Price Breakdown
        PriceBreakdownCard(calc = calc, currentLang = currentLang)

        if (placeOrderError != null) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = placeOrderError ?: "",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Place Order Button
        Button(
            onClick = {
                if (isPlacingOrder) return@Button
                isPlacingOrder = true
                placeOrderError = null
                val result = ExpressRepository.placeOrder(
                    customerAddress = customerAddress,
                    customerLat = customerLat,
                    customerLng = customerLng,
                    tipAmount = tip,
                    coinsRedeemed = coinsToRedeem,
                    paymentMethod = paymentMethod,
                    isEmergency = isEmergencyConfirmed
                )
                result.onSuccess { order ->
                    isPlacingOrder = false
                    onOrderPlaced(order.id)
                }.onFailure { err ->
                    isPlacingOrder = false
                    placeOrderError = err.message ?: "Failed to place order"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("btn_place_order"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
            enabled = feeResult.isAvailable && !isPlacingOrder
        ) {
            if (isPlacingOrder) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = PureWhite,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "${AppStrings.t("place_order", currentLang)} • ₹${calc.totalAmount}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = PureWhite
                )
            }
        }
    }

    if (showDiscountDialog) {
        AlertDialog(
            onDismissRequest = { showDiscountDialog = false },
            title = { Text(AppStrings.t("request_discount_btn", currentLang)) },
            text = {
                Column {
                    Text("Submit reason for discount request (Admin will review in portal):", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = discountReason,
                        onValueChange = { discountReason = it },
                        label = { Text("Reason (e.g. promotional student offer, delay)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_discount_reason")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val usr = user
                        if (usr != null && discountReason.isNotBlank()) {
                            ExpressRepository.createDeliveryFeeDiscountRequest(
                                customerId = usr.id,
                                customerName = usr.name,
                                reason = discountReason,
                                currentFee = feeResult.fee,
                                requestedAmount = 25
                            )
                        }
                        showDiscountDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_submit_discount_request")
                ) {
                    Text(AppStrings.t("submit", currentLang), color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDiscountDialog = false }) {
                    Text(AppStrings.t("cancel", currentLang))
                }
            }
        )
    }
}

@Composable
fun OrderTrackingScreen(
    order: Order,
    onBack: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()
    val allRatings by ExpressRepository.ratings.collectAsState()

    var showRatingDialog by remember { mutableStateOf(false) }
    var restStars by remember { mutableStateOf(5) }
    var dpStars by remember { mutableStateOf(5) }
    var reviewComment by remember { mutableStateOf("") }
    var ratingSubmitted by remember { mutableStateOf(false) }

    val alreadyRated = allRatings.any { it.orderId == order.id }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = AppStrings.t("order_id_label", currentLang, order.id),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Current Status",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (order.orderStatus) {
                            OrderStatus.DELIVERED -> FreshGreenLight
                            OrderStatus.CANCELLED, OrderStatus.REJECTED, OrderStatus.FAILED -> MaterialTheme.colorScheme.errorContainer
                            else -> ExpressRedLight
                        }
                    ) {
                        Text(
                            text = AppStrings.t("status_" + order.orderStatus.name.lowercase(), currentLang),
                            color = when (order.orderStatus) {
                                OrderStatus.DELIVERED -> FreshGreen
                                OrderStatus.CANCELLED, OrderStatus.REJECTED, OrderStatus.FAILED -> MaterialTheme.colorScheme.error
                                else -> ExpressRedDark
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Timeline stages
                val stages = listOf(
                    OrderStatus.ORDER_PLACED to "Order Placed",
                    OrderStatus.RESTAURANT_ACCEPTED to "Restaurant Accepted",
                    OrderStatus.PREPARING to "Kitchen Preparing",
                    OrderStatus.READY_FOR_PICKUP to "Ready for Pickup",
                    OrderStatus.DELIVERY_PARTNER_ASSIGNED to "Partner Assigned",
                    OrderStatus.PICKED_UP to "Picked Up",
                    OrderStatus.ON_THE_WAY to "On the Way",
                    OrderStatus.DELIVERED to "Delivered"
                )

                stages.forEachIndexed { idx, stage ->
                    val isPassed = order.statusHistory.any { it.status == stage.first }
                    val isCurrent = order.orderStatus == stage.first

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isPassed) FreshGreen else Color.LightGray),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isPassed) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = PureWhite, modifier = Modifier.size(12.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stage.second,
                            fontSize = 13.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isPassed) MaterialTheme.colorScheme.onSurface else Color.Gray
                        )
                    }
                    if (idx < stages.lastIndex) {
                        Box(
                            modifier = Modifier
                                .padding(start = 9.dp)
                                .width(2.dp)
                                .height(16.dp)
                                .background(if (isPassed) FreshGreen else Color.LightGray)
                        )
                    }
                }
            }
        }

        // Assigned Delivery Partner details
        if (order.assignedDeliveryPartnerName != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = AppStrings.t("assigned_partner", currentLang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = AppStrings.t("partner_name", currentLang, order.assignedDeliveryPartnerName ?: ""))
                    Text(text = AppStrings.t("partner_phone", currentLang, order.assignedDeliveryPartnerPhone ?: ""))

                    if (!order.assignedDeliveryPartnerPhone.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        DirectCallButton(
                            phoneNumber = order.assignedDeliveryPartnerPhone,
                            label = AppStrings.t("call_delivery_partner", currentLang),
                            testTag = "btn_customer_call_partner_${order.id}"
                        )
                    }
                }
            }
        }

        // Order Receipt & Details
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Restaurant: ${order.restaurantName}", fontWeight = FontWeight.Bold)
                Text(text = "Deliver to: ${order.deliveryAddress}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                Spacer(modifier = Modifier.height(8.dp))
                order.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "${item.menuItem.name} × ${item.quantity}", fontSize = 13.sp)
                        Text(text = "₹${item.itemSubtotal}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Paid (${order.paymentMethod.name}):", fontWeight = FontWeight.Bold)
                    Text("₹${order.totalAmount}", fontWeight = FontWeight.ExtraBold, color = ExpressRed)
                }
            }
        }

        // Rating & Review (Eligible if DELIVERED)
        if (order.orderStatus == OrderStatus.DELIVERED) {
            if (alreadyRated || ratingSubmitted) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FreshGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = AppStrings.t("already_rated", currentLang),
                        color = FreshGreen,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else {
                Button(
                    onClick = { showRatingDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("btn_rate_order"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen)
                ) {
                    Text(AppStrings.t("rate_order_title", currentLang), color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showRatingDialog) {
        AlertDialog(
            onDismissRequest = { showRatingDialog = false },
            title = { Text(AppStrings.t("rate_order_title", currentLang)) },
            text = {
                Column {
                    Text(AppStrings.t("rate_restaurant", currentLang), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row {
                        (1..5).forEach { star ->
                            IconButton(onClick = { restStars = star }) {
                                Icon(
                                    imageVector = if (star <= restStars) Icons.Default.Star else Icons.Outlined.StarBorder,
                                    contentDescription = null,
                                    tint = SpiceAmber
                                )
                            }
                        }
                    }

                    if (order.assignedDeliveryPartnerId != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(AppStrings.t("rate_delivery", currentLang), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Row {
                            (1..5).forEach { star ->
                                IconButton(onClick = { dpStars = star }) {
                                    Icon(
                                        imageVector = if (star <= dpStars) Icons.Default.Star else Icons.Outlined.StarBorder,
                                        contentDescription = null,
                                        tint = SpiceAmber
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        label = { Text(AppStrings.t("write_review", currentLang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val usr = user
                        if (usr != null) {
                            ExpressRepository.submitRating(
                                orderId = order.id,
                                customerId = usr.id,
                                customerName = usr.name,
                                targetType = "RESTAURANT",
                                targetId = order.restaurantId,
                                stars = restStars,
                                comment = reviewComment
                            )
                            order.assignedDeliveryPartnerId?.let { dpId ->
                                ExpressRepository.submitRating(
                                    orderId = order.id,
                                    customerId = usr.id,
                                    customerName = usr.name,
                                    targetType = "DELIVERY_PARTNER",
                                    targetId = dpId,
                                    stars = dpStars,
                                    comment = reviewComment
                                )
                            }
                            ratingSubmitted = true
                        }
                        showRatingDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed)
                ) {
                    Text(AppStrings.t("submit_rating", currentLang), color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRatingDialog = false }) {
                    Text(AppStrings.t("cancel", currentLang))
                }
            }
        )
    }
}

@Composable
fun CustomerOrdersListScreen(
    onTrackOrder: (String) -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val orders by ExpressRepository.orders.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = AppStrings.t("nav_orders", currentLang),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (orders.isEmpty()) {
            item {
                Text("No past orders yet.", color = Color.Gray)
            }
        }

        items(orders) { order ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTrackOrder(order.id) }
                    .testTag("order_item_${order.id}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = order.restaurantName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ExpressRedLight
                        ) {
                            Text(
                                text = AppStrings.t("status_" + order.orderStatus.name.lowercase(), currentLang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpressRedDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Order #${order.id} • ${order.items.size} items • ₹${order.totalAmount}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { onTrackOrder(order.id) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text(AppStrings.t("track_order", currentLang), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerWalletScreen() {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val balance by ExpressRepository.coinBalance.collectAsState()
    val transactions by ExpressRepository.coinTransactions.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = AppStrings.t("nav_wallet", currentLang),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SpiceAmber),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Express Food Coin Wallet",
                        color = PureWhite.copy(alpha = 0.9f),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "🪙 $balance Coins",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = PureWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Worth ₹${balance / 10} Discount (10 coins = ₹1)",
                        color = PureWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PureWhite.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "Earn 15 coins for every complete ₹100 of food subtotal on completed orders! (e.g. ₹200 = 30 coins, ₹250 = 30 coins). Redeem at checkout (10 coins = ₹1).",
                            color = PureWhite,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Transaction History",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(transactions) { tx ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = tx.description, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = tx.id, fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(
                        text = if (tx.amount > 0) "+${tx.amount} coins" else "${tx.amount} coins",
                        fontWeight = FontWeight.ExtraBold,
                        color = if (tx.amount > 0) FreshGreen else ExpressRed
                    )
                }
            }
        }
    }
}

@Composable
fun CustomerSupportScreen() {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val tickets by ExpressRepository.supportTickets.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("ORDER_ISSUE") }
    var ticketReason by remember { mutableStateOf("") }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = ExpressRed,
                modifier = Modifier.testTag("fab_create_ticket")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Ticket", tint = PureWhite)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = AppStrings.t("support_title", currentLang),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (tickets.isEmpty()) {
                item {
                    Text("No active tickets. Tap + to create one.", color = Color.Gray)
                }
            }

            items(tickets) { ticket ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = AppStrings.t("ticket_id", currentLang, ticket.id),
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (ticket.status) {
                                    "APPROVED" -> FreshGreenLight
                                    "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                                    else -> SpiceAmberLight
                                }
                            ) {
                                Text(
                                    text = ticket.status,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (ticket.status) {
                                        "APPROVED" -> FreshGreen
                                        "REJECTED" -> MaterialTheme.colorScheme.error
                                        else -> SpiceAmber
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Category: ${ticket.category}", fontSize = 12.sp, color = Color.Gray)
                        Text(text = "Reason: ${ticket.reason}", fontSize = 13.sp)

                        if (ticket.approvedDiscount > 0) {
                            Text(
                                text = "Approved Discount: ₹${ticket.approvedDiscount} (by ${ticket.approvedBy})",
                                fontSize = 12.sp,
                                color = FreshGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (ticket.messages.isNotEmpty()) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text(text = "Messages:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            ticket.messages.forEach { msg ->
                                Text(
                                    text = "${msg.senderName} (${msg.senderRole.name}): ${msg.message}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text(AppStrings.t("create_ticket", currentLang)) },
            text = {
                Column {
                    Text(AppStrings.t("ticket_category", currentLang), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    val cats = listOf("ORDER_ISSUE", "PAYMENT_ISSUE", "DELIVERY_FEE_DISCOUNT", "GENERAL")
                    cats.forEach { c ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCategory = c }
                        ) {
                            RadioButton(selected = selectedCategory == c, onClick = { selectedCategory = c })
                            Text(c, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ticketReason,
                        onValueChange = { ticketReason = it },
                        label = { Text(AppStrings.t("ticket_reason", currentLang)) },
                        modifier = Modifier.fillMaxWidth().testTag("input_ticket_desc")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val usr = user
                        if (usr != null && ticketReason.isNotBlank()) {
                            ExpressRepository.createSupportTicket(
                                customerId = usr.id,
                                customerName = usr.name,
                                category = selectedCategory,
                                reason = ticketReason
                            )
                        }
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_submit_support_ticket")
                ) {
                    Text(AppStrings.t("submit", currentLang), color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text(AppStrings.t("cancel", currentLang))
                }
            }
        )
    }
}
