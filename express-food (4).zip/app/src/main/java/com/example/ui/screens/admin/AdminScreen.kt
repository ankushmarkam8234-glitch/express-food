package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExpressRepository
import com.example.localization.AppStrings
import com.example.model.*
import com.example.ui.components.ExpressTopBar
import com.example.ui.components.DirectCallButton
import com.example.ui.components.DialPhoneIconButton
import com.example.ui.theme.*

fun formatTimeAgo(timestamp: Long): String {
    if (timestamp <= 0L) return "Never"
    val diff = System.currentTimeMillis() - timestamp
    val mins = diff / (60 * 1000)
    return when {
        mins < 1 -> "Just now"
        mins < 60 -> "$mins min ago"
        mins < 1440 -> "${mins / 60} hr ago"
        else -> "${mins / 1440} days ago"
    }
}

enum class AdminSection(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DISPATCH("Order Assignment", Icons.Default.LocalShipping),
    RESTAURANTS("Restaurants", Icons.Default.Storefront),
    DELIVERY_PARTNERS("Delivery Partners", Icons.Default.TwoWheeler),
    CUSTOMERS("Customers", Icons.Default.People),
    ORDERS("Orders", Icons.AutoMirrored.Filled.ReceiptLong),
    COMMISSIONS("Fees & Ledger", Icons.Default.AccountBalance),
    COINS_REWARDS("Coins & Rewards", Icons.Default.MonetizationOn),
    SUPPORT("Support & Tickets", Icons.Default.SupportAgent),
    SETTINGS("Settings & Logs", Icons.Default.Settings)
}

@Composable
fun AdminMainScreen(
    onLogout: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    var currentSection by remember { mutableStateOf(AdminSection.DISPATCH) }

    Scaffold(
        topBar = {
            Column {
                ExpressTopBar(
                    title = AppStrings.t("admin_portal_title", currentLang),
                    currentRole = UserRole.ADMIN,
                    onLogout = onLogout
                )

                // 9-Section Navigation Scrollable Row
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    shadowElevation = 2.dp
                ) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(AdminSection.values()) { section ->
                            val isSelected = currentSection == section
                            FilterChip(
                                selected = isSelected,
                                onClick = { currentSection = section },
                                label = { Text(section.title, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = section.icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isSelected) PureWhite else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ExpressRed,
                                    selectedLabelColor = PureWhite
                                ),
                                modifier = Modifier.testTag("admin_tab_${section.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentSection) {
                AdminSection.RESTAURANTS -> AdminRestaurantManagementScreen()
                AdminSection.DELIVERY_PARTNERS -> AdminDeliveryPartnerManagementScreen()
                AdminSection.CUSTOMERS -> AdminCustomerManagementScreen()
                AdminSection.ORDERS -> AdminOrderManagementScreen()
                AdminSection.DISPATCH -> AdminDispatchAssignmentScreen()
                AdminSection.COMMISSIONS -> AdminPaymentsCommissionsScreen()
                AdminSection.COINS_REWARDS -> AdminCoinsRewardsScreen()
                AdminSection.SUPPORT -> AdminSupportComplaintsScreen()
                AdminSection.SETTINGS -> AdminSettingsReportsScreen()
            }
        }
    }
}

// SECTION A: RESTAURANT MANAGEMENT
@Composable
fun AdminRestaurantManagementScreen() {
    val restaurants by ExpressRepository.restaurants.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("ALL") }

    var showAddDialog by remember { mutableStateOf(false) }
    var editingRestaurant by remember { mutableStateOf<Restaurant?>(null) }
    var resettingPasswordRest by remember { mutableStateOf<Restaurant?>(null) }
    var tempPasswordResult by remember { mutableStateOf<Pair<String, String>?>(null) } // Pair(RestName, TempPassword)
    var successAlert by remember { mutableStateOf<String?>(null) }
    var errorAlert by remember { mutableStateOf<String?>(null) }

    val filtered = remember(restaurants, searchQuery, statusFilter) {
        restaurants.filter { r ->
            val matchQuery = searchQuery.isBlank() ||
                    r.name.contains(searchQuery, ignoreCase = true) ||
                    r.id.contains(searchQuery, ignoreCase = true) ||
                    r.phone.contains(searchQuery)
            val matchStatus = statusFilter == "ALL" || r.status == statusFilter
            matchQuery && matchStatus
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Restaurant Management",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${restaurants.size} restaurants registered",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("btn_admin_add_restaurant")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Restaurant", fontSize = 12.sp, color = PureWhite)
                }
            }
        }

        if (successAlert != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FreshGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = successAlert ?: "", color = FreshGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(onClick = { successAlert = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = FreshGreen, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        if (errorAlert != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = errorAlert ?: "", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(onClick = { errorAlert = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Search & Filter
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by name, ID or mobile...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_search_admin_restaurants"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }

        // Status Filter Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL", "ACTIVE", "DEACTIVATED", "SUSPENDED").forEach { st ->
                    FilterChip(
                        selected = statusFilter == st,
                        onClick = { statusFilter = st },
                        label = { Text(st, fontSize = 11.sp) }
                    )
                }
            }
        }

        items(filtered) { r ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("restaurant_admin_card_${r.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = r.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "ID: ${r.id}", fontSize = 11.sp, color = ExpressRed, fontWeight = FontWeight.SemiBold)
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when (r.status) {
                                "ACTIVE" -> FreshGreenLight
                                "SUSPENDED" -> MaterialTheme.colorScheme.errorContainer
                                else -> Color.LightGray.copy(alpha = 0.4f)
                            }
                        ) {
                            Text(
                                text = r.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (r.status) {
                                    "ACTIVE" -> FreshGreen
                                    "SUSPENDED" -> MaterialTheme.colorScheme.error
                                    else -> Color.DarkGray
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "📞 ${r.phone}  |  ✉️ ${r.email}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        DialPhoneIconButton(
                            phoneNumber = r.phone,
                            contentDescription = "Call ${r.name}",
                            testTag = "btn_admin_call_rest_${r.id}"
                        )
                    }
                    Text(text = "📍 ${r.address} (GPS: ${r.lat}, ${r.lng})", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "🍽️ ${r.cuisine}  |  🕒 ${r.openingHours}", fontSize = 11.sp, color = Color.Gray)

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (r.isOpen) FreshGreenLight else Color.LightGray.copy(alpha = 0.4f)
                        ) {
                            Text(
                                text = if (r.isOpen) "🟢 KITCHEN ONLINE" else "⚪ KITCHEN CLOSED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (r.isOpen) FreshGreen else Color.DarkGray,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Status updated: " + formatTimeAgo(r.lastStatusUpdatedAt),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    // Action buttons: Edit, Suspend/Activate, Reset Password
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { editingRestaurant = r },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_edit_restaurant_${r.id}"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { resettingPasswordRest = r },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_reset_pwd_restaurant_${r.id}"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Password", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val nextStatus = if (r.status == "ACTIVE") "SUSPENDED" else "ACTIVE"
                                ExpressRepository.setRestaurantStatus(r.id, nextStatus)
                                successAlert = "${r.name} status updated to $nextStatus"
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (r.status == "ACTIVE") MaterialTheme.colorScheme.error else FreshGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_toggle_status_restaurant_${r.id}")
                        ) {
                            Text(if (r.status == "ACTIVE") "Suspend" else "Activate", fontSize = 11.sp, color = PureWhite)
                        }
                    }
                }
            }
        }
    }

    // Add Restaurant Dialog
    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var cuisine by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }
        var hours by remember { mutableStateOf("10:00 AM - 11:00 PM") }
        var initialPass by remember { mutableStateOf("rest2026") }
        var mustChange by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Restaurant Account", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Restaurant Name *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_rest_name"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Registered Email *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_rest_email"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Registered Mobile (10 digits) *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_rest_phone"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = cuisine, onValueChange = { cuisine = it }, label = { Text("Cuisine Types") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Full Address *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_rest_address"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = hours, onValueChange = { hours = it }, label = { Text("Operating Hours") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = initialPass, onValueChange = { initialPass = it }, label = { Text("Temporary Password") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = mustChange, onCheckedChange = { mustChange = it })
                        Text("Require password change on first login", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isBlank() || email.isBlank() || phone.isBlank() || address.isBlank()) {
                            errorAlert = "Please fill in all required fields marked with *"
                        } else {
                            val newR = ExpressRepository.provisionRestaurantPartner(
                                name = name,
                                email = email,
                                phone = phone,
                                cuisine = if (cuisine.isBlank()) "Indian" else cuisine,
                                address = address,
                                openingHours = hours,
                                initialPassword = initialPass,
                                mustChangePassword = mustChange
                            )
                            tempPasswordResult = Pair(newR.name, initialPass)
                            successAlert = "Created restaurant ${newR.name}! Unique ID: ${newR.id}"
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_save_add_restaurant")
                ) {
                    Text("Create Restaurant", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Edit Restaurant Dialog (Loads existing values, validates and persists)
    if (editingRestaurant != null) {
        val r = editingRestaurant!!
        var editName by remember(r) { mutableStateOf(r.name) }
        var editEmail by remember(r) { mutableStateOf(r.email) }
        var editPhone by remember(r) { mutableStateOf(r.phone) }
        var editCuisine by remember(r) { mutableStateOf(r.cuisine) }
        var editAddress by remember(r) { mutableStateOf(r.address) }
        var editHours by remember(r) { mutableStateOf(r.openingHours) }
        var dialogError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { editingRestaurant = null },
            title = { Text("Edit Restaurant: ${r.id}", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (dialogError != null) {
                        Text(text = dialogError ?: "", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Restaurant Name") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_rest_name"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editEmail, onValueChange = { editEmail = it }, label = { Text("Registered Email") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_rest_email"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editPhone, onValueChange = { editPhone = it }, label = { Text("Registered Mobile") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_rest_phone"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editCuisine, onValueChange = { editCuisine = it }, label = { Text("Cuisine Types") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editAddress, onValueChange = { editAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_rest_address"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editHours, onValueChange = { editHours = it }, label = { Text("Opening Hours") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isBlank() || editEmail.isBlank() || editPhone.isBlank() || editAddress.isBlank()) {
                            dialogError = "Name, email, phone and address cannot be empty."
                        } else {
                            val res = ExpressRepository.updateRestaurant(
                                id = r.id,
                                name = editName,
                                cuisine = editCuisine,
                                address = editAddress,
                                phone = editPhone,
                                email = editEmail,
                                openingHours = editHours
                            )
                            res.onSuccess {
                                successAlert = "Successfully updated ${r.id} (${editName})!"
                                editingRestaurant = null
                            }.onFailure { err ->
                                dialogError = err.message
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_save_edit_restaurant")
                ) {
                    Text("Save Changes", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingRestaurant = null }) { Text("Cancel") }
            }
        )
    }

    // Reset Password Dialog
    if (resettingPasswordRest != null) {
        val r = resettingPasswordRest!!
        var newTempPass by remember { mutableStateOf("temp@" + (1000..9999).random()) }

        AlertDialog(
            onDismissRequest = { resettingPasswordRest = null },
            title = { Text("Reset Password: ${r.name}") },
            text = {
                Column {
                    Text("Enter a new temporary password for this partner. They will be forced to change it upon first login:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = newTempPass, onValueChange = { newTempPass = it }, label = { Text("Temporary Password") }, modifier = Modifier.fillMaxWidth().testTag("input_rest_temp_pass"))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        ExpressRepository.resetRestaurantPassword(r.id, newTempPass)
                        successAlert = "Reset password for ${r.name} to '$newTempPass'. Forced change on login."
                        resettingPasswordRest = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed)
                ) {
                    Text("Apply Reset", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { resettingPasswordRest = null }) { Text("Cancel") }
            }
        )
    }
}

// SECTION B: DELIVERY PARTNER MANAGEMENT
@Composable
fun AdminDeliveryPartnerManagementScreen() {
    val deliveryPartners by ExpressRepository.deliveryPartners.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("ALL") }

    var showAddDialog by remember { mutableStateOf(false) }
    var editingPartner by remember { mutableStateOf<DeliveryPartner?>(null) }
    var resettingPasswordDp by remember { mutableStateOf<DeliveryPartner?>(null) }
    var successAlert by remember { mutableStateOf<String?>(null) }
    var errorAlert by remember { mutableStateOf<String?>(null) }

    val filtered = remember(deliveryPartners, searchQuery, statusFilter) {
        deliveryPartners.filter { dp ->
            val matchQuery = searchQuery.isBlank() ||
                    dp.name.contains(searchQuery, ignoreCase = true) ||
                    dp.code.contains(searchQuery, ignoreCase = true) ||
                    dp.phone.contains(searchQuery)
            val matchStatus = statusFilter == "ALL" || dp.status == statusFilter
            matchQuery && matchStatus
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Delivery Partner Management",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${deliveryPartners.size} delivery partners registered",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("btn_admin_add_dp")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Partner", fontSize = 12.sp, color = PureWhite)
                }
            }
        }

        if (successAlert != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FreshGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = successAlert ?: "", color = FreshGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(onClick = { successAlert = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = FreshGreen, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        if (errorAlert != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = errorAlert ?: "", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(onClick = { errorAlert = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name, code (DP-101) or mobile...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_admin_dp"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )
        }

        items(filtered) { dp ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dp_admin_card_${dp.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = dp.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "Code: ${dp.code}", fontSize = 11.sp, color = FreshGreen, fontWeight = FontWeight.SemiBold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (dp.isOnline) FreshGreenLight else Color.LightGray.copy(alpha = 0.4f)
                            ) {
                                Text(
                                    text = if (dp.isOnline) "ONLINE" else "OFFLINE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (dp.isOnline) FreshGreen else Color.DarkGray,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (dp.status == "ACTIVE") FreshGreenLight else MaterialTheme.colorScheme.errorContainer
                            ) {
                                Text(
                                    text = dp.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (dp.status == "ACTIVE") FreshGreen else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "📞 ${dp.phone}  |  ✉️ ${dp.email}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        DialPhoneIconButton(
                            phoneNumber = dp.phone,
                            contentDescription = "Call ${dp.name}",
                            testTag = "btn_admin_call_dp_${dp.id}"
                        )
                    }
                    Text(text = "🛵 Vehicle: ${dp.vehicleType}  |  🏠 ${dp.address}", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "📦 Completed: ${dp.totalDeliveries}  |  💵 Earnings: ₹${dp.baseEarnings + dp.tipsEarned}", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        text = "Status: ${if (dp.isOnline) "🟢 Online on duty" else "⚪ Offline"} (Updated: ${formatTimeAgo(dp.lastStatusUpdatedAt)})",
                        fontSize = 11.sp,
                        color = if (dp.isOnline) FreshGreen else Color.Gray,
                        fontWeight = FontWeight.SemiBold
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { editingPartner = dp },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_edit_dp_${dp.id}"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { resettingPasswordDp = dp },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_reset_pwd_dp_${dp.id}"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Password", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val nextStatus = if (dp.status == "ACTIVE") "SUSPENDED" else "ACTIVE"
                                ExpressRepository.setDeliveryPartnerStatus(dp.id, nextStatus)
                                successAlert = "${dp.name} status updated to $nextStatus"
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (dp.status == "ACTIVE") MaterialTheme.colorScheme.error else FreshGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_toggle_status_dp_${dp.id}")
                        ) {
                            Text(if (dp.status == "ACTIVE") "Suspend" else "Activate", fontSize = 11.sp, color = PureWhite)
                        }
                    }
                }
            }
        }
    }

    // Add Delivery Partner Dialog
    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }
        var vehicle by remember { mutableStateOf("Motorcycle") }
        var initialPass by remember { mutableStateOf("partner2026") }
        var mustChange by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Delivery Partner Account", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_dp_name"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Registered Email *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_dp_email"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Number (10 digits) *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_dp_phone"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address / Delivery Zone *") }, modifier = Modifier.fillMaxWidth().testTag("input_add_dp_address"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = vehicle, onValueChange = { vehicle = it }, label = { Text("Vehicle Type (e.g. Scooter, Bike)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = initialPass, onValueChange = { initialPass = it }, label = { Text("Temporary Password") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = mustChange, onCheckedChange = { mustChange = it })
                        Text("Require password change on first login", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isBlank() || email.isBlank() || phone.isBlank() || address.isBlank()) {
                            errorAlert = "Please fill in all required fields marked with *"
                        } else {
                            val newDp = ExpressRepository.provisionDeliveryPartner(
                                name = name,
                                email = email,
                                phone = phone,
                                address = address,
                                vehicleType = vehicle,
                                initialPassword = initialPass,
                                mustChangePassword = mustChange
                            )
                            successAlert = "Created delivery partner ${newDp.name}! Assigned ID: ${newDp.code}"
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                    modifier = Modifier.testTag("btn_save_add_dp")
                ) {
                    Text("Create Partner", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Edit Delivery Partner Dialog
    if (editingPartner != null) {
        val dp = editingPartner!!
        var editName by remember(dp) { mutableStateOf(dp.name) }
        var editEmail by remember(dp) { mutableStateOf(dp.email) }
        var editPhone by remember(dp) { mutableStateOf(dp.phone) }
        var editAddress by remember(dp) { mutableStateOf(dp.address) }
        var editVehicle by remember(dp) { mutableStateOf(dp.vehicleType) }
        var dialogError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { editingPartner = null },
            title = { Text("Edit Delivery Partner: ${dp.code}", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (dialogError != null) {
                        Text(text = dialogError ?: "", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_dp_name"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editEmail, onValueChange = { editEmail = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_dp_email"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editPhone, onValueChange = { editPhone = it }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_dp_phone"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editAddress, onValueChange = { editAddress = it }, label = { Text("Address / Hub") }, modifier = Modifier.fillMaxWidth().testTag("input_edit_dp_address"))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = editVehicle, onValueChange = { editVehicle = it }, label = { Text("Vehicle Type") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isBlank() || editEmail.isBlank() || editPhone.isBlank()) {
                            dialogError = "Name, email, and mobile cannot be empty."
                        } else {
                            val res = ExpressRepository.updateDeliveryPartner(
                                id = dp.id,
                                name = editName,
                                email = editEmail,
                                phone = editPhone,
                                address = editAddress,
                                vehicleType = editVehicle
                            )
                            res.onSuccess {
                                successAlert = "Successfully updated ${dp.code} (${editName})!"
                                editingPartner = null
                            }.onFailure { err ->
                                dialogError = err.message
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                    modifier = Modifier.testTag("btn_save_edit_dp")
                ) {
                    Text("Save Changes", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingPartner = null }) { Text("Cancel") }
            }
        )
    }

    // Reset Password Dialog for DP
    if (resettingPasswordDp != null) {
        val dp = resettingPasswordDp!!
        var newTempPass by remember { mutableStateOf("dp@" + (1000..9999).random()) }

        AlertDialog(
            onDismissRequest = { resettingPasswordDp = null },
            title = { Text("Reset Password: ${dp.name} (${dp.code})") },
            text = {
                Column {
                    Text("Enter a temporary password for this partner. Forced change on login:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = newTempPass, onValueChange = { newTempPass = it }, label = { Text("Temporary Password") }, modifier = Modifier.fillMaxWidth().testTag("input_dp_temp_pass"))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        ExpressRepository.resetDeliveryPartnerPassword(dp.id, newTempPass)
                        successAlert = "Reset password for ${dp.name} (${dp.code}) to '$newTempPass'."
                        resettingPasswordDp = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen)
                ) {
                    Text("Apply Reset", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { resettingPasswordDp = null }) { Text("Cancel") }
            }
        )
    }
}

// SECTION C: CUSTOMER MANAGEMENT
@Composable
fun AdminCustomerManagementScreen() {
    val users by ExpressRepository.users.collectAsState()
    val orders by ExpressRepository.orders.collectAsState()
    val coinBalance by ExpressRepository.coinBalance.collectAsState()

    val customers = users.filter { it.role == UserRole.CUSTOMER }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Customer Account Management",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Manage registered customer accounts, view orders and coin rewards.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        items(customers) { cust ->
            val custOrders = orders.filter { it.customerId == cust.id }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = cust.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (cust.isActive && cust.status == "ACTIVE") FreshGreenLight else MaterialTheme.colorScheme.errorContainer
                        ) {
                            Text(
                                text = cust.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (cust.isActive && cust.status == "ACTIVE") FreshGreen else MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "ID: ${cust.id}  |  📞 ${cust.phone}  |  ✉️ ${cust.email}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        DialPhoneIconButton(
                            phoneNumber = cust.phone,
                            contentDescription = "Call ${cust.name}",
                            testTag = "btn_admin_call_cust_${cust.id}"
                        )
                    }
                    Text(text = "Total Orders: ${custOrders.size}  |  Active Wallet: 🪙 $coinBalance Coins", fontSize = 12.sp, color = Color.Gray)

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                val next = if (cust.status == "ACTIVE") "SUSPENDED" else "ACTIVE"
                                ExpressRepository.setCustomerStatus(cust.id, next)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (cust.status == "ACTIVE") MaterialTheme.colorScheme.error else FreshGreen
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (cust.status == "ACTIVE") "Suspend Customer" else "Activate Customer", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// SECTION D: ORDER MANAGEMENT
@Composable
fun AdminOrderManagementScreen() {
    val orders by ExpressRepository.orders.collectAsState()
    var selectedStatus by remember { mutableStateOf("ALL") }
    var selectedPaymentFilter by remember { mutableStateOf("ALL") } // ALL, COD, ONLINE

    val filtered = remember(orders, selectedStatus, selectedPaymentFilter) {
        orders.filter { order ->
            val matchStatus = selectedStatus == "ALL" || order.orderStatus.name == selectedStatus
            val matchPayment = when (selectedPaymentFilter) {
                "COD" -> order.paymentMethod == PaymentMethod.COD
                "ONLINE" -> order.paymentMethod == PaymentMethod.ONLINE
                else -> true
            }
            matchStatus && matchPayment
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Order & Payment Records",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Live view of all orders, separate COD and Online payments, delivery distances, partner earnings (at ₹17/km), and cancel overrides.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        // Payment filter chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedPaymentFilter == "ALL",
                    onClick = { selectedPaymentFilter = "ALL" },
                    label = { Text("All Payments", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedPaymentFilter == "COD",
                    onClick = { selectedPaymentFilter = "COD" },
                    label = { Text("💵 COD Only", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedPaymentFilter == "ONLINE",
                    onClick = { selectedPaymentFilter = "ONLINE" },
                    label = { Text("🛡️ Online Paid", fontSize = 11.sp) }
                )
            }
        }

        // Status filter row
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    FilterChip(
                        selected = selectedStatus == "ALL",
                        onClick = { selectedStatus = "ALL" },
                        label = { Text("ALL STATUSES") }
                    )
                }
                items(OrderStatus.values()) { st ->
                    FilterChip(
                        selected = selectedStatus == st.name,
                        onClick = { selectedStatus = st.name },
                        label = { Text(st.name.replace("_", " "), fontSize = 10.sp) }
                    )
                }
            }
        }

        items(filtered) { order ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Order #${order.id}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = ExpressRedLight
                        ) {
                            Text(
                                text = order.orderStatus.name.replace("_", " "),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpressRedDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Prominent Payment Badge: Separate COD vs Online Records
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (order.paymentMethod == PaymentMethod.ONLINE) FreshGreenLight else SpiceAmberLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (order.paymentMethod == PaymentMethod.ONLINE) "🛡️ ONLINE PAID (Razorpay)" else "💵 CASH ON DELIVERY (COD)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (order.paymentMethod == PaymentMethod.ONLINE) FreshGreenDark else SpiceAmber
                            )
                            Text(
                                text = "Status: ${order.paymentStatus}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (order.paymentStatus == PaymentStatus.SUCCESSFUL) FreshGreenDark else SpiceAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "From: ${order.restaurantName} → To: ${order.customerName}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Subtotal: ₹${order.subtotal} | Delivery Fee: ₹${order.deliveryFee} | Platform: ₹${order.platformFee} | Tip: ₹${order.tipAmount} | Total: ₹${order.totalAmount}", fontSize = 11.sp)
                    Text(text = "Straight-line Distance: ${order.distanceKm} km | Delivery Partner Earnings: ₹${order.deliveryPartnerEarnings} (@ ₹17/km)", fontSize = 11.sp, color = FreshGreen, fontWeight = FontWeight.SemiBold)

                    if (order.assignedDeliveryPartnerName != null) {
                        Text(
                            text = "Assigned Delivery Partner: ${order.assignedDeliveryPartnerName} (📞 ${order.assignedDeliveryPartnerPhone ?: "N/A"})",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }

                    if (order.orderStatus !in listOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.FAILED)) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(
                                onClick = { ExpressRepository.updateOrderStatus(order.id, OrderStatus.CANCELLED, "Cancelled by Admin") },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Force Cancel", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// SECTION A (DEFAULT): ORDER ASSIGNMENT & DISPATCH MANAGEMENT
@Composable
fun AdminDispatchAssignmentScreen() {
    val orders by ExpressRepository.orders.collectAsState()
    val deliveryPartners by ExpressRepository.deliveryPartners.collectAsState()

    var assigningOrder by remember { mutableStateOf<Order?>(null) }
    var selectedPartnerId by remember { mutableStateOf<String?>(null) }
    var filterTab by remember { mutableStateOf(0) } // 0: All Active, 1: Ready for Pickup, 2: Kitchen/Pending, 3: Out for Delivery

    val activeOrders = orders.filter {
        it.orderStatus !in listOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.FAILED, OrderStatus.REJECTED)
    }

    val pendingCount = activeOrders.count { it.orderStatus == OrderStatus.ORDER_PLACED }
    val kitchenCount = activeOrders.count { it.orderStatus in listOf(OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.PREPARING) }
    val readyCount = activeOrders.count { it.orderStatus == OrderStatus.READY_FOR_PICKUP }
    val outForDeliveryCount = activeOrders.count { it.orderStatus in listOf(OrderStatus.DELIVERY_PARTNER_ASSIGNED, OrderStatus.PICKED_UP, OrderStatus.ON_THE_WAY) }
    val availablePartnersCount = deliveryPartners.count { it.isOnline && it.status == "ACTIVE" }
    val assignedActiveCount = activeOrders.count { it.assignedDeliveryPartnerId != null }

    // Critical Offline Alerts for active assigned deliveries
    val offlineAlertOrders = activeOrders.filter { order ->
        val partner = deliveryPartners.find { it.id == order.assignedDeliveryPartnerId }
        order.partnerOfflineAlert || (partner != null && !partner.isOnline)
    }

    val displayedOrders = when (filterTab) {
        1 -> activeOrders.filter { it.orderStatus == OrderStatus.READY_FOR_PICKUP }
        2 -> activeOrders.filter { it.orderStatus in listOf(OrderStatus.ORDER_PLACED, OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.PREPARING) }
        3 -> activeOrders.filter { it.orderStatus in listOf(OrderStatus.DELIVERY_PARTNER_ASSIGNED, OrderStatus.PICKED_UP, OrderStatus.ON_THE_WAY) }
        else -> activeOrders
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_dispatch_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Order Assignment & Dispatch",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Live dispatch console: Monitor order stages, GPS coordinates, assign & reassign delivery partners.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        // Top Metrics Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Real-Time Fleet & Dispatch Metrics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DispatchMetricTile("⏳ Pending", "$pendingCount", ExpressRed)
                        DispatchMetricTile("🍳 Kitchen", "$kitchenCount", SpiceAmber)
                        DispatchMetricTile("📦 Ready", "$readyCount", FreshGreen)
                        DispatchMetricTile("🛵 Partners", "$availablePartnersCount", FreshGreen)
                        DispatchMetricTile("🚀 Active", "$assignedActiveCount", MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Offline Alert Warning Banner
        if (offlineAlertOrders.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "URGENT DISPATCH ALERT: ${offlineAlertOrders.size} Partner(s) Went Offline",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        offlineAlertOrders.forEach { alertOrder ->
                            val p = deliveryPartners.find { it.id == alertOrder.assignedDeliveryPartnerId }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Order #${alertOrder.id} • Partner: ${p?.name ?: alertOrder.assignedDeliveryPartnerName} (📞 ${p?.phone ?: alertOrder.assignedDeliveryPartnerPhone})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                    Text(
                                        text = "Partner switched offline during delivery. Delivery is preserved. Reassign if needed.",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                                    )
                                }
                                Button(
                                    onClick = {
                                        assigningOrder = alertOrder
                                        selectedPartnerId = deliveryPartners.firstOrNull { it.isOnline && it.status == "ACTIVE" }?.id
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Reassign", fontSize = 11.sp, color = PureWhite)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Filter Chips Row
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = filterTab == 0,
                        onClick = { filterTab = 0 },
                        label = { Text("All Active (${activeOrders.size})", fontSize = 12.sp) }
                    )
                }
                item {
                    FilterChip(
                        selected = filterTab == 1,
                        onClick = { filterTab = 1 },
                        label = { Text("Ready for Pickup ($readyCount)", fontSize = 12.sp) }
                    )
                }
                item {
                    FilterChip(
                        selected = filterTab == 2,
                        onClick = { filterTab = 2 },
                        label = { Text("Kitchen / Pending ($kitchenCount)", fontSize = 12.sp) }
                    )
                }
                item {
                    FilterChip(
                        selected = filterTab == 3,
                        onClick = { filterTab = 3 },
                        label = { Text("Out for Delivery ($outForDeliveryCount)", fontSize = 12.sp) }
                    )
                }
            }
        }

        if (displayedOrders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🛵", fontSize = 42.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No active orders matching this dispatch filter",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        items(displayedOrders) { order ->
            val assignedPartner = deliveryPartners.find { it.id == order.assignedDeliveryPartnerId }
            val isAssigned = order.assignedDeliveryPartnerId != null
            val isPartnerOnline = assignedPartner?.isOnline == true

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dispatch_order_card_${order.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header: Order ID & Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Order #${order.id}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "• " + formatTimeAgo(order.createdAt),
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when (order.orderStatus) {
                                OrderStatus.ORDER_PLACED -> ExpressRedLight
                                OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.PREPARING -> SpiceAmberLight
                                OrderStatus.READY_FOR_PICKUP -> FreshGreenLight
                                OrderStatus.DELIVERY_PARTNER_ASSIGNED, OrderStatus.PICKED_UP, OrderStatus.ON_THE_WAY -> MaterialTheme.colorScheme.primaryContainer
                                else -> Color.LightGray.copy(alpha = 0.4f)
                            }
                        ) {
                            Text(
                                text = order.orderStatus.name.replace("_", " "),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (order.orderStatus) {
                                    OrderStatus.ORDER_PLACED -> ExpressRedDark
                                    OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.PREPARING -> SpiceAmber
                                    OrderStatus.READY_FOR_PICKUP -> FreshGreen
                                    else -> MaterialTheme.colorScheme.onPrimaryContainer
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Restaurant Info & GPS Map Coordinates
                    Row(verticalAlignment = Alignment.Top) {
                        Text("🍽️", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = order.restaurantName,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${order.restaurantAddress} (GPS: ${order.restaurantLat}, ${order.restaurantLng})",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Customer Delivery Info & GPS Map Coordinates
                    Row(verticalAlignment = Alignment.Top) {
                        Text("📍", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "${order.customerName} (📞 ${order.customerPhone})",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${order.deliveryAddress} (GPS: ${order.customerLat}, ${order.customerLng})",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calculated Coordinate Distance & Delivery Fee
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Straight-Line Distance (GPS Coordinates)",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "${order.distanceKm} km",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ExpressRed
                                )
                                Text(
                                    text = "Partner Earnings: ₹${order.deliveryPartnerEarnings} (Rate: ₹17/km)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FreshGreenDark
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (order.paymentMethod == PaymentMethod.ONLINE) "🛡️ ONLINE PAID" else "💵 COD (CASH)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (order.paymentMethod == PaymentMethod.ONLINE) FreshGreenDark else SpiceAmber
                                )
                                Text(
                                    text = "Total: ₹${order.totalAmount}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                if (order.isEmergencyOrder) {
                                    Text(
                                        text = "🚨 Emergency Approved",
                                        fontSize = 10.sp,
                                        color = SpiceAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    // Assigned Partner Status or Assignment Prompt
                    if (isAssigned) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Assigned Partner: ${assignedPartner?.name ?: order.assignedDeliveryPartnerName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "📞 ${assignedPartner?.phone ?: order.assignedDeliveryPartnerPhone} • ${assignedPartner?.vehicleType ?: "Two-Wheeler"}",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        modifier = Modifier.weight(1f)
                                    )
                                    val partnerPhone = assignedPartner?.phone ?: order.assignedDeliveryPartnerPhone
                                    if (!partnerPhone.isNullOrBlank()) {
                                        DialPhoneIconButton(
                                            phoneNumber = partnerPhone,
                                            contentDescription = "Call Assigned Partner",
                                            testTag = "btn_admin_call_assigned_dp_${order.id}"
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isPartnerOnline) FreshGreenLight else MaterialTheme.colorScheme.errorContainer
                                    ) {
                                        Text(
                                            text = if (isPartnerOnline) "🟢 PARTNER ONLINE" else "🚨 PARTNER OFFLINE",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isPartnerOnline) FreshGreen else MaterialTheme.colorScheme.error,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    assigningOrder = order
                                    selectedPartnerId = order.assignedDeliveryPartnerId
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_reassign_partner_${order.id}")
                            ) {
                                Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reassign", fontSize = 11.sp)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚪ No delivery partner assigned yet",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.SemiBold
                            )

                            Button(
                                onClick = {
                                    assigningOrder = order
                                    selectedPartnerId = deliveryPartners.firstOrNull { it.isOnline && it.status == "ACTIVE" }?.id
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_dispatch_assign_${order.id}")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Assign Partner", fontSize = 11.sp, color = PureWhite)
                            }
                        }
                    }
                }
            }
        }
    }

    // Assign / Reassign Dialog
    if (assigningOrder != null) {
        val targetOrder = assigningOrder!!
        val isReassign = targetOrder.assignedDeliveryPartnerId != null
        val activePartners = deliveryPartners.filter { it.status == "ACTIVE" }

        AlertDialog(
            onDismissRequest = { assigningOrder = null },
            title = {
                Text(
                    text = if (isReassign) "Reassign Partner: Order #${targetOrder.id}" else "Assign Partner: Order #${targetOrder.id}",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "Pickup: ${targetOrder.restaurantName} → ${targetOrder.deliveryAddress}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = "Straight-line distance: ${targetOrder.distanceKm} km (Fee: ₹${targetOrder.deliveryFee})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ExpressRed
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (activePartners.isEmpty()) {
                        Text("No active delivery partners configured in system.", color = MaterialTheme.colorScheme.error)
                    } else {
                        Text("Select Delivery Partner:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))

                        activePartners.forEach { dp ->
                            val isSelected = selectedPartnerId == dp.id
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) ExpressRedLight else MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clickable { selectedPartnerId = dp.id }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedPartnerId = dp.id }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${dp.name} (${dp.code})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "📞 ${dp.phone} • ${dp.vehicleType}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (dp.isOnline) FreshGreenLight else Color.LightGray.copy(alpha = 0.4f)
                                    ) {
                                        Text(
                                            text = if (dp.isOnline) "ONLINE" else "OFFLINE",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (dp.isOnline) FreshGreen else Color.DarkGray,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pId = selectedPartnerId
                        if (pId != null) {
                            ExpressRepository.assignDeliveryPartner(targetOrder.id, pId)
                        }
                        assigningOrder = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    enabled = selectedPartnerId != null
                ) {
                    Text(if (isReassign) "Confirm Reassign" else "Confirm Assignment", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { assigningOrder = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun DispatchMetricTile(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = color)
        Text(text = label, fontSize = 10.sp, color = Color.Gray)
    }
}

// SECTION F: PAYMENTS, FEES & COMMISSIONS MANAGEMENT
@Composable
fun AdminPaymentsCommissionsScreen() {
    val orders by ExpressRepository.orders.collectAsState()

    val completed = orders.filter { it.orderStatus == OrderStatus.DELIVERED }
    val totalFoodSales = completed.sumOf { it.subtotal }
    val totalPlatformFees = orders.sumOf { it.platformFee } // ₹10 per placed order
    val totalRestCommissions = completed.size * 10 // ₹10 per completed order
    val totalOwnerCommissions = completed.size * 10 // ₹10 per completed order
    val totalTips = completed.sumOf { it.tipAmount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Payments, Fees & Commission Ledger",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Auditable ledger separating customer platform fees, restaurant commissions, and company revenue.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Revenue Breakdown", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    LedgerRow("Gross Food Sales (Subtotal)", "₹$totalFoodSales")
                    LedgerRow("Customer Platform Fees (₹10/order)", "₹$totalPlatformFees", FreshGreen)
                    LedgerRow("Restaurant Commission (₹10/completed)", "₹$totalRestCommissions", SpiceAmber)
                    LedgerRow("Express Food Owner Commission (₹10/completed)", "₹$totalOwnerCommissions", ExpressRed)
                    LedgerRow("Customer Tips (100% to Delivery Partners)", "₹$totalTips", FreshGreen)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Settlement Rules & Guarantee", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "• Restaurant commission (₹10) and Owner commission (₹10) are maintained separately.", fontSize = 12.sp)
                    Text(text = "• Customer platform fee (₹10) covers platform infrastructure & support.", fontSize = 12.sp)
                    Text(text = "• 100% of tips are credited to the delivery partner with zero commission deduction.", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun LedgerRow(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

// SECTION G: COINS AND REWARDS MANAGEMENT
@Composable
fun AdminCoinsRewardsScreen() {
    val currentRate by ExpressRepository.coinsPerHundredConfig.collectAsState()
    val transactions by ExpressRepository.coinTransactions.collectAsState()

    var editingRate by remember { mutableStateOf(false) }
    var newRateInput by remember(currentRate) { mutableStateOf(currentRate.toString()) }
    var rateSavedMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Coins & Rewards Management",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Rule: Award 15 coins for every complete ₹100 of eligible food subtotal. 10 coins = ₹1 discount.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SpiceAmberLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Current Reward Rate", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SpiceAmber)
                            Text("$currentRate Coins per ₹100 subtotal", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Button(
                            onClick = { editingRate = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SpiceAmber),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_edit_coin_rate")
                        ) {
                            Text("Change Rate", color = PureWhite, fontSize = 12.sp)
                        }
                    }

                    if (rateSavedMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = rateSavedMsg ?: "", color = FreshGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "• ₹100 subtotal = 15 coins\n• ₹200 subtotal = 30 coins\n• ₹250 subtotal = 30 coins (complete ₹100 blocks only)\n• ₹300 subtotal = 45 coins\n• 10 coins = ₹1 discount (e.g. 100 coins = ₹10 off)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }
            }
        }

        item {
            Text(text = "Coin Ledger Transactions", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        items(transactions) { tx ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = tx.description, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = tx.id, fontSize = 10.sp, color = Color.Gray)
                    }
                    Text(
                        text = if (tx.amount > 0) "+${tx.amount} coins" else "${tx.amount} coins",
                        fontWeight = FontWeight.Bold,
                        color = if (tx.amount > 0) FreshGreen else ExpressRed
                    )
                }
            }
        }
    }

    if (editingRate) {
        AlertDialog(
            onDismissRequest = { editingRate = false },
            title = { Text("Configure Coin Reward Rate") },
            text = {
                Column {
                    Text("Enter coins awarded per complete ₹100 of eligible food subtotal:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newRateInput,
                        onValueChange = { newRateInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Coins per ₹100") },
                        modifier = Modifier.fillMaxWidth().testTag("input_coin_rate")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = newRateInput.toIntOrNull() ?: 15
                        ExpressRepository.setCoinRewardRate(parsed)
                        rateSavedMsg = "Updated reward rate to $parsed coins per ₹100"
                        editingRate = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SpiceAmber),
                    modifier = Modifier.testTag("btn_save_coin_rate")
                ) {
                    Text("Save Rate", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingRate = false }) { Text("Cancel") }
            }
        )
    }
}

// SECTION H: SUPPORT AND COMPLAINTS
@Composable
fun AdminSupportComplaintsScreen() {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val tickets by ExpressRepository.supportTickets.collectAsState()

    var replyingTicket by remember { mutableStateOf<SupportTicket?>(null) }
    var replyText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Support Tickets & Delivery Fee Discounts",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(tickets) { t ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Ticket #${t.id} (${t.category})", fontWeight = FontWeight.Bold)
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when (t.status) {
                                "APPROVED" -> FreshGreenLight
                                "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                                else -> SpiceAmberLight
                            }
                        ) {
                            Text(
                                text = t.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (t.status) {
                                    "APPROVED" -> FreshGreen
                                    "REJECTED" -> MaterialTheme.colorScheme.error
                                    else -> SpiceAmber
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Customer: ${t.customerName}", fontSize = 12.sp)
                    Text(text = "Reason: ${t.reason}", fontSize = 13.sp)

                    if (t.category == "DELIVERY_FEE_DISCOUNT" && t.status == "PENDING") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(
                                onClick = { ExpressRepository.adminReviewDiscountRequest(t.id, false) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Reject", fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { ExpressRepository.adminReviewDiscountRequest(t.id, true, t.requestedDiscount) },
                                colors = ButtonDefaults.buttonColors(containerColor = FreshGreen)
                            ) {
                                Text("Approve ₹${t.requestedDiscount}", fontSize = 11.sp, color = PureWhite)
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(onClick = { replyingTicket = t }) {
                                Text("Reply", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (replyingTicket != null) {
        val t = replyingTicket!!
        AlertDialog(
            onDismissRequest = { replyingTicket = null },
            title = { Text("Reply to Ticket #${t.id}") },
            text = {
                Column {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        label = { Text("Admin Message") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (replyText.isNotBlank()) {
                            ExpressRepository.replyToTicket(t.id, "ADMIN-001", "Express Admin", UserRole.ADMIN, replyText)
                            replyText = ""
                        }
                        replyingTicket = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed)
                ) {
                    Text("Send Reply", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { replyingTicket = null }) { Text("Cancel") }
            }
        )
    }
}

// SECTION I: SETTINGS AND REPORTS
@Composable
fun AdminSettingsReportsScreen() {
    val auditLogs by ExpressRepository.auditLogs.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Settings, System Rules & Audit Trail",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Core Rules Summary", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "• Food Markup: Original Price + ₹20 added exactly once.", fontSize = 12.sp)
                    Text(text = "• Platform Fee: ₹10 fixed per placed order.", fontSize = 12.sp)
                    Text(text = "• Restaurant Commission: ₹10 per eligible completed order.", fontSize = 12.sp)
                    Text(text = "• Owner Commission: ₹10 per eligible completed order.", fontSize = 12.sp)
                    Text(text = "• Delivery Slabs: 1km=₹25, 2km=₹50, 3-4km=₹75, 5km=₹85, 6km=₹86, 7km=₹90, 8km=₹92, 9km=₹100, 10km=₹135.", fontSize = 12.sp)
                    Text(text = "• Emergency Slabs: 11km=₹200, 12km=₹250, 13km=₹300. >13km blocked.", fontSize = 12.sp)
                }
            }
        }

        item {
            Text(text = "System Audit Trail", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        items(auditLogs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ExpressRed)
                        Text(text = log.id, fontSize = 10.sp, color = Color.Gray)
                    }
                    Text(text = log.details, fontSize = 12.sp)
                    Text(text = "By: ${log.adminEmail} | Target: ${log.targetType}:${log.targetId}", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }
    }
}
