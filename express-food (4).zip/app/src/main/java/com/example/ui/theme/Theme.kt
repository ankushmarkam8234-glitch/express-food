package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ExpressRed,
    onPrimary = PureWhite,
    primaryContainer = ExpressRedDark,
    onPrimaryContainer = PureWhite,
    secondary = SpiceAmber,
    onSecondary = PureWhite,
    tertiary = FreshGreen,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = DarkTextPrimary,
    onSurface = DarkTextPrimary,
    error = Color(0xFFEF5350)
)

private val LightColorScheme = lightColorScheme(
    primary = ExpressRed,
    onPrimary = PureWhite,
    primaryContainer = ExpressRedLight,
    onPrimaryContainer = ExpressRedDark,
    secondary = SpiceAmber,
    onSecondary = PureWhite,
    tertiary = FreshGreen,
    background = WarmBackground,
    surface = CardSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = Color(0xFFD32F2F)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
