package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExpressRepository
import com.example.localization.AppStrings
import com.example.model.LoginResult
import com.example.model.UserAccount
import com.example.model.UserRole
import com.example.ui.components.ExpressTopBar
import com.example.ui.theme.*

@Composable
fun RoleGatewayScreen(
    onSelectCustomer: () -> Unit,
    onSelectRestaurant: () -> Unit,
    onSelectDelivery: () -> Unit,
    onSelectAdmin: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    Scaffold(
        topBar = {
            ExpressTopBar(
                title = AppStrings.t("app_title", currentLang),
                currentRole = null
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Hero Brand Cloche
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(ExpressRed),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.DeliveryDining,
                    contentDescription = "Express Cloche",
                    tint = PureWhite,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = AppStrings.t("app_title", currentLang),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = ExpressRed
            )
            Text(
                text = AppStrings.t("app_tagline", currentLang),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Customer Choice
            GatewayRoleCard(
                title = AppStrings.t("role_customer", currentLang),
                subtitle = "Discover top restaurants, order food, track orders & earn 15 coins per ₹100",
                icon = Icons.Default.RestaurantMenu,
                iconBg = ExpressRedLight,
                iconColor = ExpressRed,
                testTag = "btn_gateway_customer",
                onClick = onSelectCustomer
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Restaurant Partner Choice
            GatewayRoleCard(
                title = AppStrings.t("role_restaurant", currentLang),
                subtitle = "Manage menu, original prices (+₹20 markup), kitchen orders & payouts",
                icon = Icons.Default.Storefront,
                iconBg = SpiceAmberLight,
                iconColor = SpiceAmber,
                testTag = "btn_gateway_restaurant",
                onClick = onSelectRestaurant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Delivery Partner Choice
            GatewayRoleCard(
                title = AppStrings.t("role_delivery", currentLang),
                subtitle = "Admin-assigned orders, route map, duty status & 100% tips",
                icon = Icons.Default.TwoWheeler,
                iconBg = FreshGreenLight,
                iconColor = FreshGreen,
                testTag = "btn_gateway_delivery",
                onClick = onSelectDelivery
            )

            Spacer(modifier = Modifier.height(32.dp))

            HorizontalDivider()

            Spacer(modifier = Modifier.height(20.dp))

            // Dedicated Separate Admin Access Button
            OutlinedButton(
                onClick = onSelectAdmin,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_gateway_admin"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.onSurface
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Portal",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.t("role_admin", currentLang),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun GatewayRoleCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: androidx.compose.ui.graphics.Color,
    iconColor: androidx.compose.ui.graphics.Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                    maxLines = 2
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        }
    }
}

@Composable
fun RoleSpecificLoginScreen(
    targetRole: UserRole,
    title: String,
    onLoginSuccess: () -> Unit,
    onBack: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    var identifier by remember {
        mutableStateOf(
            when (targetRole) {
                UserRole.CUSTOMER -> "customer@expressfood.in"
                UserRole.RESTAURANT -> "dilli@expressfood.in"
                UserRole.DELIVERY_PARTNER -> "ramesh@expressfood.in"
                UserRole.ADMIN -> "admin@expressfood.in"
            }
        )
    }

    var password by remember {
        mutableStateOf(
            when (targetRole) {
                UserRole.CUSTOMER -> "customer123"
                UserRole.RESTAURANT -> "rest123"
                UserRole.DELIVERY_PARTNER -> "partner123"
                UserRole.ADMIN -> "Admin@2026"
            }
        )
    }

    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    // Registration state for Customer
    var isRegistering by remember { mutableStateOf(false) }
    var regName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }

    // Forgot password state
    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var forgotIdentifier by remember { mutableStateOf("") }
    var forgotNewPassword by remember { mutableStateOf("") }
    var forgotConfirmPassword by remember { mutableStateOf("") }
    var forgotStatusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            ExpressTopBar(
                title = title,
                currentRole = null,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isRegistering) AppStrings.t("register", currentLang) else AppStrings.t("login", currentLang),
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = when (targetRole) {
                    UserRole.CUSTOMER -> "Login with Email or Mobile Number"
                    UserRole.RESTAURANT -> "Restaurant Portal (Email or Mobile)"
                    UserRole.DELIVERY_PARTNER -> "Delivery Partner Portal (Email or Mobile)"
                    UserRole.ADMIN -> "Authorized Admin Only (Email)"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )

            if (targetRole == UserRole.ADMIN) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = AppStrings.t("admin_login_instructions", currentLang),
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = ExpressRedDark
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            if (successMessage != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FreshGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = successMessage ?: "",
                        color = FreshGreen,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            if (isRegistering && targetRole == UserRole.CUSTOMER) {
                OutlinedTextField(
                    value = regName,
                    onValueChange = { regName = it },
                    label = { Text(AppStrings.t("full_name", currentLang)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_reg_name"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = regPhone,
                    onValueChange = { regPhone = it },
                    label = { Text(AppStrings.t("phone", currentLang)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_reg_phone"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Identifier Input: Supports Email OR Mobile Number
            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it },
                label = {
                    Text(
                        if (targetRole == UserRole.ADMIN) "Admin Email"
                        else "Email or Mobile Number"
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = if (identifier.contains("@")) Icons.Default.Email else Icons.Default.Phone,
                        contentDescription = null
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_login_email"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Password Input with Show/Hide toggle
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(AppStrings.t("password", currentLang)) },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_login_password"),
                singleLine = true
            )

            // Forgot Password Link
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = {
                        forgotIdentifier = identifier
                        forgotStatusMessage = null
                        showForgotPasswordDialog = true
                    },
                    modifier = Modifier.testTag("btn_forgot_password")
                ) {
                    Text(
                        text = "Forgot Password?",
                        fontSize = 12.sp,
                        color = ExpressRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    errorMessage = null
                    successMessage = null
                    isLoading = true

                    if (isRegistering && targetRole == UserRole.CUSTOMER) {
                        if (regName.isBlank() || identifier.isBlank() || password.isBlank()) {
                            errorMessage = "Please fill in all registration fields"
                            isLoading = false
                        } else {
                            ExpressRepository.registerCustomer(regName, identifier, regPhone, password)
                            isLoading = false
                            onLoginSuccess()
                        }
                    } else {
                        val authResult = ExpressRepository.authenticate(identifier, password, targetRole)
                        isLoading = false
                        when (authResult) {
                            is LoginResult.Success, is LoginResult.MustChangePassword -> {
                                onLoginSuccess()
                            }
                            is LoginResult.AccountBlocked -> {
                                errorMessage = authResult.reason
                            }
                            is LoginResult.InvalidCredentials -> {
                                errorMessage = authResult.message
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_submit_login"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (targetRole == UserRole.ADMIN) MaterialTheme.colorScheme.onSurface else ExpressRed
                ),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = PureWhite,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = if (isRegistering) AppStrings.t("register", currentLang) else AppStrings.t("login", currentLang),
                        fontWeight = FontWeight.Bold,
                        color = PureWhite
                    )
                }
            }

            if (targetRole == UserRole.CUSTOMER) {
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    onClick = {
                        isRegistering = !isRegistering
                        errorMessage = null
                    },
                    modifier = Modifier.testTag("btn_toggle_register")
                ) {
                    Text(
                        text = if (isRegistering) "Already have an account? Login" else "New to Express Food? Register",
                        color = ExpressRed
                    )
                }
            }
        }
    }

    // Customer / Partner Forgot Password Dialog
    if (showForgotPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showForgotPasswordDialog = false },
            title = {
                Text(
                    text = "Password Recovery",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enter your registered Email or Mobile number to reset password.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = forgotIdentifier,
                        onValueChange = { forgotIdentifier = it },
                        label = { Text("Email or Mobile Number") },
                        modifier = Modifier.fillMaxWidth().testTag("input_forgot_id"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = forgotNewPassword,
                        onValueChange = { forgotNewPassword = it },
                        label = { Text("New Password (min 6 chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("input_forgot_new_pass"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = forgotConfirmPassword,
                        onValueChange = { forgotConfirmPassword = it },
                        label = { Text("Confirm New Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("input_forgot_confirm_pass"),
                        singleLine = true
                    )

                    if (forgotStatusMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = forgotStatusMessage ?: "",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (forgotNewPassword != forgotConfirmPassword) {
                            forgotStatusMessage = "Passwords do not match."
                        } else if (forgotNewPassword.length < 6) {
                            forgotStatusMessage = "Password must be at least 6 characters."
                        } else {
                            val res = ExpressRepository.recoverCustomerPassword(forgotIdentifier, forgotNewPassword)
                            res.onSuccess { msg ->
                                successMessage = msg
                                password = forgotNewPassword
                                showForgotPasswordDialog = false
                            }.onFailure { err ->
                                forgotStatusMessage = err.message
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_confirm_forgot_password")
                ) {
                    Text("Reset Password", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPasswordDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
