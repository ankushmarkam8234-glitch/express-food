package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ExpressRed = Color(0xFFE23744)
val ExpressRedDark = Color(0xFFC21828)
val ExpressRedLight = Color(0xFFFFECEE)

val SpiceAmber = Color(0xFFFF7E29)
val SpiceAmberLight = Color(0xFFFFF3E0)

val FreshGreen = Color(0xFF2E7D32)
val FreshGreenDark = Color(0xFF1B5E20)
val FreshGreenLight = Color(0xFFE8F5E9)

val PureWhite = Color(0xFFFFFFFF)
val WarmBackground = Color(0xFFF8F9FA)
val CardSurface = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1F1F1F)
val TextSecondary = Color(0xFF6F7280)
val BorderLight = Color(0xFFE5E7EB)

val DarkSurface = Color(0xFF18191A)
val DarkBackground = Color(0xFF121212)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextSecondary = Color(0xFF9CA3AF)
