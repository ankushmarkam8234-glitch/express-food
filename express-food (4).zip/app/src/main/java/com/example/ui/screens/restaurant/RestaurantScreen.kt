package com.example.ui.screens.restaurant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.example.data.ExpressRepository
import com.example.localization.AppStrings
import com.example.model.*
import com.example.ui.components.ExpressTopBar
import com.example.ui.components.DirectCallButton
import com.example.ui.components.DialPhoneIconButton
import com.example.ui.components.InAppNotificationBanner
import com.example.ui.theme.*

@Composable
fun RestaurantMainScreen(
    onLogout: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()
    val restaurants by ExpressRepository.restaurants.collectAsState()
    val allOrders by ExpressRepository.orders.collectAsState()
    val allMenuItems by ExpressRepository.menuItems.collectAsState()

    // Find restaurant associated with this user
    val restaurant = restaurants.find { it.id == user?.assignedEntityId } ?: restaurants.firstOrNull()

    var selectedTab by remember { mutableStateOf(0) } // 0: Orders, 1: Menu Management, 2: Sales & Settlements

    if (restaurant == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No restaurant assigned to this account.")
        }
        return
    }

    val restaurantOrders = allOrders.filter { it.restaurantId == restaurant.id }
    val menuItems = allMenuItems.filter { it.restaurantId == restaurant.id }

    Scaffold(
        topBar = {
            ExpressTopBar(
                title = restaurant.name,
                currentRole = UserRole.RESTAURANT,
                onLogout = onLogout
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Receipt, contentDescription = "Orders") },
                    label = { Text("Kitchen Orders", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_restaurant_orders")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Menu") },
                    label = { Text(AppStrings.t("manage_menu", currentLang), fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_restaurant_menu")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Sales") },
                    label = { Text("Sales & Ledger", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_restaurant_sales")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Restaurant Header Status Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (restaurant.isOpen) AppStrings.t("restaurant_status_open", currentLang) else AppStrings.t("restaurant_status_closed", currentLang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (restaurant.isOpen) FreshGreen else MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = "📍 " + restaurant.address + " (GPS: ${restaurant.lat}, ${restaurant.lng})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        val minsAgo = if (restaurant.lastStatusUpdatedAt > 0L) (System.currentTimeMillis() - restaurant.lastStatusUpdatedAt) / 60000 else 0
                        Text(
                            text = "Last status update: ${if (minsAgo < 1) "Just now" else "$minsAgo min ago"}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }

                    Switch(
                        checked = restaurant.isOpen,
                        onCheckedChange = { ExpressRepository.toggleRestaurantStatus(restaurant.id) },
                        modifier = Modifier.testTag("switch_restaurant_status")
                    )
                }
            }

            // Realtime in-app notification banner for new orders with sound alert
            InAppNotificationBanner(
                recipientRole = UserRole.RESTAURANT,
                recipientEntityId = restaurant.id
            )

            when (selectedTab) {
                0 -> RestaurantKitchenOrdersTab(restaurant = restaurant, orders = restaurantOrders)
                1 -> RestaurantMenuManagementTab(restaurant = restaurant, items = menuItems)
                2 -> RestaurantSalesSettlementTab(restaurant = restaurant, orders = restaurantOrders)
            }
        }
    }
}

@Composable
fun RestaurantKitchenOrdersTab(
    restaurant: Restaurant,
    orders: List<Order>
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = AppStrings.t("incoming_orders", currentLang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (orders.isEmpty()) {
            item {
                Text("No orders currently active.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }

        items(orders) { order ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Order #${order.id}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = ExpressRedLight
                        ) {
                            Text(
                                text = AppStrings.t("status_" + order.orderStatus.name.lowercase(), currentLang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpressRedDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Customer: ${order.customerName} (${order.customerPhone})",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    if (order.assignedDeliveryPartnerName != null) {
                        Text(
                            text = "Delivery Partner: ${order.assignedDeliveryPartnerName} (${order.assignedDeliveryPartnerPhone ?: "N/A"})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    val isActiveOrder = order.orderStatus !in listOf(OrderStatus.CANCELLED, OrderStatus.REJECTED)
                    val hasDpPhone = !order.assignedDeliveryPartnerPhone.isNullOrBlank()

                    if (isActiveOrder) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (hasDpPhone) {
                                DirectCallButton(
                                    phoneNumber = order.assignedDeliveryPartnerPhone,
                                    label = AppStrings.t("call_delivery_partner", currentLang),
                                    modifier = Modifier.weight(1f),
                                    testTag = "btn_rest_call_dp_${order.id}",
                                    containerColor = FreshGreen
                                )
                            }
                            if (order.customerPhone.isNotBlank()) {
                                DirectCallButton(
                                    phoneNumber = order.customerPhone,
                                    label = AppStrings.t("call_customer", currentLang),
                                    modifier = Modifier.weight(1f),
                                    testTag = "btn_rest_call_cust_${order.id}",
                                    containerColor = SpiceAmber
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    order.items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${item.menuItem.name} × ${item.quantity}", fontSize = 13.sp)
                            Text(text = "₹${item.itemSubtotal}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Action buttons according to state
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        when (order.orderStatus) {
                            OrderStatus.ORDER_PLACED -> {
                                OutlinedButton(
                                    onClick = { ExpressRepository.updateOrderStatus(order.id, OrderStatus.REJECTED, "Rejected by restaurant") },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("btn_reject_${order.id}")
                                ) {
                                    Text(AppStrings.t("reject_order", currentLang), fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { ExpressRepository.updateOrderStatus(order.id, OrderStatus.RESTAURANT_ACCEPTED, "Accepted by restaurant") },
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("btn_accept_${order.id}")
                                ) {
                                    Text(AppStrings.t("accept_order", currentLang), fontSize = 12.sp, color = PureWhite)
                                }
                            }

                            OrderStatus.RESTAURANT_ACCEPTED -> {
                                Button(
                                    onClick = { ExpressRepository.updateOrderStatus(order.id, OrderStatus.PREPARING, "Started cooking in kitchen") },
                                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("btn_preparing_${order.id}")
                                ) {
                                    Text(AppStrings.t("mark_preparing", currentLang), fontSize = 12.sp, color = PureWhite)
                                }
                            }

                            OrderStatus.PREPARING -> {
                                Button(
                                    onClick = { ExpressRepository.updateOrderStatus(order.id, OrderStatus.READY_FOR_PICKUP, "Packed and ready for pickup") },
                                    colors = ButtonDefaults.buttonColors(containerColor = SpiceAmber),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("btn_ready_${order.id}")
                                ) {
                                    Text(AppStrings.t("mark_ready", currentLang), fontSize = 12.sp, color = PureWhite)
                                }
                            }

                            else -> {
                                Text(
                                    text = "Status: ${order.orderStatus.name}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RestaurantMenuManagementTab(
    restaurant: Restaurant,
    items: List<MenuItem>
) {
    val context = LocalContext.current
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var newCat by remember { mutableStateOf("Main Course") }
    var newOriginalPrice by remember { mutableStateOf("") }
    var newIsVeg by remember { mutableStateOf(true) }
    var selectedPhotoUri by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Main Course", "Starters", "Biryani", "North Indian", "South Indian", "Desserts", "Beverages", "Snacks")

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedPhotoUri = uri.toString()
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            try {
                val file = java.io.File(context.cacheDir, "dish_${System.currentTimeMillis()}.jpg")
                file.outputStream().use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                selectedPhotoUri = file.toURI().toString()
            } catch (_: Exception) {}
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    newName = ""
                    newDesc = ""
                    newCat = "Main Course"
                    newOriginalPrice = ""
                    newIsVeg = true
                    selectedPhotoUri = null
                    showAddDialog = true
                },
                containerColor = ExpressRed,
                modifier = Modifier.testTag("fab_add_menu_item")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Dish", tint = PureWhite)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = AppStrings.t("manage_menu", currentLang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Markup rule: Enter your original price; ₹20 Express Food markup is added automatically for the customer.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("menu_item_card_${item.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Food Photo thumbnail
                        if (item.imageUrl.isNotBlank()) {
                            AsyncImage(
                                model = item.imageUrl,
                                contentDescription = item.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Restaurant,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (item.isVeg) "🟢" else "🔴",
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = item.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            Text(
                                text = "${item.category} • ${item.description}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Original: ₹${item.originalPrice} | Selling Price: ₹${item.customerPrice} (+₹${item.markupAmount})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ExpressRed
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (item.isAvailable) "In Stock" else "Out",
                                fontSize = 10.sp,
                                color = if (item.isAvailable) FreshGreen else MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = item.isAvailable,
                                onCheckedChange = { ExpressRepository.toggleMenuItemStock(item.id) },
                                modifier = Modifier.testTag("switch_stock_${item.id}")
                            )
                            IconButton(
                                onClick = { ExpressRepository.deleteMenuItem(item.id) },
                                modifier = Modifier.testTag("btn_delete_item_${item.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(AppStrings.t("add_item", currentLang)) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Photo Upload section
                    Text("Dish Photo (Gallery or Camera)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    if (selectedPhotoUri != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(8.dp)
                        ) {
                            AsyncImage(
                                model = selectedPhotoUri,
                                contentDescription = "Dish preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Photo attached", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FreshGreen)
                                Text("Will be shown on customer menu", fontSize = 10.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { selectedPhotoUri = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove photo", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    galleryLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.weight(1f).testTag("btn_upload_dish_gallery"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Gallery", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = { cameraLauncher.launch(null) },
                                modifier = Modifier.weight(1f).testTag("btn_upload_dish_camera"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Camera", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text(AppStrings.t("dish_name", currentLang)) },
                        modifier = Modifier.fillMaxWidth().testTag("input_new_dish_name"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newDesc,
                        onValueChange = { newDesc = it },
                        label = { Text(AppStrings.t("dish_desc", currentLang)) },
                        modifier = Modifier.fillMaxWidth().testTag("input_new_dish_desc"),
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Category Selector
                    Text("Category: $newCat", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Main Course", "Biryani", "Starters", "Desserts").forEach { cat ->
                            FilterChip(
                                selected = newCat == cat,
                                onClick = { newCat = cat },
                                label = { Text(cat, fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newOriginalPrice,
                        onValueChange = { newOriginalPrice = it.filter { c -> c.isDigit() } },
                        label = { Text(AppStrings.t("dish_original_price", currentLang)) },
                        placeholder = { Text("e.g. 150") },
                        modifier = Modifier.fillMaxWidth().testTag("input_new_dish_price"),
                        singleLine = true
                    )

                    val enteredPrice = newOriginalPrice.toIntOrNull() ?: 0
                    if (enteredPrice > 0) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = CardDefaults.cardColors(containerColor = FreshGreenLight)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "Original Restaurant Price: ₹$enteredPrice",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                                Text(
                                    text = "Customer Selling Price: ₹${enteredPrice + 20} (₹20 markup added automatically)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FreshGreenDark
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = newIsVeg, onCheckedChange = { newIsVeg = it })
                        Text("Vegetarian dish (🟢 Veg)", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val orig = newOriginalPrice.toIntOrNull() ?: 0
                        if (newName.isNotBlank() && orig > 0) {
                            ExpressRepository.addMenuItem(
                                restaurantId = restaurant.id,
                                name = newName,
                                description = newDesc,
                                category = newCat,
                                originalPrice = orig,
                                isVeg = newIsVeg,
                                imageUrl = selectedPhotoUri ?: ""
                            )
                        }
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                    modifier = Modifier.testTag("btn_save_new_dish")
                ) {
                    Text(AppStrings.t("save", currentLang), color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text(AppStrings.t("cancel", currentLang))
                }
            }
        )
    }
}

@Composable
fun RestaurantSalesSettlementTab(
    restaurant: Restaurant,
    orders: List<Order>
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    val completedOrders = orders.filter { it.orderStatus == OrderStatus.DELIVERED }
    val totalFoodSales = completedOrders.sumOf { it.subtotal }
    val totalCommission = completedOrders.size * 10 // ₹10 per eligible completed order
    val netSettlement = totalFoodSales - totalCommission

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Sales, Commission & Settlements",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("todays_orders", currentLang))
                        Text("${orders.size} (${completedOrders.size} completed)", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("net_sales", currentLang))
                        Text("₹$totalFoodSales", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("restaurant_commission_label", currentLang))
                        Text("-₹$totalCommission", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("net_payout", currentLang), fontWeight = FontWeight.ExtraBold)
                        Text("₹$netSettlement", color = FreshGreen, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "Settlement Ledger Rules",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = "• ₹10 Commission per completed order is settled weekly into restaurant bank account.\n" +
                        "• Express Food Owner Commission (₹10) is maintained on an independent audit ledger.\n" +
                        "• Customer tip is transferred 100% to the delivery partner and not deducted from restaurant.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
