package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExpressRepository
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.PriceCalculation
import com.example.model.UserRole
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpressTopBar(
    title: String,
    currentRole: UserRole?,
    onLogout: () -> Unit = {},
    onBack: (() -> Unit)? = null
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    var showSetupDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("btn_top_bar_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(ExpressRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fastfood,
                                contentDescription = "Express Logo",
                                tint = PureWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = ExpressRedLight,
                                modifier = Modifier
                                    .clickable { showSetupDialog = true }
                                    .testTag("tag_demo_badge")
                            ) {
                                Text(
                                    text = AppStrings.t("demo_mode_badge", currentLang) + " ℹ️",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ExpressRedDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                // Language toggle button & user status
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Visible Hindi/English switcher
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .clickable {
                                val next = if (currentLang == AppLanguage.HINDI) AppLanguage.ENGLISH else AppLanguage.HINDI
                                ExpressRepository.setLanguage(next)
                            }
                            .testTag("btn_language_toggle")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Language",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (currentLang == AppLanguage.HINDI) "English" else "हिन्दी",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    if (currentRole != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { showChangePasswordDialog = true },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("btn_topbar_change_password")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = AppStrings.t("change_password", currentLang),
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("btn_logout")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Logout",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSetupDialog) {
        SetupGuideDialog(
            currentLang = currentLang,
            onDismiss = { showSetupDialog = false }
        )
    }

    if (showChangePasswordDialog) {
        ChangePasswordDialog(
            currentLang = currentLang,
            onDismiss = { showChangePasswordDialog = false }
        )
    }
}

@Composable
fun PriceBreakdownCard(
    calc: PriceCalculation,
    currentLang: AppLanguage,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = AppStrings.t("to_pay", currentLang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            PriceRow(
                label = AppStrings.t("item_subtotal", currentLang),
                amount = "₹${calc.subtotal}",
                subtitle = AppStrings.t("markup_info", currentLang)
            )

            PriceRow(
                label = AppStrings.t("delivery_fee", currentLang),
                amount = "₹${calc.deliveryFee}"
            )

            if (calc.deliveryFeeDiscount > 0) {
                PriceRow(
                    label = AppStrings.t("delivery_discount", currentLang),
                    amount = "-₹${calc.deliveryFeeDiscount}",
                    isDiscount = true
                )
            }

            PriceRow(
                label = AppStrings.t("platform_fee", currentLang),
                amount = "₹${calc.platformFee}",
                subtitle = "Fixed platform maintenance"
            )

            if (calc.tipAmount > 0) {
                PriceRow(
                    label = AppStrings.t("delivery_tip", currentLang),
                    amount = "+₹${calc.tipAmount}",
                    subtitle = AppStrings.t("tip_note", currentLang)
                )
            }

            if (calc.coinDiscount > 0) {
                PriceRow(
                    label = AppStrings.t("coins_redeemed", currentLang),
                    amount = "-₹${calc.coinDiscount} (${calc.coinsToRedeem} coins)",
                    isDiscount = true
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.t("to_pay", currentLang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "₹${calc.totalAmount}",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                    color = ExpressRed
                )
            }
        }
    }
}

@Composable
fun PriceRow(
    label: String,
    amount: String,
    subtitle: String? = null,
    isDiscount: Boolean = false
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = amount,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = if (isDiscount) FreshGreen else MaterialTheme.colorScheme.onSurface
            )
        }
        if (subtitle != null) {
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = if (isDiscount) FreshGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun SetupGuideDialog(
    currentLang: AppLanguage,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = ExpressRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.t("setup_guide_title", currentLang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = AppStrings.t("setup_firebase_title", currentLang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = AppStrings.t("setup_firebase_desc", currentLang),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = AppStrings.t("setup_razorpay_title", currentLang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = AppStrings.t("setup_razorpay_desc", currentLang),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = AppStrings.t("setup_maps_title", currentLang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = AppStrings.t("setup_maps_desc", currentLang),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ExpressRed)
            ) {
                Text(AppStrings.t("close", currentLang), color = PureWhite)
            }
        }
    )
}

// IN-APP DIRECT CALL HELPER (Using Android Device Phone Dialer via tel: Intent)
object PhoneCallHelper {
    fun dial(context: Context, rawPhone: String?): Boolean {
        val sanitized = rawPhone?.filter { it.isDigit() || it == '+' }
        if (sanitized.isNullOrBlank() || sanitized.filter { it.isDigit() }.length < 5) {
            Toast.makeText(context, "Phone number is not available or incomplete.", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$sanitized")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open dialer: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}

@Composable
fun DirectCallButton(
    phoneNumber: String?,
    label: String = "Call",
    modifier: Modifier = Modifier,
    testTag: String = "btn_direct_call",
    containerColor: Color = FreshGreen,
    contentColor: Color = PureWhite
) {
    val context = LocalContext.current
    val isValid = !phoneNumber.isNullOrBlank() && phoneNumber.filter { it.isDigit() }.length >= 5

    Button(
        onClick = {
            PhoneCallHelper.dial(context, phoneNumber)
        },
        modifier = modifier
            .defaultMinSize(minHeight = 48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isValid) containerColor else Color.Gray,
            contentColor = contentColor
        ),
        enabled = isValid
    ) {
        Icon(
            imageVector = Icons.Default.Phone,
            contentDescription = label,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DialPhoneIconButton(
    phoneNumber: String?,
    contentDescription: String = "Call",
    modifier: Modifier = Modifier,
    testTag: String = "btn_call_icon",
    tint: Color = FreshGreen
) {
    val context = LocalContext.current
    val isValid = !phoneNumber.isNullOrBlank() && phoneNumber.filter { it.isDigit() }.length >= 5

    IconButton(
        onClick = {
            PhoneCallHelper.dial(context, phoneNumber)
        },
        modifier = modifier
            .size(48.dp)
            .testTag(testTag),
        enabled = isValid
    ) {
        Icon(
            imageVector = Icons.Default.Phone,
            contentDescription = contentDescription,
            tint = if (isValid) tint else Color.Gray.copy(alpha = 0.4f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun ChangePasswordDialog(
    currentLang: AppLanguage,
    onDismiss: () -> Unit
) {
    val currentUser by ExpressRepository.currentUser.collectAsState()
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = ExpressRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.t("change_password", currentLang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Update your account password. Must be at least 6 characters.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text(AppStrings.t("new_password", currentLang)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_settings_new_password")
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text(AppStrings.t("confirm_password", currentLang)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_settings_confirm_password")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                if (successMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = successMessage ?: "",
                        fontSize = 12.sp,
                        color = FreshGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    errorMessage = null
                    val usr = currentUser
                    if (usr == null) {
                        errorMessage = "User not logged in"
                    } else if (newPassword.length < 6) {
                        errorMessage = "Password must be at least 6 characters"
                    } else if (newPassword != confirmPassword) {
                        errorMessage = "Passwords do not match"
                    } else {
                        val res = ExpressRepository.changeUserPassword(usr.id, newPassword)
                        res.onSuccess {
                            successMessage = AppStrings.t("password_changed_success", currentLang)
                        }.onFailure { err ->
                            errorMessage = err.message ?: "Failed to update password"
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                modifier = Modifier.testTag("btn_save_settings_password")
            ) {
                Text(AppStrings.t("save_password", currentLang), color = PureWhite)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_cancel_settings_password")
            ) {
                Text(AppStrings.t("close", currentLang))
            }
        }
    )
}

// NOTIFICATION SOUND & ALERT HELPER
object NotificationSoundHelper {
    fun playNotificationSound(context: Context) {
        if (!ExpressRepository.isSoundEnabled.value) return
        try {
            val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val ringtone = RingtoneManager.getRingtone(context.applicationContext, alertUri)
            ringtone?.play()
        } catch (_: Exception) {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
            } catch (_: Exception) {}
        }
    }
}

@Composable
fun InAppNotificationBanner(
    recipientRole: UserRole,
    recipientEntityId: String? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allNotifications by ExpressRepository.notifications.collectAsState()
    val isSoundEnabled by ExpressRepository.isSoundEnabled.collectAsState()

    // Filter relevant notifications for this screen/role
    val relevant = allNotifications.filter { notif ->
        notif.recipientRole == recipientRole &&
        (recipientEntityId == null || notif.recipientEntityId == null || notif.recipientEntityId == recipientEntityId)
    }

    val latestNotification = relevant.firstOrNull()

    // Sound alert effect whenever the latest notification ID changes
    LaunchedEffect(latestNotification?.id) {
        if (latestNotification != null) {
            NotificationSoundHelper.playNotificationSound(context)
        }
    }

    if (latestNotification != null) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("in_app_notification_card"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SpiceAmberLight),
            border = BorderStroke(1.dp, SpiceAmber)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SpiceAmber),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Notification",
                        tint = PureWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = latestNotification.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SpiceAmber
                    )
                    Text(
                        text = latestNotification.message,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Sound toggle button
                IconButton(
                    onClick = { ExpressRepository.toggleSoundEnabled() },
                    modifier = Modifier.size(32.dp).testTag("btn_toggle_notif_sound")
                ) {
                    Icon(
                        imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = if (isSoundEnabled) "Mute Sound" else "Unmute Sound",
                        tint = if (isSoundEnabled) FreshGreen else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Dismiss button
                IconButton(
                    onClick = { ExpressRepository.dismissNotification(latestNotification.id) },
                    modifier = Modifier.size(32.dp).testTag("btn_dismiss_notif")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

