package com.example.ui.screens.delivery

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExpressRepository
import com.example.localization.AppStrings
import com.example.model.*
import com.example.ui.components.ExpressTopBar
import com.example.ui.components.DirectCallButton
import com.example.ui.components.DialPhoneIconButton
import com.example.ui.components.InAppNotificationBanner
import com.example.ui.theme.*
import kotlin.math.ceil

@Composable
fun DeliveryMainScreen(
    onLogout: () -> Unit
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val user by ExpressRepository.currentUser.collectAsState()
    val partners by ExpressRepository.deliveryPartners.collectAsState()
    val allOrders by ExpressRepository.orders.collectAsState()

    val partner = partners.find { it.id == user?.assignedEntityId } ?: partners.firstOrNull()

    var selectedTab by remember { mutableStateOf(0) } // 0: Assigned Deliveries, 1: Earnings & Tips

    if (partner == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No delivery partner account found.")
        }
        return
    }

    // Only orders assigned to THIS delivery partner
    val assignedOrders = allOrders.filter { it.assignedDeliveryPartnerId == partner.id }

    Scaffold(
        topBar = {
            ExpressTopBar(
                title = "${partner.name} (${partner.code})",
                currentRole = UserRole.DELIVERY_PARTNER,
                onLogout = onLogout
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Moped, contentDescription = "Deliveries") },
                    label = { Text("My Deliveries", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_delivery_tasks")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Payments, contentDescription = "Earnings") },
                    label = { Text("Earnings & Tips", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_delivery_earnings")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Online/Offline Duty Header
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (partner.isOnline) AppStrings.t("partner_online", currentLang) else AppStrings.t("partner_offline", currentLang),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (partner.isOnline) FreshGreen else MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = AppStrings.t("partner_code_label", currentLang, partner.code),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        val minsAgo = if (partner.lastStatusUpdatedAt > 0L) (System.currentTimeMillis() - partner.lastStatusUpdatedAt) / 60000 else 0
                        Text(
                            text = "Status: ${if (partner.isOnline) "🟢 On Duty" else "⚪ Off Duty"} • ${if (minsAgo < 1) "Just now" else "$minsAgo min ago"}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }

                    Switch(
                        checked = partner.isOnline,
                        onCheckedChange = { ExpressRepository.toggleDeliveryPartnerAvailability(partner.id) },
                        modifier = Modifier.testTag("switch_partner_online")
                    )
                }
            }

            // Warning if partner is offline with an active delivery
            val activeAssigned = assignedOrders.filter { it.orderStatus !in listOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.FAILED) }
            if (!partner.isOnline && activeAssigned.isNotEmpty()) {
                Surface(
                    color = SpiceAmberLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚠️", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "You are currently Off Duty, but have an active delivery (#${activeAssigned.first().id}). You can finish and deliver this order, but cannot receive new assignments.",
                            fontSize = 11.sp,
                            color = SpiceAmber,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Realtime in-app notification banner for assigned orders with sound alert
            InAppNotificationBanner(
                recipientRole = UserRole.DELIVERY_PARTNER,
                recipientEntityId = partner.id
            )

            when (selectedTab) {
                0 -> DeliveryAssignedOrdersTab(partner = partner, orders = assignedOrders)
                1 -> DeliveryEarningsTab(partner = partner, orders = assignedOrders)
            }
        }
    }
}

@Composable
fun DeliveryAssignedOrdersTab(
    partner: DeliveryPartner,
    orders: List<Order>
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()
    val restaurants by ExpressRepository.restaurants.collectAsState()

    val activeOrders = orders.filter { it.orderStatus !in listOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.FAILED) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = AppStrings.t("assigned_orders", currentLang),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (activeOrders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🛵", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = AppStrings.t("no_assigned_orders", currentLang),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        items(activeOrders) { order ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Order #${order.id}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = ExpressRedLight
                        ) {
                            Text(
                                text = AppStrings.t("status_" + order.orderStatus.name.lowercase(), currentLang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ExpressRedDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Payment Status Banner (Strict Cash on Delivery vs Online Paid rules)
                    if (order.paymentMethod == PaymentMethod.ONLINE) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = FreshGreenLight,
                            border = BorderStroke(1.5.dp, FreshGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("payment_banner_online_${order.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FreshGreenDark, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "ONLINE PAID — PAYMENT RECEIVED",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = FreshGreenDark,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "DO NOT COLLECT ANY CASH FROM CUSTOMER",
                                        fontWeight = FontWeight.Bold,
                                        color = FreshGreenDark,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SpiceAmberLight,
                            border = BorderStroke(1.5.dp, SpiceAmber),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("payment_banner_cod_${order.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = SpiceAmber, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "COD — CASH ON DELIVERY",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SpiceAmber,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "COLLECT ₹${order.totalAmount} CASH FROM CUSTOMER",
                                        fontWeight = FontWeight.Bold,
                                        color = SpiceAmber,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Pickup info
                    Row(verticalAlignment = Alignment.Top) {
                        Text(text = "🏪", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(text = AppStrings.t("pickup_from", currentLang), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(text = order.restaurantName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = order.restaurantAddress, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Drop info
                    Row(verticalAlignment = Alignment.Top) {
                        Text(text = "📍", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(text = AppStrings.t("deliver_to", currentLang), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(text = "${order.customerName} (${order.customerPhone})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = order.deliveryAddress, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Food items and quantities
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Food Items (${order.items.sumOf { it.quantity }} items):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            order.items.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${item.menuItem.name} × ${item.quantity}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "₹${item.menuItem.customerPrice * item.quantity}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Order Value:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("₹${order.totalAmount}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = ExpressRed)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Route Distance & Earnings at ₹17/km
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Delivery Distance: ${order.distanceKm} km (Rate: ₹${order.deliveryPartnerRatePerKm}/km)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Your Earnings: ₹${order.deliveryPartnerEarnings}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FreshGreen
                                )
                            }
                            if (order.tipAmount > 0) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = FreshGreenLight
                                ) {
                                    Text(
                                        text = "+₹${order.tipAmount} Tip",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FreshGreenDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // In-app direct contact buttons
                    val rest = restaurants.find { it.id == order.restaurantId }
                    val restPhone = rest?.phone
                    val custPhone = order.customerPhone

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DirectCallButton(
                            phoneNumber = restPhone,
                            label = AppStrings.t("call_restaurant", currentLang),
                            modifier = Modifier.weight(1f),
                            testTag = "btn_dp_call_restaurant_${order.id}",
                            containerColor = ExpressRedDark
                        )
                        DirectCallButton(
                            phoneNumber = custPhone,
                            label = AppStrings.t("call_customer", currentLang),
                            modifier = Modifier.weight(1f),
                            testTag = "btn_dp_call_customer_${order.id}",
                            containerColor = FreshGreen
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    // Delivery Action Progress Buttons (Assigned -> Accepted -> Picked Up -> Delivered)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        when (order.orderStatus) {
                            OrderStatus.DELIVERY_PARTNER_ASSIGNED, OrderStatus.READY_FOR_PICKUP -> {
                                Button(
                                    onClick = { ExpressRepository.updateDeliveryPartnerStatus(order.id, OrderStatus.PICKED_UP) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ExpressRed),
                                    modifier = Modifier.weight(1f).testTag("btn_dp_pickup_${order.id}")
                                ) {
                                    Text(AppStrings.t("action_pickup", currentLang), color = PureWhite, fontSize = 12.sp)
                                }
                            }

                            OrderStatus.PICKED_UP -> {
                                Button(
                                    onClick = { ExpressRepository.updateDeliveryPartnerStatus(order.id, OrderStatus.ON_THE_WAY) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SpiceAmber),
                                    modifier = Modifier.weight(1f).testTag("btn_dp_on_the_way_${order.id}")
                                ) {
                                    Text(AppStrings.t("action_on_the_way", currentLang), color = PureWhite, fontSize = 12.sp)
                                }
                            }

                            OrderStatus.ON_THE_WAY -> {
                                OutlinedButton(
                                    onClick = { ExpressRepository.updateDeliveryPartnerStatus(order.id, OrderStatus.FAILED) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.weight(0.4f).testTag("btn_dp_fail_${order.id}")
                                ) {
                                    Text("Fail", fontSize = 12.sp)
                                }
                                Button(
                                    onClick = { ExpressRepository.updateDeliveryPartnerStatus(order.id, OrderStatus.DELIVERED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                                    modifier = Modifier.weight(0.6f).testTag("btn_dp_deliver_${order.id}")
                                ) {
                                    Text(AppStrings.t("action_deliver", currentLang), color = PureWhite, fontSize = 12.sp)
                                }
                            }

                            else -> {
                                Text(
                                    text = "Status: ${order.orderStatus.name}",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeliveryEarningsTab(
    partner: DeliveryPartner,
    orders: List<Order>
) {
    val currentLang by ExpressRepository.currentLanguage.collectAsState()

    val completed = orders.filter { it.orderStatus == OrderStatus.DELIVERED }
    val base = completed.sumOf { it.deliveryPartnerEarnings }
    val tips = completed.sumOf { it.tipAmount }
    val total = base + tips

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "My Earnings & Settlements",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Earnings calculated strictly at ₹17 per kilometre. Never derived from food prices.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("total_deliveries_label", currentLang, completed.size))
                        Text("Rating: ★ ${partner.rating}", fontWeight = FontWeight.Bold, color = SpiceAmber)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Base Earnings (@ ₹17/km):")
                        Text("₹$base", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("tips_earned_label", currentLang, tips))
                        Text("₹$tips", fontWeight = FontWeight.Bold, color = FreshGreen)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(AppStrings.t("total_delivery_payout", currentLang, total), fontWeight = FontWeight.ExtraBold)
                        Text("₹$total", color = FreshGreen, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "Partner Settlement Terms",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = "• Delivery earnings are calculated at ₹17 per kilometre (e.g. 5 km × ₹17 = ₹85).\n" +
                        "• Delivery earnings are independent of food pricing.\n" +
                        "• 100% of customer tips are credited directly to your partner wallet.\n" +
                        "• Daily direct bank deposit via UPI/IMPS.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
