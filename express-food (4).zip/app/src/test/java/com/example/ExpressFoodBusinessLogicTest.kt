package com.example

import com.example.data.ExpressRepository
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ExpressFoodBusinessLogicTest {

    @Before
    fun setUp() {
        ExpressRepository.resetToDefaultState()
        ExpressRepository.setLanguage(AppLanguage.HINDI)
    }

    // 1. Admin can create a restaurant account
    @Test
    fun testAdminCanCreateRestaurantAccount() {
        val newRest = ExpressRepository.provisionRestaurantPartner(
            name = "Royal Awadh Darbar",
            email = "awadh@expressfood.in",
            phone = "9812345678",
            cuisine = "Awadhi, Biryani",
            address = "Hazratganj, Lucknow",
            initialPassword = "tempPass123",
            mustChangePassword = true
        )
        assertNotNull(newRest)
        assertTrue(newRest.id.startsWith("REST-"))
        assertEquals("Royal Awadh Darbar", newRest.name)

        // Verify persisted in restaurants collection
        val foundInList = ExpressRepository.restaurants.value.find { it.id == newRest.id }
        assertNotNull(foundInList)
        assertEquals("ACTIVE", foundInList?.status)
    }

    // 2. Admin can create a delivery partner account
    @Test
    fun testAdminCanCreateDeliveryPartnerAccount() {
        val newDp = ExpressRepository.provisionDeliveryPartner(
            name = "Sunil Yadav",
            email = "sunil@expressfood.in",
            phone = "9876501234",
            address = "Gomti Nagar, Lucknow",
            vehicleType = "Electric Scooter",
            initialPassword = "tempPartner123",
            mustChangePassword = true
        )
        assertNotNull(newDp)
        assertTrue(newDp.code.startsWith("DP-"))
        assertEquals("Sunil Yadav", newDp.name)

        // Verify persisted in delivery partners collection
        val foundInList = ExpressRepository.deliveryPartners.value.find { it.id == newDp.id }
        assertNotNull(foundInList)
        assertEquals("ACTIVE", foundInList?.status)
    }

    // 3 & 4. Restaurant can log in using email OR mobile number
    @Test
    fun testRestaurantLoginWithEmailAndMobileNumber() {
        // Email login
        val emailAuth = ExpressRepository.authenticate("dilli@expressfood.in", "rest123", UserRole.RESTAURANT)
        assertTrue("Restaurant should authenticate via email", emailAuth is LoginResult.Success)

        // Mobile login (using registered phone 9822334455)
        val phoneAuth = ExpressRepository.authenticate("9822334455", "rest123", UserRole.RESTAURANT)
        assertTrue("Restaurant should authenticate via 10-digit mobile number", phoneAuth is LoginResult.Success)

        // Mobile login with +91 prefix
        val phoneWithPrefixAuth = ExpressRepository.authenticate("+91 9822334455", "rest123", UserRole.RESTAURANT)
        assertTrue("Restaurant should authenticate via phone with +91 prefix", phoneWithPrefixAuth is LoginResult.Success)
    }

    // 5 & 6. Delivery partner can log in using email OR mobile number
    @Test
    fun testDeliveryPartnerLoginWithEmailAndMobileNumber() {
        // Email login
        val emailAuth = ExpressRepository.authenticate("ramesh@expressfood.in", "partner123", UserRole.DELIVERY_PARTNER)
        assertTrue("Delivery Partner should authenticate via email", emailAuth is LoginResult.Success)

        // Mobile login (registered phone 9988776655)
        val phoneAuth = ExpressRepository.authenticate("9988776655", "partner123", UserRole.DELIVERY_PARTNER)
        assertTrue("Delivery Partner should authenticate via mobile number", phoneAuth is LoginResult.Success)
    }

    // 7. Each role opens the correct dashboard (verified by backend role checking)
    @Test
    fun testRoleVerificationPreventsCrossDashboardAccess() {
        // Restaurant account cannot log in as Delivery Partner or Admin
        val restAsDp = ExpressRepository.authenticate("dilli@expressfood.in", "rest123", UserRole.DELIVERY_PARTNER)
        assertTrue(restAsDp is LoginResult.InvalidCredentials)

        val restAsAdmin = ExpressRepository.authenticate("dilli@expressfood.in", "rest123", UserRole.ADMIN)
        assertTrue(restAsAdmin is LoginResult.InvalidCredentials)

        // Delivery partner cannot log in as Restaurant or Admin
        val dpAsRest = ExpressRepository.authenticate("ramesh@expressfood.in", "partner123", UserRole.RESTAURANT)
        assertTrue(dpAsRest is LoginResult.InvalidCredentials)

        val dpAsAdmin = ExpressRepository.authenticate("ramesh@expressfood.in", "partner123", UserRole.ADMIN)
        assertTrue(dpAsAdmin is LoginResult.InvalidCredentials)
    }

    // 8 & 10. Admin can edit and save a restaurant's details and saved changes remain
    @Test
    fun testAdminCanEditAndSaveRestaurantDetails() {
        val targetRest = ExpressRepository.restaurants.value.first()
        val originalId = targetRest.id

        val updateResult = ExpressRepository.updateRestaurant(
            id = originalId,
            name = "Dilli Durbar Heritage",
            cuisine = "Mughlai, Awadhi, Tandoori",
            address = "Block C, Connaught Place, New Delhi",
            phone = "9822998877",
            email = "heritage@expressfood.in",
            openingHours = "10:30 AM - 11:45 PM"
        )
        assertTrue(updateResult.isSuccess)

        // Verify changes in repository
        val updated = ExpressRepository.restaurants.value.find { it.id == originalId }
        assertNotNull(updated)
        assertEquals("Dilli Durbar Heritage", updated?.name)
        assertEquals("Block C, Connaught Place, New Delhi", updated?.address)
        assertEquals("9822998877", updated?.phone)
        assertEquals("heritage@expressfood.in", updated?.email)
    }

    // 9 & 10. Admin can edit and save delivery partner details and changes remain
    @Test
    fun testAdminCanEditAndSaveDeliveryPartnerDetails() {
        val targetDp = ExpressRepository.deliveryPartners.value.first()
        val originalId = targetDp.id

        val updateResult = ExpressRepository.updateDeliveryPartner(
            id = originalId,
            name = "Ramesh K. Verma",
            email = "ramesh.verma@expressfood.in",
            phone = "9988112233",
            address = "North Campus Hub, Delhi",
            vehicleType = "Hero Splendor Plus"
        )
        assertTrue(updateResult.isSuccess)

        val updated = ExpressRepository.deliveryPartners.value.find { it.id == originalId }
        assertNotNull(updated)
        assertEquals("Ramesh K. Verma", updated?.name)
        assertEquals("ramesh.verma@expressfood.in", updated?.email)
        assertEquals("9988112233", updated?.phone)
        assertEquals("Hero Splendor Plus", updated?.vehicleType)
    }

    // 11. Customer Forgot Password works with recovery flow
    @Test
    fun testCustomerForgotPasswordRecovery() {
        // Recover password using customer email
        val recoverResult = ExpressRepository.recoverCustomerPassword("customer@expressfood.in", "newSecurePassword123")
        assertTrue(recoverResult.isSuccess)

        // Login with old password must fail
        val oldLogin = ExpressRepository.authenticate("customer@expressfood.in", "customer123", UserRole.CUSTOMER)
        assertTrue(oldLogin is LoginResult.InvalidCredentials)

        // Login with new password must succeed
        val newLogin = ExpressRepository.authenticate("customer@expressfood.in", "newSecurePassword123", UserRole.CUSTOMER)
        assertTrue(newLogin is LoginResult.Success)
    }

    // 12 & 13. Customer Coin Reward System: ₹100 earns 15 coins, ₹250 earns 30 coins (complete ₹100 blocks only)
    @Test
    fun testCustomerCoinRewardSystemFifteenCoinsPerHundred() {
        // ₹100 eligible subtotal = 15 coins
        assertEquals(15, ExpressRepository.calculateEarnedCoins(100))

        // ₹200 eligible subtotal = 30 coins
        assertEquals(30, ExpressRepository.calculateEarnedCoins(200))

        // ₹250 eligible subtotal = 30 coins (complete ₹100 blocks only, partial ₹50 does not earn coins)
        assertEquals(30, ExpressRepository.calculateEarnedCoins(250))

        // ₹300 eligible subtotal = 45 coins
        assertEquals(45, ExpressRepository.calculateEarnedCoins(300))

        // ₹90 subtotal = 0 coins (less than complete ₹100 block)
        assertEquals(0, ExpressRepository.calculateEarnedCoins(90))

        // Test configurable rate: update rate to 20 coins per ₹100
        ExpressRepository.setCoinRewardRate(20)
        assertEquals(40, ExpressRepository.calculateEarnedCoins(250))

        // Reset back to standard default 15
        ExpressRepository.setCoinRewardRate(15)
        assertEquals(30, ExpressRepository.calculateEarnedCoins(250))
    }

    // 14. Duplicate order updates do not award coins twice
    @Test
    fun testDuplicateOrderUpdatesDoNotAwardCoinsTwice() {
        val initialCoinBalance = ExpressRepository.coinBalance.value

        // Place a real order with subtotal ₹200
        val menuItem = MenuItem("C-TEST", "REST-001", "Dish", "Desc", "Main", 80) // customer price = 100
        ExpressRepository.addToCart(menuItem)
        ExpressRepository.addToCart(menuItem) // subtotal = 200

        val orderResult = ExpressRepository.placeOrder(
            customerAddress = "Test Address",
            distanceKm = 1.0,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        )
        assertTrue(orderResult.isSuccess)
        val order = orderResult.getOrThrow()

        // Transition order: ORDER_PLACED -> RESTAURANT_ACCEPTED -> PREPARING -> READY_FOR_PICKUP -> PICKED_UP -> ON_THE_WAY -> DELIVERED
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.RESTAURANT_ACCEPTED)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PREPARING)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.READY_FOR_PICKUP)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PICKED_UP)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.ON_THE_WAY)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.DELIVERED)

        // ₹200 subtotal earns 30 coins
        val balanceAfterDelivery = ExpressRepository.coinBalance.value
        assertEquals(initialCoinBalance + 30, balanceAfterDelivery)

        // Attempting to deliver again or re-trigger DELIVERED update must NOT award coins a second time
        val updatedOrder = ExpressRepository.orders.value.find { it.id == order.id }!!
        assertTrue(updatedOrder.coinsAwarded)

        // Repeating update:
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.DELIVERED)
        assertEquals("Coin balance must not double-increment", balanceAfterDelivery, ExpressRepository.coinBalance.value)
    }

    // 15. Blocked / Suspended accounts cannot log in
    @Test
    fun testSuspendedAccountsBlockedFromLogin() {
        val dp = ExpressRepository.deliveryPartners.value.first()
        // Suspend delivery partner
        ExpressRepository.setDeliveryPartnerStatus(dp.id, "SUSPENDED")

        val loginAttempt = ExpressRepository.authenticate(dp.phone, "partner123", UserRole.DELIVERY_PARTNER)
        assertTrue("Suspended account must be blocked", loginAttempt is LoginResult.AccountBlocked)

        // Reactivate delivery partner
        ExpressRepository.setDeliveryPartnerStatus(dp.id, "ACTIVE")
        val activeAttempt = ExpressRepository.authenticate(dp.phone, "partner123", UserRole.DELIVERY_PARTNER)
        assertTrue("Active account must succeed", activeAttempt is LoginResult.Success)
    }

    // 16. Preservation of existing core pricing rules (₹20 markup, ₹10 platform fee, exact delivery bands)
    @Test
    fun testPreservationOfCorePricingAndDeliveryBands() {
        // ₹20 markup
        val item = MenuItem("ITEM", "REST-001", "Butter Chicken", "Desc", "Main", 220)
        assertEquals(240, item.customerPrice)

        // Delivery bands
        assertEquals(25, ExpressRepository.calculateDeliveryFee(0.8).fee)
        assertEquals(50, ExpressRepository.calculateDeliveryFee(1.5).fee)
        assertEquals(75, ExpressRepository.calculateDeliveryFee(2.8).fee)
        assertEquals(85, ExpressRepository.calculateDeliveryFee(4.5).fee)
        assertEquals(86, ExpressRepository.calculateDeliveryFee(5.2).fee)
        assertEquals(90, ExpressRepository.calculateDeliveryFee(6.1).fee)
        assertEquals(92, ExpressRepository.calculateDeliveryFee(7.4).fee)
        assertEquals(100, ExpressRepository.calculateDeliveryFee(8.9).fee)
        assertEquals(135, ExpressRepository.calculateDeliveryFee(9.5).fee)
        assertEquals(200, ExpressRepository.calculateDeliveryFee(10.5, isEmergency = true).fee)
        assertFalse(ExpressRepository.calculateDeliveryFee(13.5, isEmergency = true).isAvailable)
    }

    // 17. Automatic map coordinate distance calculation (Haversine formula)
    @Test
    fun testAutomaticCoordinateDistanceCalculation() {
        // Connaught Place (28.6328, 77.2197) to South Extension (28.5684, 77.2215) is ~7.16 km
        val distance = ExpressRepository.calculateCoordinateDistance(28.6328, 77.2197, 28.5684, 77.2215)
        assertTrue("Distance should be around 7.2 km", distance in 7.0..7.4)

        // Same location distance should be 0.0
        val zeroDist = ExpressRepository.calculateCoordinateDistance(28.6328, 77.2197, 28.6328, 77.2197)
        assertEquals(0.0, zeroDist, 0.01)
    }

    // 18. Placing order with map coordinates and straight-line distance
    @Test
    fun testPlaceOrderWithMapCoordinates() {
        val menuItem = MenuItem("C-COORD-TEST", "REST-001", "Biryani", "Desc", "Main", 180)
        ExpressRepository.addToCart(menuItem)

        // Customer in South Extension (28.5684, 77.2215) ordering from Dilli 6 (28.6328, 77.2197)
        val orderResult = ExpressRepository.placeOrder(
            customerAddress = "South Extension Part 2, New Delhi",
            customerLat = 28.5684,
            customerLng = 77.2215,
            tipAmount = 20,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.ONLINE_RAZORPAY,
            isEmergency = false
        )
        assertTrue(orderResult.isSuccess)
        val order = orderResult.getOrThrow()

        assertEquals(28.5684, order.customerLat, 0.0001)
        assertEquals(77.2215, order.customerLng, 0.0001)
        assertEquals(28.6328, order.restaurantLat, 0.0001)
        assertEquals(77.2197, order.restaurantLng, 0.0001)
        assertFalse(order.isRoadDistance) // Straight-line GPS coordinate distance
        assertTrue("Distance should be ~7.2 km", order.distanceKm in 7.0..7.4)
        // Band 8 (7.1 km to 8.0 km) = ₹92
        assertEquals(92, order.deliveryFee)
    }

    // 19. Admin assign and reassign delivery partner with active order state management
    @Test
    fun testAdminAssignAndReassignDeliveryPartner() {
        val menuItem = MenuItem("C-DISPATCH-TEST", "REST-001", "Thali", "Desc", "Main", 150)
        ExpressRepository.addToCart(menuItem)

        val order = ExpressRepository.placeOrder(
            customerAddress = "Lajpat Nagar, New Delhi",
            customerLat = 28.5700,
            customerLng = 77.2400,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        ).getOrThrow()

        val dp1 = ExpressRepository.deliveryPartners.value[0]
        val dp2 = ExpressRepository.deliveryPartners.value[1]

        // Initial assignment to DP1
        val assigned = ExpressRepository.assignDeliveryPartner(order.id, dp1.id)
        assertTrue("Admin can assign delivery partner", assigned)

        val afterAssign = ExpressRepository.orders.value.find { it.id == order.id }!!
        assertEquals(dp1.id, afterAssign.assignedDeliveryPartnerId)
        assertEquals(order.id, ExpressRepository.deliveryPartners.value.find { it.id == dp1.id }?.activeOrderId)

        // Reassign to DP2
        val reassigned = ExpressRepository.assignDeliveryPartner(order.id, dp2.id)
        assertTrue("Admin can reassign delivery partner", reassigned)

        val afterReassign = ExpressRepository.orders.value.find { it.id == order.id }!!
        assertEquals(dp2.id, afterReassign.assignedDeliveryPartnerId)
        // DP1's activeOrderId must be cleared
        assertNull(ExpressRepository.deliveryPartners.value.find { it.id == dp1.id }?.activeOrderId)
        // DP2's activeOrderId must be set
        assertEquals(order.id, ExpressRepository.deliveryPartners.value.find { it.id == dp2.id }?.activeOrderId)
    }

    // 20. Delivery partner online/offline duty status and offline alert during active delivery
    @Test
    fun testDeliveryPartnerOfflineAlertDuringActiveDelivery() {
        val dp = ExpressRepository.deliveryPartners.value.first()
        assertTrue("Partner starts online", dp.isOnline)

        val menuItem = MenuItem("C-ALERT-TEST", "REST-001", "Kebab", "Desc", "Main", 120)
        ExpressRepository.addToCart(menuItem)
        val order = ExpressRepository.placeOrder(
            customerAddress = "India Gate, New Delhi",
            customerLat = 28.6100,
            customerLng = 77.2200,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        ).getOrThrow()

        ExpressRepository.assignDeliveryPartner(order.id, dp.id)

        // Partner toggles offline while delivering
        ExpressRepository.updatePartnerOnlineStatus(dp.id, false)
        val updatedDp = ExpressRepository.deliveryPartners.value.find { it.id == dp.id }!!
        assertFalse(updatedDp.isOnline)
        assertTrue("lastStatusUpdatedAt should be recorded", updatedDp.lastStatusUpdatedAt > 0L)

        // Order is NOT cancelled, but partnerOfflineAlert is triggered for admin
        val updatedOrder = ExpressRepository.orders.value.find { it.id == order.id }!!
        assertFalse("Assigned partner is offline", updatedOrder.assignedDeliveryPartnerOnline)
        assertTrue("Admin dispatch offline alert should be true", updatedOrder.partnerOfflineAlert)
        assertNotEquals(OrderStatus.CANCELLED, updatedOrder.orderStatus)
    }

    // 21. Restaurant online/offline duty status and lastStatusUpdatedAt
    @Test
    fun testRestaurantOnlineStatusToggle() {
        val rest = ExpressRepository.restaurants.value.first()
        assertTrue("Restaurant starts open", rest.isOpen)

        ExpressRepository.updateRestaurantOnlineStatus(rest.id, false)
        val updatedRest = ExpressRepository.restaurants.value.find { it.id == rest.id }!!
        assertFalse(updatedRest.isOpen)
        assertTrue("lastStatusUpdatedAt should be recorded", updatedRest.lastStatusUpdatedAt > 0L)
    }

    // 22. Partner accounts authenticate directly into their portals without forced password popup
    @Test
    fun testPartnerAccountsAuthenticateDirectly() {
        // Restaurant login
        val restAuth = ExpressRepository.authenticate("dilli@expressfood.in", "rest123", UserRole.RESTAURANT)
        assertTrue("Restaurant should authenticate directly with Success", restAuth is LoginResult.Success)
        val restUser = (restAuth as LoginResult.Success).user
        assertEquals(UserRole.RESTAURANT, restUser.role)

        // Delivery Partner login
        val dpAuth = ExpressRepository.authenticate("ramesh@expressfood.in", "partner123", UserRole.DELIVERY_PARTNER)
        assertTrue("Delivery Partner should authenticate directly with Success", dpAuth is LoginResult.Success)
        val dpUser = (dpAuth as LoginResult.Success).user
        assertEquals(UserRole.DELIVERY_PARTNER, dpUser.role)
    }

    // 23. Admin newly created partner logs in directly with assigned credentials
    @Test
    fun testAdminCreatedPartnerCanLoginDirectly() {
        val newDp = ExpressRepository.provisionDeliveryPartner(
            name = "Kavita Rao",
            email = "kavita@expressfood.in",
            phone = "9876543219",
            address = "Koramangala, Bengaluru",
            vehicleType = "Bicycle",
            initialPassword = "securePass2026",
            mustChangePassword = false
        )
        assertNotNull(newDp)

        val authResult = ExpressRepository.authenticate("kavita@expressfood.in", "securePass2026", UserRole.DELIVERY_PARTNER)
        assertTrue("Newly provisioned partner authenticates directly", authResult is LoginResult.Success)
        assertEquals(newDp.id, (authResult as LoginResult.Success).user.assignedEntityId)
    }

    // 24. Coin rewards are idempotent and not duplicated on multiple delivery status triggers
    @Test
    fun testCoinRewardsIdempotentOnDelivery() {
        val menuItem = MenuItem("C-COIN-TEST", "REST-001", "Biryani Feast", "Desc", "Biryani", 300)
        ExpressRepository.addToCart(menuItem)
        val order = ExpressRepository.placeOrder(
            customerAddress = "Connaught Place, New Delhi",
            customerLat = 28.6300,
            customerLng = 77.2180,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        ).getOrThrow()

        val dp1 = ExpressRepository.deliveryPartners.value[0]
        ExpressRepository.assignDeliveryPartner(order.id, dp1.id)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.RESTAURANT_ACCEPTED, "Accepted")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PREPARING, "Cooking")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.READY_FOR_PICKUP, "Packed")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PICKED_UP, "Driver picked up")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.ON_THE_WAY, "Driver on the way")

        val initialCoins = ExpressRepository.coinBalance.value

        // First delivery trigger: earns coins
        val delivered = ExpressRepository.updateOrderStatus(order.id, OrderStatus.DELIVERED, "Delivered to doorstep")
        assertTrue("Order should transition to DELIVERED", delivered)
        val coinsAfterFirst = ExpressRepository.coinBalance.value
        assertTrue("Coins should be awarded upon delivery", coinsAfterFirst > initialCoins)

        // Repeat status trigger: must NOT award coins again
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.DELIVERED, "Delivered confirmation duplicate")
        val coinsAfterSecond = ExpressRepository.coinBalance.value
        assertEquals("Coins must remain identical on duplicate delivery status updates", coinsAfterFirst, coinsAfterSecond)
    }

    // 25. Restaurant partner can upload food item photo and ₹20 markup is applied exactly once
    @Test
    fun testMenuItemCreationWithPhotoAndStrictTwentyRupeeMarkup() {
        val dish = ExpressRepository.addMenuItem(
            restaurantId = "REST-001",
            name = "Paneer Tikka Kebab",
            description = "Smoky grilled cottage cheese skewers with mint chutney",
            category = "Starters",
            originalPrice = 180,
            isVeg = true,
            imageUrl = "content://media/external/images/media/4567"
        )

        assertEquals("Original price should be preserved", 180, dish.originalPrice)
        assertEquals("Markup amount must be exactly ₹20", 20, dish.markupAmount)
        assertEquals("Customer price must be originalPrice + 20", 200, dish.customerPrice)
        assertEquals("Image URL / URI must be saved", "content://media/external/images/media/4567", dish.imageUrl)

        // Verify stored in repository
        val stored = ExpressRepository.menuItems.value.find { it.id == dish.id }
        assertNotNull(stored)
        assertEquals(200, stored?.customerPrice)
        assertEquals("content://media/external/images/media/4567", stored?.imageUrl)
    }

    // 26. Delivery partner earnings calculated strictly at ₹17 per kilometre
    @Test
    fun testDeliveryPartnerEarningsCalculatedStrictlyAtSeventeenPerKm() {
        val cheapItem = MenuItem("ITEM-CHEAP", "REST-001", "Tea", "Chai", "Beverages", 30)
        ExpressRepository.addToCart(cheapItem)

        // Place order with approx 5 km distance
        val order = ExpressRepository.placeOrder(
            customerAddress = "Saket, New Delhi",
            distanceKm = 5.0,
            tipAmount = 25,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.ONLINE
        ).getOrThrow()

        assertEquals("Rate per km must be exactly ₹17", 17, order.deliveryPartnerRatePerKm)
        // 5 km * 17 = 85
        assertEquals("5 km distance must yield exactly ₹85 delivery partner earnings", 85, order.deliveryPartnerEarnings)
        assertNotEquals("Earnings must not be derived from food subtotal", order.subtotal, order.deliveryPartnerEarnings)
    }

    // 27. Delivery partner base earnings incremented by ₹17/km on delivery
    @Test
    fun testDeliveryPartnerBaseEarningsUpdatedOnDeliveredStatus() {
        val item = MenuItem("ITEM-FEAST", "REST-001", "Feast", "Desc", "Main Course", 250)
        ExpressRepository.addToCart(item)

        val order = ExpressRepository.placeOrder(
            customerAddress = "Lajpat Nagar, New Delhi",
            distanceKm = 4.0,
            tipAmount = 15,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.ONLINE
        ).getOrThrow()

        val partner = ExpressRepository.deliveryPartners.value[0]
        val initialEarnings = partner.baseEarnings
        val expectedEarningsForOrder = order.deliveryPartnerEarnings // 4 km * 17 = 68

        ExpressRepository.assignDeliveryPartner(order.id, partner.id)
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.RESTAURANT_ACCEPTED, "Accepted")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PREPARING, "Cooking")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.READY_FOR_PICKUP, "Packed")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.PICKED_UP, "Driver picked up")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.ON_THE_WAY, "On the way")
        ExpressRepository.updateOrderStatus(order.id, OrderStatus.DELIVERED, "Delivered")

        val updatedPartner = ExpressRepository.deliveryPartners.value.find { it.id == partner.id }!!
        assertEquals(
            "Partner base earnings must increase by order.deliveryPartnerEarnings",
            initialEarnings + expectedEarningsForOrder,
            updatedPartner.baseEarnings
        )
    }

    // 28. Realtime notifications dispatched on order placement and delivery assignment
    @Test
    fun testNotificationDispatchForNewOrderAndDeliveryAssignment() {
        val item = MenuItem("ITEM-NOTIF", "REST-001", "Dal Tadka", "Desc", "Main Course", 140)
        ExpressRepository.addToCart(item)

        val initialNotifCount = ExpressRepository.notifications.value.size

        val order = ExpressRepository.placeOrder(
            customerAddress = "Hauz Khas, New Delhi",
            distanceKm = 3.0,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        ).getOrThrow()

        // Restaurant notification should be posted
        val notifsAfterPlace = ExpressRepository.notifications.value
        val restNotif = notifsAfterPlace.find { it.orderId == order.id && it.recipientRole == UserRole.RESTAURANT }
        assertNotNull("Restaurant partner must receive a notification for the new order", restNotif)
        assertTrue(restNotif!!.title.contains(order.id))

        // Assign delivery partner
        val dp = ExpressRepository.deliveryPartners.value[0]
        ExpressRepository.assignDeliveryPartner(order.id, dp.id)

        val dpNotif = ExpressRepository.notifications.value.find { it.orderId == order.id && it.recipientRole == UserRole.DELIVERY_PARTNER }
        assertNotNull("Delivery partner must receive a notification for assigned order", dpNotif)
        assertTrue(dpNotif!!.title.contains(order.id))
    }

    // 29. COD vs Online Payment status handling
    @Test
    fun testCashOnDeliveryVsOnlinePaymentStatus() {
        val item = MenuItem("ITEM-PAY", "REST-001", "Roti", "Desc", "Breads", 40)
        ExpressRepository.addToCart(item)

        // Online Order: Immediately SUCCESSFUL
        val onlineOrder = ExpressRepository.placeOrder(
            customerAddress = "Noida Sector 18",
            distanceKm = 3.0,
            tipAmount = 10,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.ONLINE
        ).getOrThrow()

        assertEquals(PaymentMethod.ONLINE, onlineOrder.paymentMethod)
        assertEquals(PaymentStatus.SUCCESSFUL, onlineOrder.paymentStatus)

        // COD Order: Starts as PENDING, turns SUCCESSFUL upon DELIVERED
        ExpressRepository.addToCart(item)
        val codOrder = ExpressRepository.placeOrder(
            customerAddress = "Noida Sector 62",
            distanceKm = 4.0,
            tipAmount = 0,
            coinsRedeemed = 0,
            paymentMethod = PaymentMethod.COD
        ).getOrThrow()

        assertEquals(PaymentMethod.COD, codOrder.paymentMethod)
        assertEquals(PaymentStatus.PENDING, codOrder.paymentStatus)

        val dp = ExpressRepository.deliveryPartners.value[0]
        ExpressRepository.assignDeliveryPartner(codOrder.id, dp.id)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.RESTAURANT_ACCEPTED)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.PREPARING)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.READY_FOR_PICKUP)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.PICKED_UP)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.ON_THE_WAY)
        ExpressRepository.updateOrderStatus(codOrder.id, OrderStatus.DELIVERED)

        val deliveredCodOrder = ExpressRepository.orders.value.find { it.id == codOrder.id }!!
        assertEquals("COD paymentStatus must become SUCCESSFUL upon delivery", PaymentStatus.SUCCESSFUL, deliveredCodOrder.paymentStatus)
    }
}
